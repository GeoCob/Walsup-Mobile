import { products, news, Profile } from "./Images";

export const offerData = [
    {
        offer_id:1,
        title: "Offer teste 01",
        image: products.prod_1,
        description: "lorem ipsum Can't find so I pulled on wrists and then got to write, some line just for the sake of, making the discription full of love"
    },
    {
        offer_id:2,
        title: "Offer teste 02",
        image: products.prod_2,
        description: "lorem ipsum Can't find so I pulled on wrists and then got to write, some line just for the sake of, making the discription full of love"
    },
    {
        offer_id:3,
        title: "Offer teste 03",
        image: products.prod_3,
        description: "lorem ipsum Can't find so I pulled on wrists and then got to write, some line just for the sake of, making the discription full of love"
    },
    {
        offer_id:4,
        title: "Offer teste 04",
        image: products.prod_4,
        description: "lorem ipsum Can't find so I pulled on wrists and then got to write, some line just for the sake of, making the discription full of love"
    },
    {
        offer_id:5,
        title: "Offer teste 05",
        image: products.prod_5,
        description: "lorem ipsum Can't find so I pulled on wrists and then got to write, some line just for the sake of, making the discription full of love"
    },
]

export const newsData = [
    {
        offer_id:1,
        title: "News teste 01",
        image: news.new_1,
        description: "lorem ipsum Can't find so I pulled on wrists and then got to write, some line just for the sake of, making the discription full of love"
    },
    {
        offer_id:2,
        title: "News teste 02",
        image: news.new_2,
        description: "lorem ipsum Can't find so I pulled on wrists and then got to write, some line just for the sake of, making the discription full of love"
    },
    {
        offer_id:3,
        title: "News teste 03",
        image: news.new_3,
        description: "lorem ipsum Can't find so I pulled on wrists and then got to write, some line just for the sake of, making the discription full of love"
    },
    {
        offer_id:4,
        title: "News teste 04",
        image: news.new_4,
        description: "lorem ipsum Can't find so I pulled on wrists and then got to write, some line just for the sake of, making the discription full of love"
    },
    {
        offer_id:5,
        title: "News teste 05",
        image: news.new_5,
        description: "lorem ipsum Can't find so I pulled on wrists and then got to write, some line just for the sake of, making the discription full of love"
    },
]

export const emptyData = []

export const Comments = [
    {
        id: 1,
        userName: "Jean Leclair",
        image: Profile.user1,
        comment: "Excellent prix pour les étudiants et une belle configuration!"
    },
    {
        id: 2,
        userName: "Christophe Guertin",
        image: Profile.user2,
        comment: "Cashback intéréssant pour un smartphone de qualité."
    },
    {
        id: 3,
        userName: "Karine Bauer",
        image: Profile.user3,
        comment: "le cashback, le cashbcak, est super aussi le produit !"
    },
    {
        id: 4,
        userName: "Olivier Hubert",
        image: Profile.user4,
        comment: "Pas mal mais juste pour pour un deal, c'est tellement facile de pa ratter ça!"
    },
    // {
    //     id: 5,
    //     userName: "Françoise Lopez",
    //     image: Profile.user5,
    //     comment: "J'est testé et j'approuve"
    // },
    // {
    //     id: 6,
    //     userName: "Etrig Mister",
    //     image: Profile.user6,
    //     comment: "Une offre intéressante"
    // },
    // {
    //     id: 7,
    //     userName: "Éric Flamand",
    //     image: Profile.user7,
    //     comment: "je partage de suite avec mon groupe"
    // },
    // {
    //     id: 8,
    //     userName: "Pierre Dupont",
    //     image: Profile.user8,
    //     comment: "je suis pas trop convincue"
    // },
]