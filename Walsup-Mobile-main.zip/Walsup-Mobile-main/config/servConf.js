//true for buld mode false for local
export const serverSection = true;
