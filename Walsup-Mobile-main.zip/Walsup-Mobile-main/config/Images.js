
export const products ={
    prod_1: require('../assets/porductsImages/prod_001.jpg'),
    prod_2: require('../assets/porductsImages/prod_002.jpg'),
    prod_3: require('../assets/porductsImages/prod_003.jpg'),
    prod_4: require('../assets/porductsImages/prod_004.jpg'),
    prod_5: require('../assets/porductsImages/prod_005.jpg')
}

export const news = {
    new_1: require('../assets/porductsImages/news_001.jpg'),
    new_2: require('../assets/porductsImages/news_002.jpg'),
    new_3: require('../assets/porductsImages/news_003.jpg'),
    new_4: require('../assets/porductsImages/news_004.jpg'),
    new_5: require('../assets/porductsImages/news_005.jpg')
}

export const Icons = {
    filter: require("../assets/Icons/filter_new.png"),
    filter_P: require("../assets/Icons/filter_news_P.png"),
    heart: require("../assets/Icons/Heart.png"),
    heart_Active: require("../assets/Icons/Heart_active.png"),
    share: require("../assets/Icons/Send.png"),
    wishlist: require("../assets/Icons/wishlist.png"),
    starsAvis: require('../assets/Icons/stars.png'),
    wishlist_details: require('../assets/Icons/wishlist_details.png'),
    bag_details: require('../assets/Icons/bags.png'),
    cart_details: require('../assets/Icons/cart_details.png')
}

export const Mascotts = {
    noProducts: require('../assets/AUCUN_OFFRE_1.png'),
    cashback_mascote: require('../assets/mascotes/cashback_mascot.png'),
    money: require('../assets/mascotes/money_honey.png'),
    timer_guy: require('../assets/mascotes/timer_Guy.png'),
    link_mascot: require('../assets/mascotes/link_mascot.png')
}

export const Logo ={
    timer_logo: require('../assets/logo_logo_timer_cut.png'),
    logo_detail_big: require('../assets/big_logo_details.png')
}

export const Profile = {
    user1: require('../assets/fakePorfile/prof_01.png'),
    user2: require('../assets/fakePorfile/prof_02.png'),
    user3: require('../assets/fakePorfile/prof_03.png'),
    user4: require('../assets/fakePorfile/prof_04.png'),
    user5: require('../assets/fakePorfile/prof_05.png'),
    user6: require('../assets/fakePorfile/prof_06.png'),
    user7: require('../assets/fakePorfile/prof_07.png'),
    user8: require('../assets/fakePorfile/prof_08.png'),
    userDefault: require('../assets/profile.png')
}