import { initializeApp } from "firebase/app";
import { getDatabase } from "firebase/database";
import { getStorage } from "firebase/storage";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCYsWu3z6aXsPkEOTlfw_dw8NqAwN1bN5s",
  authDomain: "walsup-4b132.firebaseapp.com",
  databaseURL:
    "https://walsup-4b132-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "walsup-4b132",
  storageBucket: "walsup-4b132.appspot.com",
  messagingSenderId: "281609768173",
  appId: "1:281609768173:web:1552687b209c8a8eff50e4",
  measurementId: "G-ZGHNSNT9K5",
};

// Initialize Firebase
const firebaseApp = initializeApp(firebaseConfig);

// Export database, auth and storage instances
export const auth = getAuth(firebaseApp);
export const database = getDatabase(firebaseApp);
export const storage = getStorage(firebaseApp);
