

/**
 * main colors app
 */

export const BaseColor = {
    primaryColor: "#6959DE",
    primarydark: "#352F84",
    primaryLight: "#E3D4F2",
    secondary: "#F5F2ED",
    orangePrimary: "#F25924",
    white: "#ffffff",
    backMain: "#130F26",
    fadedGrey: "#F2F2F2",
    fadedGrey_02: "#eee",
    greyMain: "#9597A1",
    greenPrimary: "#3AE180",
    greenLight: "#74F0A8",
    darckBlue: "#352F84",
    redheart: "#FF3F33",
}

export const Fonts = {
    font_family: "Poppins",
    font_EXXL: 28,
    font_XXL: 20,
    font_XL: 16,
    font_big: 14,
    font_normal: 12,
    font_small: 10,
    font_800: "800",
    font_700: "700",
    font_600: "600",
    font_500: "500",
    font_400: "400"
}