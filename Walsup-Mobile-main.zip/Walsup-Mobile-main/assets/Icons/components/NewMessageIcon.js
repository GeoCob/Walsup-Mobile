import * as React from "react"
import Svg, { Circle, Path } from "react-native-svg"

function NewMessageIcon(props) {
  return (
    <Svg
      width={35}
      height={35}
      viewBox="0 0 35 35"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <Circle cx={17.5} cy={17.5} r={17.5} fill="#F2F2F2" />
      <Path
        d="M9.062 9.328h10.306a2.061 2.061 0 012.06 2.061v6.184a2.06 2.06 0 01-2.06 2.06h-3.092l-3.092 3.092-3.091-3.091h-1.03A2.061 2.061 0 017 17.573v-6.184a2.061 2.061 0 012.061-2.06z"
        stroke="#6959DE"
        strokeWidth={1.85}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M21.43 14.477h4.123a2.061 2.061 0 012.061 2.06v6.184a2.061 2.061 0 01-2.06 2.061h-2.062l-2.061 3.092-3.092-3.092h-3.091a2.06 2.06 0 01-2.061-2.061"
        stroke="#6959DE"
        strokeWidth={1.85}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  )
}

export default NewMessageIcon
