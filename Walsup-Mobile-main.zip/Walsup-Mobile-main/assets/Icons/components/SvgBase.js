import React from 'react'
import { View } from 'react-native'

const SvgBase = ({...props}) => {
  return (
    <View>
        centratl SVG handler
    </View>
  )
}

export default SvgBase