import React from 'react';
import { Svg, Path } from 'react-native-svg';
import { BaseColor } from '../../../config/theme';

const WishlistSvg = ({ scale, color}) => {
  return (
    <Svg width={scale.width} height={scale.height} viewBox="0 0 18 21" fill="none" xmlns="http://www.w3.org/2000/svg">
      <Path
        d="M5.27344 7.71875H12.1557"
        stroke={color ? color : BaseColor.backMain}
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        FillRule="evenodd"
        ClipRule="evenodd"
        d="M8.71094 1C2.2985 1 1.2152 1.932 1.2152 9.429C1.2152 17.822 1.05757 20 2.65993 20C4.26128 20 6.87666 16.316 8.71094 16.316C10.5452 16.316 13.1606 20 14.7619 20C16.3643 20 16.2067 17.822 16.2067 9.429C16.2067 1.932 15.1234 1 8.71094 1Z"
        stroke={color ? color : BaseColor.backMain}
        strokeWidth="1.6"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </Svg>
  );
};

export default WishlistSvg;
