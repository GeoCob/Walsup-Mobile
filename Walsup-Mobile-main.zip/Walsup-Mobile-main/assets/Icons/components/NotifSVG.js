import React from 'react'
import { Svg, Path, Mask,G } from 'react-native-svg'


const NotifSVG = ({scale}) => {
    return (
        <Svg width={scale.width} height={scale.height} viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg">
            <Mask id="mask0_4447_34213" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="3" y="1" width="24" height="22">
            <Path FillRule="evenodd" ClipRule="evenodd" d="M3.75 1.25H26.8711V22.935H3.75V1.25Z" fill="white"/>
            </Mask>
        <G Mask="url(#mask0_4447_34213)">
        <Path fillRule="evenodd" clipRule="evenodd" d="M15.3088 3.125C10.94 3.125 7.89502 6.5475 7.89502 9.61875C7.89502 12.2175 7.17377 13.4187 6.53627 14.4788C6.02502 15.33 5.62127 16.0025 5.62127 17.4637C5.83002 19.8212 7.38627 21.06 15.3088 21.06C23.1875 21.06 24.7925 19.7663 25 17.3825C24.9963 16.0025 24.5925 15.33 24.0813 14.4788C23.4438 13.4187 22.7225 12.2175 22.7225 9.61875C22.7225 6.5475 19.6775 3.125 15.3088 3.125ZM15.3088 22.935C9.46377 22.935 4.18127 22.5225 3.75002 17.5438C3.74627 15.4837 4.37502 14.4362 4.93002 13.5138C5.49127 12.5787 6.02002 11.6975 6.02002 9.61875C6.02002 5.5775 9.75252 1.25 15.3088 1.25C20.865 1.25 24.5975 5.5775 24.5975 9.61875C24.5975 11.6975 25.1263 12.5787 25.6875 13.5138C26.2425 14.4362 26.8713 15.4837 26.8713 17.4637C26.435 22.5225 21.1538 22.935 15.3088 22.935Z" fill="#130F26" strokeWidth={scale.stroke} strokeLinecap={"round"} strokeLinejoin={"round"} strokeDasharray={"4, 2"} />
        </G>
        <Path fillRule="evenodd" clipRule="evenodd" d="M15.2502 28.1243H15.2477C13.8465 28.123 12.5202 27.5055 11.514 26.3843C11.1677 26.0005 11.199 25.4068 11.584 25.0618C11.969 24.7143 12.5615 24.7455 12.9077 25.1318C13.5552 25.853 14.3865 26.2493 15.249 26.2493H15.2502C16.1165 26.2493 16.9515 25.853 17.6002 25.1305C17.9477 24.7468 18.5402 24.7155 18.924 25.0618C19.309 25.408 19.3402 26.0018 18.994 26.3855C17.984 27.5068 16.6552 28.1243 15.2502 28.1243Z" fill="#130F26" strokeWidth={scale.stroke} strokeLinecap={"round"} strokeLinejoin={"round"} strokeDasharray={"4, 2"}/>
      </Svg>

    );
};

export default NotifSVG;