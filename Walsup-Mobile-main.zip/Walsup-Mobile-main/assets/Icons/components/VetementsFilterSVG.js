import * as React from 'react';
import Svg, { G, Circle, Path, Defs, ClipPath } from 'react-native-svg';

const VetementsFilterSVG = ({circleColor}) => {
  return (
    <Svg width="89" height="92" viewBox="0 0 70 92" fill="none" xmlns="http://www.w3.org/2000/svg">
      <Circle cx={32.5} cy={32.5} r={32.5} fill={circleColor.value} />
      <G clipPath="url(#clip0_6_30)">
        <Path
          d="M48.316 24.112c-1.971-2.507-5.476-6.08-9.436-6.08l-2.136 3.19-4.244 3.19-4.244-3.19-2.136-3.19c-3.96 0-7.465 3.573-9.437 6.08l.014.052v.001l.984 3.603 3.608 1.604 1.164-.808s-.284 10.419-.284 18.404h20.662c0-7.985-.284-18.404-.284-18.404l1.164.808 3.607-1.604.984-3.603v-.001l.016-.05-.002-.002z"
          fill="#FF6465"
        />
        <Path
          d="M36.538 18.032a4.042 4.042 0 01-4.038 4.037 4.042 4.042 0 01-4.038-4.037H26.12a6.38 6.38 0 0012.76 0h-2.343zM16.697 24.164l-.014-.052-.136.176A24.24 24.24 0 0015 26.51s.38 2.205 3.727 4.639l2.562-1.778c-3.18-2.237-4.253-4.307-4.592-5.208zM48.417 24.241l-.099-.127-.015.05c-.34.901-1.412 2.971-4.592 5.207l2.563 1.779C49.62 28.716 50 26.51 50 26.51s-.58-.978-1.583-2.269z"
          fill="#6AB2CC"
        />
      </G>
      <Defs>
        <ClipPath id="clip0_6_30">
          <Path fill="#fff" transform="translate(15 15)" d="M0 0H35V35H0z" />
        </ClipPath>
      </Defs>
    </Svg>
  );
};

export default VetementsFilterSVG;
