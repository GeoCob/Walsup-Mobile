import * as React from 'react';
import Svg, { Circle, Path } from 'react-native-svg';

function DrawerSVG() {
  return (
    <Svg width={30} height={30} viewBox="0 0 30 30" fill="none" xmlns="http://www.w3.org/2000/svg" >
      <Circle cx={6.5} cy={6.5} r={6.5} fill="#F2F2F2" />
      <Path d="M3 4h6.75H3z" fill="#F2F2F2" />
      <Path d="M3 4h6.75" stroke="#130F26" strokeWidth={0.75} strokeLinecap="round" strokeLinejoin="round" />
      <Path d="M3 6.5h6.75H3z" fill="#F2F2F2" />
      <Path d="M3 6.5h6.75" stroke="#130F26" strokeWidth={0.75} strokeLinecap="round" strokeLinejoin="round" />
      <Path d="M3 9h6.75H3z" fill="#F2F2F2" />
      <Path d="M3 9h6.75" stroke="#130F26" strokeWidth={0.75} strokeLinecap="round" strokeLinejoin="round" />
    </Svg>
  );
}

export default DrawerSVG;
