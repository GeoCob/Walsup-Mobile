import React from 'react'
import Svg, { Path } from "react-native-svg"
import { BaseColor } from "../../../config/theme"

const CartSvg = (props) => {
    const {scale, color} = props
  return (
    <Svg
      width={scale.width ? scale.width : 24}
      height={scale.height ? scale.height : 24}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg">
      <Path
        d="M2.75 3.25l2.08.36.963 11.473a1.8 1.8 0 001.8 1.653h10.909a1.8 1.8 0 001.785-1.546l.949-6.558a1.341 1.341 0 00-1.135-1.519c-.064-.009-14.937-.014-14.937-.014M14.125 10.797h2.773"
        stroke={color ? color : BaseColor.backMain}
        strokeWidth={1.5}
        strokeLinecap="round"
        strokeLinejoin="round" />
      <Path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M7.154 20.203a.544.544 0 110 1.088.544.544 0 010-1.088zM18.435 20.203a.545.545 0 110 1.09.545.545 0 010-1.09z"
        fill={color ? color : BaseColor.backMain}
        stroke={color ? color : BaseColor.backMain}
        strokeWidth={2}
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </Svg>
  )
}

export default CartSvg;