import React, {useState} from 'react'
import { Svg, Path,Circle} from 'react-native-svg'

const ProfileSvg = ({scale}) => {
    return (
        <Svg width={scale.width} height={scale.height} viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
        <Path FillRule="evenodd" ClipRule="evenodd" d="M11.983 15.3438C8.11536 15.3438 4.8125 15.9285 4.8125 18.2704C4.8125 20.6123 8.0944 21.218 11.983 21.218C15.8506 21.218 19.1525 20.6323 19.1525 18.2914C19.1525 15.9504 15.8715 15.3438 11.983 15.3438Z" stroke="#6959DE" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <Path FillRule="evenodd" ClipRule="evenodd" d="M11.9829 12.0039C14.521 12.0039 16.5782 9.94583 16.5782 7.40774C16.5782 4.86964 14.521 2.8125 11.9829 2.8125C9.44484 2.8125 7.38675 4.86964 7.38675 7.40774C7.37817 9.93726 9.42198 11.9954 11.9506 12.0039H11.9829Z" stroke="#6959DE" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </Svg>
    );
};

export default ProfileSvg;