import React from 'react';
import { Svg, Path, Mask, G, Circle } from 'react-native-svg';
import { BaseColor } from '../../../config/theme';

const SendButtonChat = ({ scale, active }) => {
  return (
    <Svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <Circle cx="20" cy="20" r="20" fill={active ? "#6959DE" : BaseColor.greyMain} />
      <Path
        d="M19.0704 13.1545L27.1135 17.176C30.7216 18.9801 30.7216 21.9305 27.1135 23.7346L19.0704 27.7561C13.6582 30.4622 11.4501 28.2447 14.1562 22.8419L14.9736 21.2164C15.1803 20.803 15.1803 20.117 14.9736 19.7036L14.1562 18.0687C11.4501 12.6659 13.6676 10.4484 19.0704 13.1545Z"
        stroke="white"
        strokeWidth="1.52732"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <Path
        d="M15.25 20.4531H27.5402"
        stroke="white"
        stroke-width="1.52732"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </Svg>
  );
};

export default SendButtonChat;
