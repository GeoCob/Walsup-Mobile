import React from 'react'
import { Svg, Path, Mask,G } from 'react-native-svg'

const SocialSvg = ({scale,color}) => {
    return (
        <Svg width={scale.width} height={scale.height} viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
        <Path  fillRule="evenodd" clipRule="evenodd" d="M10.3887 16.4766C14.3851 16.4766 17.8009 17.0821 17.8009 19.5012C17.8009 21.9203 14.4079 22.5432 10.3887 22.5432C6.39123 22.5432 2.97656 21.9431 2.97656 19.5229C2.97656 17.1027 6.36848 16.4766 10.3887 16.4766Z" stroke={color ? color : BaseColor.backMain} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <Path fillRule="evenodd" clipRule="evenodd" d="M10.3921 13.0243C7.76829 13.0243 5.64062 10.8977 5.64062 8.27385C5.64062 5.65002 7.76829 3.52344 10.3921 3.52344C13.0149 3.52344 15.1425 5.65002 15.1425 8.27385C15.1523 10.8879 13.0398 13.0145 10.4257 13.0243H10.3921Z" stroke={color ? color : BaseColor.backMain} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <Path d="M17.8516 11.7877C19.586 11.544 20.9217 10.0555 20.925 8.2539C20.925 6.47831 19.6304 5.00498 17.9328 4.72656" stroke={color ? color : BaseColor.backMain} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <Path d="M20.1406 15.9609C21.8209 16.2112 22.9941 16.8005 22.9941 18.0139C22.9941 18.8491 22.4416 19.3908 21.549 19.7299" stroke={color ? color : BaseColor.backMain} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </Svg>
    );
};

export default SocialSvg;
