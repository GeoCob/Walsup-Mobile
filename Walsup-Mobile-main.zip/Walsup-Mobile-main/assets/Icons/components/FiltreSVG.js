import React from 'react'
import { Svg, Path } from 'react-native-svg'

const FiltreSVG = ({scale}) => {
    return (

<Svg width={scale.width} height={scale.height}  viewBox="0 0 29 25" fill="none" xmlns="http://www.w3.org/2000/svg">
<Path d="M2 19.6172H8.2493Z" fill="#F2F2F2"/>
<Path d="M2 19.6172H8.2493" stroke="#6959DE" strokeWidth="2.35276" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
<Path d="M26.9983 5.875H20.749Z" fill="#F2F2F2"/>
<Path d="M26.9983 5.875H20.749" stroke="#6959DE" strokeWidth="2.35276" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
<Path d="M15.7471 19.6172H26.9958Z" fill="#F2F2F2"/>
<Path d="M15.7471 19.6172H26.9958" stroke="#6959DE" strokeWidth="2.35276" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
<Path d="M13.2487 5.875H2Z" fill="#F2F2F2"/>
<Path d="M13.2487 5.875H2" stroke="#6959DE" strokeWidth="2.35276" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
<Path d="M11.9996 23.2492C9.92875 23.2492 8.25 21.5705 8.25 19.4996C8.25 17.4287 9.92875 15.75 11.9996 15.75C14.0705 15.75 15.7492 17.4287 15.7492 19.4996C15.7492 21.5705 14.0705 23.2492 11.9996 23.2492Z" stroke="#6959DE" strokeWidth="2.35276" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
<Path d="M17.0015 9.49916C19.0724 9.49916 20.7511 7.82042 20.7511 5.74958C20.7511 3.67875 19.0724 2 17.0015 2C14.9306 2 13.252 3.67875 13.252 5.74958C13.252 7.82042 14.9306 9.49916 17.0015 9.49916Z" stroke="#6959DE" strokeWidth="2.35276" strokeMiterlimit="10" strokeLinecap="round" strokeLinejoin="round"/>
</Svg>
    );
};

export default FiltreSVG;