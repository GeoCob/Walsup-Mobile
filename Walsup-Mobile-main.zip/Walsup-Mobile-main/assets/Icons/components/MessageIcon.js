import React, {useState} from 'react'
import { Svg, Path, Circle } from 'react-native-svg'
import { BaseColor } from '../../../config/theme'

const MessageIcon = ({scale}) => {
    const [scaler, setScaler] = useState({...scale})
  return (
        <Svg width={scaler.width} height={scaler.height} viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
            <Path d="M6.99946 13.1117V12.9989M12.9989 13.1117V12.9989M18.9984 13.1117V12.9989M24.9978 12.9989C24.9978 14.7238 24.6339 16.3637 23.9786 17.8459L25.0001 24.9967L18.872 23.4647C17.136 24.441 15.1325 24.9978 12.9989 24.9978C6.3721 24.9978 1 19.6257 1 12.9989C1 6.3721 6.3721 1 12.9989 1C19.6257 1 24.9978 6.3721 24.9978 12.9989Z" stroke={BaseColor.backMain} strokeWidth={scaler.stroke} strokeLinecap={"round"} strokeLinejoin={"round"} />
            <Circle cx="6.73061" cy="12.7853" r="1.73061" fill={BaseColor.backMain}/>
            <Circle cx="12.4962" cy="12.7853" r="1.73061" fill={BaseColor.backMain}/>
            <Circle cx="18.2697" cy="12.7853" r="1.73061" fill={BaseColor.backMain}/>
        </Svg>
  )
}

export default MessageIcon