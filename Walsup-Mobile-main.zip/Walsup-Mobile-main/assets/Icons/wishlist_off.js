import { Svg, Path } from "react-native-svg";


const wishlist_off = () => {
  return (
    <View>
        <Svg width="19" height="21" viewBox="0 0 19 21" fill="none" xmlns="http://www.w3.org/2000/svg">
        <Path d="M5.83203 7.80078H13.1732" stroke="#130F26" stroke-width="1.35714" stroke-linecap="round" stroke-linejoin="round"/>
        <Path fill-rule="evenodd" clip-rule="evenodd" d="M9.5 1.08203C2.66006 1.08203 1.50454 2.01403 1.50454 9.51103C1.50454 17.904 1.33641 20.082 3.04559 20.082C4.7537 20.082 7.54344 16.398 9.5 16.398C11.4566 16.398 14.2463 20.082 15.9544 20.082C17.6636 20.082 17.4955 17.904 17.4955 9.51103C17.4955 2.01403 16.3399 1.08203 9.5 1.08203Z" stroke="#130F26" stroke-width="1.35714" stroke-linecap="round" stroke-linejoin="round"/>
        </Svg>
    </View>
  )
}

export default wishlist_off