import App from './app/index';
import 'expo-dev-client';


export default App;
