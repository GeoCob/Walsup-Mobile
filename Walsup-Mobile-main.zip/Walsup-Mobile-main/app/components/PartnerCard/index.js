import { StyleSheet, Text, View, TouchableOpacity, Image } from 'react-native';
import React from 'react';
//server swithcer
import { serverSection } from '../../../config/servConf';
import { BaseColor, Fonts } from '../../../config/theme';
//thunks
import { useDispatch } from 'react-redux';
import { unSubscribeToPartner } from '../../store/social/socialThunk';
//Composant d'affichage de partenaire
const PartnerCard = (props) => {
  const dispatch = useDispatch();
  const { item, user, profileNavigation, subbed, tab } = props;
  return (
    <View key={item.uid} style={styles.main__container}>
      <TouchableOpacity style={styles.sub__container} onPress={() => profileNavigation({ ...item, subbed: subbed })}>
        <Image
          style={styles.image__main}
          source={{ uri: serverSection ? item.imageurl : item.imageurl.replace('localhost', '10.0.2.2') }}
        />
        <Text style={styles.text__title}>{item.name}</Text>
      </TouchableOpacity>
      {tab === 'abonnements' ? (
        <TouchableOpacity
          onPress={() => {
            //console.log('call to unSubscribe');
            dispatch(unSubscribeToPartner({ partner_uid: item.id, user_uid: user.uid }));
          }}
          style={styles.Button__main}
        >
          <Text style={styles.button__text}>Abonner</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
};

export default PartnerCard;

const styles = StyleSheet.create({
  main__container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '90%',
    height: 80,
    marginTop: 12,
    marginHorizontal: 20,
  },
  sub__container: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  image__main: {
    width: 30,
    height: 30,
    borderRadius: 60,
    marginRight: 20,
  },
  text__title: {
    fontSize: Fonts.font_XL,
    fontFamily: 'Poppins-Medium',
  },
  Button__main: {
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: BaseColor.fadedGrey,
    width: 100,
    height: 26,
    marginRight: 10,
    borderRadius: 8,
  },
  button__text: {
    fontSize: Fonts.font_normal,
    fontFamily: 'Poppins-SemiBold',
  },
});
