import { StyleSheet, Text, View, TouchableOpacity, Image } from 'react-native';
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Feather, FontAwesome } from '@expo/vector-icons';
import { serverSection } from '../../../config/servConf';
import { database } from '../../../config/firebase';
import { child, get, onValue, ref } from 'firebase/database';
import { useNavigation } from '@react-navigation/native';
import { getDiscussionData } from '../../store/social/socialThunk';
import { getGroupMembers } from '../../store/social/socialThunk';
//Composant de Card d'affichage d'un groupe
const GroupeCard = (props) => {
  //fetch des données d'un groupe depuis les props
  const { item, ModalVisibiltyToggle, type } = props;
  const navigation = useNavigation();
  const dispatch = useDispatch();
  //Appel aux membres de groupes et loader de s membres depuis le store social
  const { GroupMembers, GroupMembersLoader } = useSelector((store) => store.social);
  //fonction de navigation vers le chat de groupe
  const handleChatGroupeNavigation = async (groupeId, membersData) => {
    console.log('groupe data id ===>', groupeId);
    console.log('groupe members data ==>', membersData);
    //fethc de données des membres depuis le reducer de fetch de données de membres
    const members = membersData;
    dispatch(getGroupMembers(members));
    //restructuration des membres
    let groupeMembersObject = GroupMembers.reduce((acc, item) => {
      acc[item.uid] = item;
      return acc;
    }, {});

    console.log(groupeMembersObject[membersData[0]].uid);
    //si les membres sont bien structuré
    if (groupeMembersObject[membersData[0]].uid) {
      //navigation vers la discussion
      navigation.navigate('Discussion', {
        conversationId: groupeId,
        GroupMembers: groupeMembersObject,
        recieverData: item,
        type: 'groupe',
      });
    }
  };
  //
  useEffect(() => {
    console.log('hello jingle ===>', item);
  }, []);

  return type === 'groupesProfil' ? (
    <View key={item.id} style={styles.Group}>
      <TouchableOpacity style={styles.GroupInfo} onPress={() => {}}>
        <Image style={styles.Groupsimage} source={{ uri: item.group_img.replace('localhost', '10.0.2.2') }} />
        <Text style={styles.GroupName}>{item.name}</Text>
      </TouchableOpacity>
      {/* <TouchableOpacity>
        <Feather
          name="more-vertical"
          size={20}
          style={styles.threeDotsIcon}
          onPress={() => ModalVisibiltyToggle(item)}
        />
      </TouchableOpacity> */}
    </View>
  ) : (
    <View key={item.id} style={styles.Group}>
      <TouchableOpacity
        style={styles.GroupInfo}
        onPress={() => {
          handleChatGroupeNavigation(item.id, item.member_ids);
        }}
      >
        <Image style={styles.Groupsimage} source={{ uri: item.group_img.replace('localhost', '10.0.2.2') }} />
        <Text style={styles.GroupName}>{item.name}</Text>
      </TouchableOpacity>
      <TouchableOpacity>
        <Feather
          name="more-vertical"
          size={20}
          style={styles.threeDotsIcon}
          onPress={() => ModalVisibiltyToggle(item)}
        />
      </TouchableOpacity>
    </View>
  );
};

export default GroupeCard;

const styles = StyleSheet.create({
  Group: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 70,
    width: '100%',
    marginLeft: 15,
  },
  GroupInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    position: 'relative',
    width: '80%',
  },
  Groupsimage: {
    width: 50,
    height: 50,
    borderRadius: 40,
    zIndex: 2,
  },
  Groupsimage2: {
    position: 'absolute',
    left: 32,
    top: 0,
    width: 28,
    height: 28,
    borderRadius: 40,
  },
  GroupName: {
    height: 40,
    marginTop: 22,
    fontFamily: 'Poppins-Medium',
    width: '100%',
    fontSize: 13,
    marginLeft: 20,
    textAlign: 'left',
  },
  threeDotsIcon: {
    position: 'absolute',
    top: -10,
    right: 30,
    color: 'rgba(53, 47, 132, 1)',
  },
});
