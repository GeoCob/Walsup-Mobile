import React, { useEffect, useState } from 'react';
import { Text, View, TouchableOpacity, Image, Pressable } from 'react-native';
import { useSelector, useDispatch } from 'react-redux';
import { likeCommercialOffer, unlikeCommercialOffer } from '../../store/commercialOffers/commercialOffersThunk';
import { likeAdvertisingOffer, unLikeAdvertisingOffer } from '../../store/postNews/postNewsThunk';
//images assets for socials
import Swiper from 'react-native-swiper';
import styles from './style';
import { BaseColor, Fonts } from '../../../config/theme';
import CounterMarket from '../CounterMarket';
import Feather from 'react-native-vector-icons/Feather';
import AntDesign from 'react-native-vector-icons/AntDesign';
import Ionicons from 'react-native-vector-icons/Ionicons';
//server switcher
import { serverSection } from '../../../config/servConf';
import WishlistSvg from '../../../assets/Icons/components/WishlistSvg';
// C:\Users\moham\OneDrive\Documents\apps\bkh projects\walsup_source_of_truth01\Walsup_Mobile\
// C:\Users\moham\OneDrive\Documents\apps\bkh projects\walsup_source_of_truth01\Walsup_Mobile\app\components\OffersCards\index.js

//Composant card d'offre commercial
const OfferComCard = ({ user, item, timer, endDate, partners, navigation, offer_type }) => {
  //declaration d'une variable dans le state pour l'état de j'aime d'utilisateur connecté
  const [like, setLike] = useState(item.user_has_liked);
  //Declaration d'une variable dans le state pour le nombre de j'aime d'une offre
  const [likeCount, setLikeCount] = useState(item.likes);
  //Declaration d'une variable dans le state pour le nombre des commentaires
  const [commentsCount, setCommentsCount] = useState(item.comments_count);
  //Declaration d'une variable dans le state pour les données de l'offre
  const [product, setProduct] = useState({ ...item });
  //Declaration d'une variable dans le state pour la wishlist (non developpée)
  const [wishlist, setWishlist] = useState(false);
  const [actualDate, setActualDate] = useState(new Date());
  const [endingDate, setEndingDate] = useState(new Date(endDate));
  const [timeDifference, setTimeDifference] = useState((endingDate - actualDate) / 1000);
  //Fonction de navigation vers le details de l'offre
  const handleID = (type, scrollActive) => {
    if (type) {
      navigation.navigate('OfferDetails', {
        userID: user.uid,
        userImage: user.profile_image,
        userfirstName: user.last_name,
        userLastName: user.first_name ? user.first_name : '',
        data: product,
        partnerName: partners[product.partner_id].name ? partners[product.partner_id].name : 'Partner Name',
        partnerImge: partners[product.partner_id].imageurl ? partners[product.partner_id].imageurl : '',
        scrollToCom: scrollActive,
      });
    } else {
      navigation.navigate('PostDetails', {
        userID: user.uid,
        userImage: user.profile_image,
        userfirstName: user.last_name,
        userLastName: user.first_name ? user.first_name : '',
        data: product,
        partnerName: partners[product.partner_id].name ? partners[product.partner_id].name : 'Partner Name',
        partnerImge: partners[product.partner_id].imageurl ? partners[product.partner_id].imageurl : '',
        scrollToCom: scrollActive,
      });
    }
  };
  //Appel au loader des offres
  const { loadingLike } = useSelector((store) => store.commercialOffers);
  const { loadingAdsLike } = useSelector((store) => store.postNews);
  const dispatch = useDispatch();
  useEffect(() => {
    setLike(item.user_has_liked);
    // console.log(product.title, "===>", timeDifference);
  }, []);
  return (
    <View style={styles.cardContainer}>
      <View style={styles.partnerTab}>
        {/* main partner tab */}
        <View style={styles.partnerTab}>
          {/* logo and partner name */}
          <Image
            style={styles.partnerLogo}
            source={
              partners && product.partner_id
                ? {
                    uri: serverSection
                      ? partners[product.partner_id].imageurl
                      : partners[product.partner_id].imageurl.toString().replace('localhost', '10.0.2.2'),
                  }
                : require('../../../assets/GoogleIcon.png')
            }
          />
          <Text style={{ marginStart: 12 }}>
            {partners && product.partner_id ? partners[product.partner_id].name : 'Partner Name'}
          </Text>
        </View>
        <View style={styles.optionPartnerContainer}>
          {/* Option Btn */}
          {/* <TouchableOpacity style={styles.optionPartnerContainer}>
            <Image style={styles.OptionBtn} source={require('../../../assets/Icons/Bullets.png')} />
          </TouchableOpacity> */}
        </View>
      </View>
      <View style={styles.mainCarrousel}>
        {/* carrousell view */}
        <Swiper dotColor={BaseColor.fadedGrey} activeDotStyle={{ width: 28 }} activeDotColor={BaseColor.primaryColor}>
          {product.offer_imgs.map((imageData, index) => (
            <Pressable key={index} onPress={() => handleID(offer_type, false)}>
              <Image
                style={styles.carrousel}
                key={index}
                source={
                  imageData.length > 0
                    ? { uri: serverSection ? imageData : imageData.replace('localhost', '10.0.2.2') }
                    : require('../../../assets/placeholderImage.png')
                }
              />
            </Pressable>
          ))}
        </Swiper>
      </View>
      <View style={styles.socials__container}>
        {/* social interaction view */}
        <View>
          {/* like and counter =0 */}
          <Pressable
            style={styles.mainSocials}
            onPress={() => {
              if (loadingLike || loadingAdsLike) return;
              if (like) {
                setLike((prevState) => !prevState);
                setLikeCount((prevState) => prevState - 1);
                if (timer) {
                  dispatch(unlikeCommercialOffer({ user_id: user.uid, offer_id: product.offer_id }));
                  setProduct((prevState) => ({ ...prevState, user_has_liked: false, likes: prevState.likes - 1 }));
                } else {
                  dispatch(unLikeAdvertisingOffer({ user_id: user.uid, ads_id: product.offer_id }));
                  setProduct((prevState) => ({ ...prevState, user_has_liked: false, likes: prevState.likes - 1 }));
                }
              } else {
                setLike((prevState) => !prevState);
                setLikeCount((prevState) => prevState + 1);
                if (timer) {
                  dispatch(likeCommercialOffer({ user_id: user.uid, offer_id: product.offer_id }));
                  setProduct((prevState) => ({ ...prevState, user_has_liked: true, likes: prevState.likes + 1 }));
                } else {
                  dispatch(likeAdvertisingOffer({ user_id: user.uid, ads_id: product.offer_id }));
                  setProduct((prevState) => ({ ...prevState, user_has_liked: true, likes: prevState.likes + 1 }));
                }
              }
            }}
          >
            {!like ? (
              <AntDesign name="hearto" size={22} color={BaseColor.backMain} />
            ) : (
              <AntDesign name="heart" size={22} color={BaseColor.redheart} />
            )}
            <Text style={styles.socialGapText}>{likeCount ? likeCount : 0}</Text>
          </Pressable>
        </View>
        <View>
          {/* Comments and counter =0 */}
          <TouchableOpacity style={styles.mainSocials} onPress={() => handleID(offer_type, true)}>
            <Ionicons name="chatbubble-ellipses-outline" size={24.6} color={BaseColor.backMain} />
            <Text style={styles.socialGapText}>{commentsCount ? commentsCount : 0}</Text>
          </TouchableOpacity>
        </View>
        <View>
          {/* Shares and counter =0 */}
          <TouchableOpacity style={styles.mainSocials}>
            <Feather name="share-2" size={22} color={BaseColor.backMain} />
            <Text style={styles.socialGapText}>0</Text>
          </TouchableOpacity>
        </View>
        <View>
          {/* Wishlist and counter =0 */}
          {timer ? (
            <TouchableOpacity
              style={styles.mainSocials}
              onPress={() => {
                setWishlist((prevState) => !prevState);
              }}
            >
              {!wishlist ? (
                <WishlistSvg scale={{ width: 20, height: 29 }} />
              ) : (
                <WishlistSvg scale={{ width: 20, height: 29 }} />
              )}
              <Text style={styles.socialGapText}>0</Text>
            </TouchableOpacity>
          ) : null}
        </View>
      </View>
      {/* end of social section interactions */}
      <View style={styles.titleSectionContainer}>
        {/* title and counter */}
        <View
          style={{
            flexWrap: 'wrap',
            width: timer ? 170 : '90%',
          }}
        >
          {/* title */}
          <Pressable onPress={() => handleID(offer_type, false)}>
            <Text style={styles.titleText}>
              {product.title?.length > 38 ? `${product.title.substring(0, 38)}...` : product.title}
            </Text>
          </Pressable>
        </View>
        {timer ? (
          <View>
            {/* counter */}
            <CounterMarket
              key={product.offer_id}
              timestamp={timeDifference}
              title={item.title}
              textStyle={{
                fontSize: 25,
                color: `${BaseColor.primaryColor}`,
                fontFamilly: 'Poppins-Medium',
                letterSpacing: 0.25,
              }}
            />
          </View>
        ) : null}
      </View>
      <View style={styles.descriptContainer}>
        {/* description */}
        <Text style={styles.descriptText}> {`${product.description.substr(0, 60)}...`} </Text>
      </View>
    </View>
  );
};

export default OfferComCard;
