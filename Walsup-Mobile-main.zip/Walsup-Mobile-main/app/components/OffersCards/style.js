import { StyleSheet, Dimensions } from 'react-native';
import { BaseColor } from '../../../config/theme';

const { width, height } = Dimensions.get('window');
export default StyleSheet.create({
  cardContainer: {
    height: 560,
    borderRadius: 10,
    paddingVertical: 6,
    paddingBottom: 12,
    marginHorizontal: 12,
    marginVertical: 12,
    borderColor: '#6858DD',
    backgroundColor: '#ffffff',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
    elevation: 2,
  },
  partnerTab: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 4,
    marginTop: 1,
    marginBottom: 4,
  },
  partnerLogo: {
    width: 48,
    height: 48,
    borderRadius: 100,
    borderColor: BaseColor.fadedGrey,
    borderWidth: 2,
  },
  optionPartnerContainer: {
    justifyContent: 'center',
    alignContent: 'center',
  },
  OptionBtn: {
    width: 21,
    height: 21,
    resizeMode: 'contain',
  },
  //Carroucel styles sections
  mainCarrousel: {
    width: '100%',
    height: 338,
    justifyContent: 'center',
    alignItems: 'center',
  },
  carrousel: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  //social buttons styles section
  socials__container: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    height: 48,
  },
  mainSocials: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    height: 48,
    paddingHorizontal: width * 0.056,
  },
  socialunit: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  socialIcons: {
    width: 24,
    height: 28,
    resizeMode: 'contain',
  },
  socialGapText: {
    marginLeft: 12,
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
  },
  //Title and counter section
  titleSectionContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 12,
    marginTop: 10,
  },
  titleText: {
    fontSize: 14.4,
    fontFamily: 'Poppins-Medium',
  },
  titleTextFull: {},
  titleCounter: {
    width: 108,
    resizeMode: 'contain',
  },
  //description section
  descriptContainer: {
    justifyContent: 'space-between',
    paddingHorizontal: 8,
    marginTop: 10,
  },
  descriptText: {
    color: '#8C8C8C',
  },
});
