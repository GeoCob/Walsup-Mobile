import { Text, StyleSheet, View, Image, TouchableOpacity } from 'react-native';
import React, { Component } from 'react';
import CustomButton from '../Button';
import { useNavigation } from '@react-navigation/native';
import { useDispatch } from 'react-redux';
import { FollowUser, getfollowedUsers, getUnfollowedUsers } from '../../store/social/socialThunk';

const SuggestionAmiCard = ({ item, user }) => {
  const dispatch = useDispatch();
  const navigation = useNavigation();
  //Fonction de navigation vers profile utilisateur
  const ProfileHandler = () => {
    navigation.navigate('ProfileSocial', { item: item, IsFriend: 'Suggestion' });
  };
  //Fonction d'envois d'invitation d'amitié
  const AjouerAmi = () => {
    const data = { sender_id: user.uid, requested_id: item.uid };
    dispatch(FollowUser(data));
  };

  return (
    <View key={item.uid} style={styles.Suggestion}>
      <TouchableOpacity onPress={() => ProfileHandler()}>
        <View style={styles.SuggestionInfo}>
          <Image
            style={styles.SuggestionImage}
            source={
              item.profile_image
                ? { uri: item.profile_image.toString().replace('localhost', '10.0.2.2') }
                : require('../../../assets/profile.png')
            }
          />
          <Text style={styles.SuggstionName}>
            {item.first_name && item.last_name ? item.first_name + ' ' + item.last_name : 'Prenom Nom'}
          </Text>
          <CustomButton
            title={'Ajouter'}
            onPress={() => {
              AjouerAmi();
            }}
            style={[styles.Button, item ? { right: 0 } : { right: -30 }]}
          />
        </View>
      </TouchableOpacity>
    </View>
  );
};
export default SuggestionAmiCard;

const styles = StyleSheet.create({
  SuggestionInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: 5,
    marginTop: 5,
    backgroundColor: '#ffff',
    width: 270,
    borderRadius: 10,
  },
  Suggestion: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 62,
    width: 278,
    backgroundColor: '#0000',
    borderRadius: 10,
    marginHorizontal: 10,
    elevation: 5,
    shadowColor: 'rgba(105, 89, 222, 0.6)',
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowOpacity: 0.6,
    shadowRadius: 10,
  },
  SuggestionImage: { width: 42, height: 42, borderRadius: 40, marginVertical: 5, marginRight: 10, marginLeft: 10 },
  SuggstionName: {
    width: 100,
    height: 20,
    marginVertical: 21,
    fontFamily: 'Poppins-Medium',
    fontSize: 13,
    lineHeight: 20,
  },
  Button: {
    borderRadius: 5,
    marginRight: 20,
  },
});
