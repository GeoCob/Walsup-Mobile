import React from 'react';
import { useNavigation } from '@react-navigation/native';
import { TouchableOpacity, Image } from 'react-native';
//Composant de button de retour
const Back = () => {
  const navigation = useNavigation();
  return (
    <TouchableOpacity onPress={() => navigation.goBack()}>
      <Image source={require('../../../assets/back.png')} style={{ width: 30, height: 30, top: 10 }} />
    </TouchableOpacity>
  );
};

export default Back;
