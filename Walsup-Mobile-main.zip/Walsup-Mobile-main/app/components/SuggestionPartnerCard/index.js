import { Text, StyleSheet, View, Image, TouchableOpacity } from 'react-native';
import React, { Component } from 'react';
import CustomButton from '../Button';
import { useDispatch } from 'react-redux';
import { subscribeToPartner } from '../../store/social/socialThunk';
//Composant d'afficahge de suggestion de partenaire
const SuggestionPartnerCard = (props) => {
  const { item, user, profileNavigation, subbed } = props;
  // console.log(user);
  const dispatch = useDispatch();
  // onPress={() => profileNavigation({...item, subbed : subbed})}
  return (
    <View key={item.uid} style={styles.Suggestion}>
      <View style={styles.SuggestionInfo}>
        <TouchableOpacity onPress={() => profileNavigation({ ...item, subbed: subbed })}>
          <Image
            style={styles.SuggestionImage}
            source={
              item.imageurl
                ? { uri: item.imageurl.toString().replace('localhost', '10.0.2.2') }
                : require('../../../assets/profile.png')
            }
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => profileNavigation({ ...item, subbed: subbed })}>
          <Text style={styles.SuggstionName}>{item.name ? item.name : 'Partenaire'}</Text>
        </TouchableOpacity>
        <CustomButton
          title={"S'abonner"}
          onPress={() => {
            //console.log('call to subscruibe');
            dispatch(subscribeToPartner({ sender_id: user.uid, requested_id: item.id }));
          }}
          style={[styles.Button, item ? { right: 0 } : { right: -30 }]}
        />
      </View>
    </View>
  );
};
export default SuggestionPartnerCard;

const styles = StyleSheet.create({
  SuggestionInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: 5,
    marginTop: 5,
    backgroundColor: '#ffff',
    width: 270,
    borderRadius: 10,
  },
  Suggestion: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 62,
    width: 278,
    backgroundColor: '#0000',
    borderRadius: 10,
    marginHorizontal: 10,
    elevation: 5,
    shadowColor: 'rgba(105, 89, 222, 0.6)',
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowOpacity: 0.6,
    shadowRadius: 10,
  },
  SuggestionImage: { width: 42, height: 42, borderRadius: 40, marginVertical: 5, marginRight: 10, marginLeft: 10 },
  SuggstionName: {
    width: 100,
    height: 20,
    marginVertical: 21,
    fontFamily: 'Poppins-Medium',
    fontSize: 13,
    lineHeight: 20,
  },
  Button: {
    borderRadius: 5,
    marginRight: 20,
  },
});
