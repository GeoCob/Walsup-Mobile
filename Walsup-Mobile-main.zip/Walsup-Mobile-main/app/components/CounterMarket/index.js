/**
 * CountDownTimer Component
 */

import React, { useState, useEffect, useRef, forwardRef, useImperativeHandle } from 'react';
import { Text, View, Image, ActivityIndicator } from 'react-native';
//css
import { Mascotts, Logo } from '../../../config/Images';
import { BaseColor, Fonts } from '../../../config/theme';

const CounterMarket = forwardRef((props, ref) => {
  // For Total seconds
  const [timeStamp, setTimeStamp] = useState(props.timestamp ? props.timestamp : 0);
  // Delay Required
  const [delay, setDelay] = useState(props.delay ? props.delay : 1000);

  // For days, hours, minutes and seconds
  const [months, setMonths] = useState(props.months ? props.months : 0);
  const [days, setDays] = useState(props.days ? props.days : 0);
  const [hours, setHours] = useState(props.hours ? props.hours : 0);
  const [minutes, setMinutes] = useState(props.minutes ? props.minutes : 0);
  const [seconds, setSeconds] = useState(props.seconds ? props.seconds : 0);

  // Flag for informing parent component when timer is over
  const [sendOnce, setSendOnce] = useState(true);

  // Flag for final display time format
  const [finalDisplayTime, setFinalDisplayTime] = useState('');

  // useEffect(() => {
  //   console.log(
  //     'MARKET---->',
  //     props.title,
  //     timeStamp,
  //     '--',
  //     months,
  //     '--',
  //     days,
  //     '--',
  //     hours,
  //     '--',
  //     minutes,
  //     '--',
  //     seconds,
  //     '--',
  //     finalDisplayTime
  //   );
  // }, [finalDisplayTime]);

  useInterval(() => {
    if (timeStamp > 0) {
      setTimeStamp(timeStamp - 1);
    } else if (sendOnce) {
      if (props.timerCallback) {
        props.timerCallback(true);
      } else {
        console.log('Please pass a callback function...');
      }
      setSendOnce(false);
    }

    let delta = timeStamp;
    //calculate (and substarct) whole month
    let months = Math.floor(delta / 2629743);
    delta -= months * 2629743;

    // calculate (and subtract) whole days
    let days = Math.floor(delta / 86400);
    delta -= days * 86400;

    // calculate (and subtract) whole hours
    let hours = Math.floor(delta / 3600) % 24;
    delta -= hours * 3600;

    // calculate (and subtract) whole minutes
    let minutes = Math.floor(delta / 60) % 60;
    delta -= minutes * 60;

    // what's left is seconds
    let seconds = delta % 60;
    // console.log(seconds);
    setMonths(months);
    setDays(days);
    setHours(hours);
    setMinutes(minutes);
    setSeconds(seconds);

    // Formatting Time for Display Purpose
    const month = months < 10 ? `0${months}` : months;
    const day = days < 10 ? `0${days}` : days;
    const hr = hours < 10 ? `0${hours}` : hours;
    const min = minutes < 10 ? `0${minutes}` : minutes;
    const sec = seconds < 10 ? `0${seconds}` : seconds;

    let displayTime = '';
    if (timeStamp > 2629743) {
      displayTime = `${month}${day}${hr}`;
    }
    if (2629743 > timeStamp && timeStamp > 86400) {
      displayTime = `${day}${hr}${min}`;
    }

    if (86400 > timeStamp && timeStamp > 3600) {
      displayTime = `${hr}${min}${sec}`;
    }

    if (3600 > timeStamp && timeStamp > 60) {
      displayTime = `00${min}${sec}`;
    }

    if (timeStamp < 60) {
      displayTime = `0000${sec}`;
    }

    setFinalDisplayTime(displayTime);
  }, delay);

  const refTimer = useRef();
  useImperativeHandle(ref, () => ({
    resetTimer: () => {
      // Clearing days, hours, minutes and seconds
      setMonths(props.months);
      setDays(props.days);
      setHours(props.hours);
      setMinutes(props.minutes);
      setSeconds(props.seconds);
      // Clearing Timestamp
      setTimeStamp(props.timestamp);
      setSendOnce(true);
    },
  }));

  // useEffect(() => {
  //   console.log(props.title, '====> ', timeStamp, '///', finalDisplayTime);
  // }, []);

  return (
    <View>
      {finalDisplayTime ? (
        <View
          ref={refTimer}
          style={{
            position: 'relative',
            flexDirection: 'row',
            width: 146,
            height: 42,
            backgroundColor: BaseColor.primarydark,
            justifyContent: 'center',
            alignItems: 'center',
            borderRadius: 10,
          }}
        >
          <Image
            style={{
              position: 'absolute',
              left: -10,
              width: 52,
              resizeMode: 'contain',
              padding: 0,
              margin: 0,
            }}
            source={Mascotts.timer_guy}
          />
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
              marginLeft: 34,
            }}
          >
            <View
              // first section container
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                marginHorizontal: 4,
              }}
            >
              <View>
                <Text
                  style={{
                    color: BaseColor.white,
                    fontSize: Fonts.font_XL,
                    fontFamily: 'Poppins-SemiBold',
                  }}
                >
                  {finalDisplayTime.slice(0, 2)}
                </Text>
              </View>
              <Text
                style={{
                  color: BaseColor.white,
                  fontSize: Fonts.font_small,
                  fontFamily: 'Poppins-SemiBold',
                }}
              >
                {timeStamp > 2629743 ? 'Mois' : 2629743 > timeStamp && timeStamp > 86400 ? 'Jours' : 'Heurs'}
              </Text>
            </View>
            <View
              // second section container
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                marginHorizontal: 4,
              }}
            >
              <View>
                <Text
                  style={{
                    color: BaseColor.white,
                    fontSize: Fonts.font_XL,
                    fontFamily: 'Poppins-SemiBold',
                  }}
                >
                  {finalDisplayTime.slice(2, 4)}
                </Text>
              </View>
              <Text
                style={{
                  color: BaseColor.white,
                  fontSize: Fonts.font_small,
                  fontFamily: 'Poppins-SemiBold',
                }}
              >
                {timeStamp > 2629743 ? 'Jours' : 2629743 > timeStamp && timeStamp > 86400 ? 'Heurs' : 'Min'}
              </Text>
            </View>
            <View
              // third section container
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                marginHorizontal: 4,
              }}
            >
              <View>
                <Text
                  style={{
                    color: BaseColor.white,
                    fontSize: Fonts.font_XL,
                    fontFamily: 'Poppins-SemiBold',
                  }}
                >
                  {finalDisplayTime.slice(4, 6)}
                </Text>
              </View>
              <Text
                style={{
                  color: BaseColor.white,
                  fontSize: Fonts.font_small,
                  fontFamily: 'Poppins-SemiBold',
                }}
              >
                {timeStamp > 2629743 ? 'Heurs' : 2629743 > timeStamp && timeStamp > 86400 ? 'Min' : 'Sec'}
              </Text>
            </View>
          </View>
          <Image
            style={{
              position: 'absolute',
              right: 0,
              width: 72,
              resizeMode: 'contain',
              margin: 0,
              padding: 0,
            }}
            source={Logo.timer_logo}
          />
        </View>
      ) : (
        <View
          style={{
            position: 'relative',
            flexDirection: 'row',
            width: 145,
            height: 42,
            backgroundColor: BaseColor.primarydark,
            justifyContent: 'center',
            alignItems: 'center',
            borderRadius: 10,
          }}
        >
          <ActivityIndicator size={38} color={BaseColor.primaryLight} />
          <Image
            style={{
              position: 'absolute',
              left: -12,
              width: 52,
              resizeMode: 'contain',
              padding: 0,
              margin: 0,
            }}
            source={Mascotts.timer_guy}
          />
          <Image
            style={{
              position: 'absolute',
              right: 0,
              width: 72,
              resizeMode: 'contain',
              margin: 0,
              padding: 0,
            }}
            source={Logo.timer_logo}
          />
        </View>
      )}
    </View>
  );
});

function useInterval(callback, delay) {
  const savedCallback = useRef();

  // Remember the latest function.
  useEffect(() => {
    savedCallback.current = callback;
  }, [callback]);

  // Set up the interval.
  useEffect(() => {
    function tick() {
      savedCallback.current();
    }
    if (delay !== null) {
      const id = setInterval(tick, delay);
      return () => {
        clearInterval(id);
      };
    }
  }, [delay]);
}

export default CounterMarket;
