import React from 'react';
import { Text, View, TouchableOpacity, Image, FlatList, SafeAreaView, ActivityIndicator } from 'react-native';
//css and assets
import styles from './style';
import { Mascotts } from '../../../config/Images';
//Composant qui s'affiche lorsque il n y a pas d'invitation ou suggestions
const NoSocialData = (props) => {
  const { Description } = props;
  return (
    <SafeAreaView style={styles.mainContainer}>
      <View style={styles.mascotContainer}>
        <Image style={styles.mascott} source={require('../../../assets/AUCUN_OFFRE_1.png')} />
      </View>
      <Text style={styles.textHmmm}>Hmmm......</Text>
      <Text style={styles.textDescription}>{Description}</Text>
    </SafeAreaView>
  );
};

export default NoSocialData;
