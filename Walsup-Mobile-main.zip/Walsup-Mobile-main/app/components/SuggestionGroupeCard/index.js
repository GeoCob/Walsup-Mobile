import { StyleSheet, Text, View, TouchableOpacity, Image } from 'react-native';
import { useDispatch } from 'react-redux';
import React from 'react';
import CustomButton from '../Button';
import { RejoindreGroup } from '../../store/social/socialThunk';
//Composant d'affichage de suggestion de groupe
const SuggestionGroupeCard = ({ item, user }) => {
  const dispatch = useDispatch();
  return (
    <View key={item.id} style={styles.Suggestion}>
      <View style={styles.SuggestionInfo}>
        <Image
          style={styles.SuggestionImage}
          source={
            item?.group_img
              ? { uri: item.group_img.toString().replace('localhost', '10.0.2.2') }
              : require('../../../assets/profile.png')
          }
        />
        <Text style={styles.SuggstionName}>{item.name}</Text>
        <CustomButton
          title={'Rejoindre'}
          onPress={() => {
            const data = { sender_id: user.uid, receiver_id: item.user_admin_id, group_id: item.id };
            dispatch(RejoindreGroup(data));
          }}
          style={[styles.Button, item ? { right: 0 } : { right: -30 }]}
        />
      </View>
    </View>
  );
};

export default SuggestionGroupeCard;

const styles = StyleSheet.create({
  SuggestionInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginHorizontal: 5,
    marginTop: 5,
    backgroundColor: '#ffff',
    width: 270,
    borderRadius: 10,
  },
  Suggestion: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 62,
    width: 278,
    backgroundColor: '#0000',
    borderRadius: 10,
    marginHorizontal: 10,
    elevation: 5,
    shadowColor: 'rgba(105, 89, 222, 0.6)',
    shadowOffset: {
      width: 0,
      height: 0,
    },
    shadowOpacity: 0.6,
    shadowRadius: 10,
  },
  SuggestionImage: { width: 42, height: 42, borderRadius: 40, marginVertical: 5, marginRight: 15, marginLeft: 10 },
  SuggstionName: {
    width: 100,
    height: 20,
    marginVertical: 21,
    fontFamily: 'Poppins-Medium',
    fontSize: 13,
    lineHeight: 20,
  },
  Amisimage2: {
    position: 'absolute',
    left: 32,
    top: 10,
    width: 20,
    height: 20,
    borderRadius: 40,
  },
  Button: {
    borderRadius: 5,
    marginRight: 20,
  },
});
