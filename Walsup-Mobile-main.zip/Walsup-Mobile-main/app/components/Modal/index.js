import { Text, StyleSheet, View, Image, TouchableOpacity } from 'react-native';
import {
  child,
  get,
  getDatabase,
  onValue,
  ref,
  push,
  serverTimestamp,
  set,
  off,
  update,
  runTransaction,
  increment,
  remove,
} from 'firebase/database';
import React, { Component, useState } from 'react';
import Modal from 'react-native-modal';
import { useEffect } from 'react';
import { Divider } from '@rneui/themed';
import CustomButton from '../Button';
import { Feather, Entypo, AntDesign, Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import {
  RemoveUserFromFriends,
  RemoveUserFromGroup,
  FollowUser,
  RemoveMemberFromGroup,
} from '../../store/social/socialThunk';
import { useDispatch } from 'react-redux';

//Composant de tous les modals dans la partie social
const ModalComponent = (props) => {
  //fetch de données de props
  const { isModalVisible, type, ModalVisibiltyToggle, item, user, group } = props;
  //Declaration de variable dans le state pour le toggle de type de groupe (offre/social)
  const [groupeOfferCheck, setGroupeOfferCheck] = useState(true);
  const [groupeSocialCheck, setGroupeSocialCheck] = useState(false);
  const navigation = useNavigation();
  const dispatch = useDispatch();
  //Fonction de toggle de type de groupe (offre)
  //Fonction de toggle de type de groupe (offre)
  const checkOfferHandler = () => {
    if (groupeSocialCheck) {
      setGroupeSocialCheck(false);
      setGroupeOfferCheck(true);
    } else {
      setGroupeSocialCheck(true);
      setGroupeOfferCheck(false);
    }
  };
  //Fonction de toggle de type de groupe (social)
  const checkSocialHandler = () => {
    if (groupeOfferCheck) {
      setGroupeOfferCheck(false);
      setGroupeSocialCheck(true);
    } else {
      setGroupeSocialCheck(true);
      setGroupeOfferCheck(false);
    }
  };
  //Fonction onsubmit pour naviguer vest la selection d'amis
  const OnSubmit = () => {
    if (groupeSocialCheck && !groupeOfferCheck) {
      navigation.navigate('SelectFriends', { GroupeType: 'Social', type: type });
    } else if (!groupeSocialCheck && groupeOfferCheck) {
      navigation.navigate('SelectFriends', { GroupeType: 'Offer', type: type });
    }
    ModalVisibiltyToggle();
  };
  //Fonction de suppression d'ami de la liste des amis
  const RemoveFriend = async () => {
    const data = {
      sender_id: user.uid,
      requested_id: item.uid,
    };
    dispatch(RemoveUserFromFriends(data));
    // to remove a friend
    // remove the discution between the tow parts compare Id and remove
    // remove the messages with comared ID
    const discutionId = user.uid > item.uid ? `${user.uid}${item.uid}` : `${item.uid}${user.uid}`;
    const dbRef = ref(getDatabase());
    const updates = {};
    try {
      updates['privateChatConversation/' + user.uid + '/' + discutionId] = null;
      updates['privateChatConversation/' + item.uid + '/' + discutionId] = null;
      updates['PrivateMessages/' + discutionId] = null;
      //console.log(updates);
      await update(dbRef, updates);
    } catch (error) {
      console.log(error);
    }
    ModalVisibiltyToggle();
  };
  //Fonction d'expulsion d'un membre d'un groupe
  const KickMember = async () => {
    const data = {
      uid: item.uid,
      group_id: group.id,
    };
    dispatch(RemoveMemberFromGroup(data));
    const db = getDatabase();
    try {
      const removeItem = await remove(ref(db, `privateChatConversation/${item.uid}/${group.id}`));
    } catch (error) {
      console.log(error);
    }
    ModalVisibiltyToggle();
  };
  //Fonction d'ajout d'un ami
  const AddFriend = () => {
    const data = {
      sender_id: user.uid,
      requested_id: item.uid,
    };
    dispatch(FollowUser(data));
    ModalVisibiltyToggle();
  };
  //Fonction de quitter groupe
  const QuitGroupe = async () => {
    const data = {
      uid: user.uid,
      group_id: item.id,
    };
    const dbRef = ref(getDatabase());
    const updates = {};
    try {
      updates['privateChatConversation/' + user.uid + '/' + item.id] = null;
      await update(dbRef, updates);
    } catch (error) {
      console.log(error);
    }
    dispatch(RemoveUserFromGroup(data));
    ModalVisibiltyToggle();
  };
  //Fonction de navigation vers profile utilisateur
  const ViewProfile = () => {
    if (item) {
      navigation.navigate('ProfileSocial', { item: item });
      ModalVisibiltyToggle();
    }
  };
  //Fonction d'invit au groupe
  const InviteToGroup = () => {
    if (item) {
      navigation.navigate('SelectFriends', { doing: 'Invite', item: item });
      ModalVisibiltyToggle();
    }
  };
  //Fonction d'affichage des membres
  const ShowMembers = () => {
    if (item) {
      navigation.navigate('SelectFriends', { doing: 'Members', item: item });
      ModalVisibiltyToggle();
    }
  };
  //Fonction d'envois de demande de rejoindre un groupe
  const JoinGroup = () => {
    if (item) {
      const data = { sender_id: user.uid, receiver_id: item.user_admin_id, group_id: item.id };
      dispatch(RejoindreGroup(data));
      ModalVisibiltyToggle();
    }
  };

  return (
    <View>
      <Modal
        animationIn="slideInUp"
        animationOut="slideOutDown"
        isVisible={isModalVisible}
        style={{ margin: 0, justifyContent: 'flex-start' }}
        backdropOpacity={type != 'groupesChatProfile' ? 0.3 : 0.6}
        coverScreen={true}
        onBackdropPress={() => ModalVisibiltyToggle()}
      >
        <View
          style={
            type != 'groupesChatProfile'
              ? {
                  marginTop: 'auto',
                  backgroundColor: 'white',
                  marginBottom: -10,
                  flex: 0.3,
                  borderRadius: 20,
                  alignItems: 'center',
                }
              : {
                  marginTop: '50%',
                  width: 170,
                  backgroundColor: '#0000',
                  alignSelf: 'center',
                  flex: 0.35,
                  borderRadius: 20,
                  alignItems: 'center',
                }
          }
        >
          {type === 'groupeCreate' ? (
            <View style={styles.container}>
              <Divider
                inset={true}
                insetType="middle"
                width={5}
                color="rgba(217, 217, 217, 1)"
                style={{ height: 5, width: 49, alignSelf: 'center', marginTop: 10 }}
              />
              <Text style={styles.horizontalText}>Créer une novelle discussion de groupe</Text>
              <TouchableOpacity style={styles.TextIconContainer} onPress={() => checkOfferHandler()}>
                <Text style={[styles.text, groupeOfferCheck ? { color: 'rgba(105, 89, 222, 1)' } : null]}>
                  Groupe offre
                </Text>
                <Feather
                  name="check"
                  size={20}
                  style={groupeOfferCheck ? { color: 'rgba(105, 89, 222, 1)' } : { display: 'none' }}
                />
              </TouchableOpacity>
              <Divider
                insetType="middle"
                width={1}
                color="rgba(242, 242, 242, 1)"
                style={{
                  height: 0,
                  width: 340,
                  alignSelf: 'center',
                  marginTop: 5,
                  marginBottom: 5,
                  marginEnd: -23,
                }}
              />
              <TouchableOpacity style={styles.TextIconContainer} onPress={() => checkSocialHandler()}>
                <Text style={[styles.text, groupeSocialCheck ? { color: 'rgba(105, 89, 222, 1)' } : null]}>
                  Groupe social
                </Text>
                <Feather
                  name="check"
                  size={20}
                  style={groupeSocialCheck ? { color: 'rgba(105, 89, 222, 1)' } : { display: 'none' }}
                />
              </TouchableOpacity>
              <CustomButton
                title="Suivant"
                Textstyle={
                  groupeSocialCheck || groupeOfferCheck ? styles.ButtonTextTriggered : styles.ButtonTextDefault
                }
                style={groupeSocialCheck || groupeOfferCheck ? styles.ButtonTriggered : styles.ButtonDefault}
                onPress={OnSubmit}
              />
            </View>
          ) : type === 'amis' ? (
            <View style={styles.container}>
              <Divider
                inset={true}
                insetType="middle"
                width={5}
                color="rgba(217, 217, 217, 1)"
                style={{ height: 5, width: 49, alignSelf: 'center', marginTop: 10 }}
              />
              <Text style={styles.horizontalText}>{item ? item.first_name + ' ' + item.last_name : null}</Text>
              <TouchableOpacity style={styles.TextIconProfileContainer} onPress={ViewProfile}>
                <Entypo
                  name="eye"
                  size={20}
                  style={{
                    color: 'rgba(105, 89, 222, 1)',
                    marginRight: 10,
                    backgroundColor: 'rgba(242, 242, 242, 1)',
                    borderRadius: 50,
                    padding: 5,
                  }}
                />
                <Text style={[styles.textProfile]}>Voir Profile</Text>
              </TouchableOpacity>
              <Divider
                insetType="middle"
                width={1}
                color="rgba(242, 242, 242, 1)"
                style={{
                  height: 0,
                  width: 340,
                  alignSelf: 'center',
                  marginTop: 5,
                  marginBottom: 5,
                  marginEnd: -23,
                }}
              />
              <TouchableOpacity style={styles.TextIconProfileContainer} onPress={RemoveFriend}>
                <Feather
                  name="user-x"
                  size={20}
                  style={{
                    color: 'rgba(243, 62, 62, 1)',
                    marginRight: 10,
                    backgroundColor: 'rgba(242, 242, 242, 1)',
                    borderRadius: 50,
                    padding: 2,
                  }}
                />
                <Text style={[styles.textProfile, { color: 'rgba(243, 62, 62, 1)' }]}>Retirer des amis</Text>
              </TouchableOpacity>
            </View>
          ) : type === 'groupes' ? (
            <View style={styles.container}>
              <Divider
                inset={true}
                insetType="middle"
                width={5}
                color="rgba(217, 217, 217, 1)"
                style={{ height: 5, width: 49, alignSelf: 'center', marginTop: 10 }}
              />
              <Text style={styles.horizontalText}>{item ? item.name : null}</Text>
              <TouchableOpacity style={styles.TextIconProfileContainer} onPress={() => ShowMembers()}>
                <Feather
                  name="users"
                  size={20}
                  style={{
                    color: 'rgba(105, 89, 222, 1)',
                    marginRight: 10,
                    backgroundColor: 'rgba(242, 242, 242, 1)',
                    borderRadius: 50,
                    padding: 5,
                  }}
                />
                <Text style={[styles.textProfile]}>Voir Membres</Text>
              </TouchableOpacity>
              <Divider
                insetType="middle"
                width={1}
                color="rgba(242, 242, 242, 1)"
                style={{
                  height: 0,
                  width: 340,
                  alignSelf: 'center',
                  marginTop: 5,
                  marginBottom: 5,
                  marginEnd: -23,
                }}
              />
              <TouchableOpacity style={styles.TextIconProfileContainer} onPress={() => InviteToGroup()}>
                <AntDesign
                  name="addusergroup"
                  size={20}
                  style={{
                    color: 'rgba(105, 89, 222, 1)',
                    marginRight: 10,
                    backgroundColor: 'rgba(242, 242, 242, 1)',
                    borderRadius: 50,
                    padding: 5,
                  }}
                />
                <Text style={[styles.textProfile]}>Inviter</Text>
              </TouchableOpacity>
              <Divider
                insetType="middle"
                width={1}
                color="rgba(242, 242, 242, 1)"
                style={{
                  height: 0,
                  width: 340,
                  alignSelf: 'center',
                  marginTop: 5,
                  marginBottom: 5,
                  marginEnd: -23,
                }}
              />
              <TouchableOpacity style={styles.TextIconProfileContainer} onPress={() => QuitGroupe()}>
                <Ionicons
                  name="exit-outline"
                  size={20}
                  style={{
                    color: 'rgba(243, 62, 62, 1)',
                    marginRight: 10,
                    backgroundColor: 'rgba(242, 242, 242, 1)',
                    borderRadius: 50,
                    padding: 2,
                  }}
                />
                <Text style={[styles.textProfile, { color: 'rgba(243, 62, 62, 1)' }]}>Quitter le groupe</Text>
              </TouchableOpacity>
            </View>
          ) : type === 'groupesChat' ? (
            <View style={styles.container}>
              <Divider
                inset={true}
                insetType="middle"
                width={5}
                color="rgba(217, 217, 217, 1)"
                style={{ height: 5, width: 49, alignSelf: 'center', marginTop: 10 }}
              />
              <Text style={styles.horizontalText}>{item ? item.name : null}</Text>
              <TouchableOpacity style={styles.TextIconProfileContainer} onPress={() => ShowMembers()}>
                <Feather
                  name="users"
                  size={20}
                  style={{
                    color: 'rgba(105, 89, 222, 1)',
                    marginRight: 10,
                    backgroundColor: 'rgba(242, 242, 242, 1)',
                    borderRadius: 50,
                    padding: 5,
                  }}
                />
                <Text style={[styles.textProfile]}>Voir Membres</Text>
              </TouchableOpacity>
              <Divider
                insetType="middle"
                width={1}
                color="rgba(242, 242, 242, 1)"
                style={{
                  height: 0,
                  width: 340,
                  alignSelf: 'center',
                  marginTop: 5,
                  marginBottom: 5,
                  marginEnd: -23,
                }}
              />
              <TouchableOpacity style={styles.TextIconProfileContainer} onPress={() => InviteToGroup()}>
                <AntDesign
                  name="addusergroup"
                  size={20}
                  style={{
                    color: 'rgba(105, 89, 222, 1)',
                    marginRight: 10,
                    backgroundColor: 'rgba(242, 242, 242, 1)',
                    borderRadius: 50,
                    padding: 5,
                  }}
                />
                <Text style={[styles.textProfile]}>Inviter</Text>
              </TouchableOpacity>
              <Divider
                insetType="middle"
                width={1}
                color="rgba(242, 242, 242, 1)"
                style={{
                  height: 0,
                  width: 340,
                  alignSelf: 'center',
                  marginTop: 5,
                  marginBottom: 5,
                  marginEnd: -23,
                }}
              />
            </View>
          ) : type === 'groupesChatProfile' ? (
            <View style={styles.container}>
              <Image
                style={styles.image}
                source={
                  item ? (item.group_img ? { uri: item.group_img } : require('../../../assets/profile.png')) : null
                }
              />
              <Text style={styles.horizontalTextChatGroupeProfile}>{item ? item.name : null}</Text>
            </View>
          ) : type === 'amisProfil' ? (
            <View style={styles.container}>
              <Divider
                inset={true}
                insetType="middle"
                width={5}
                color="rgba(217, 217, 217, 1)"
                style={{ height: 5, width: 49, alignSelf: 'center', marginTop: 10 }}
              />
              <Text style={styles.horizontalText}>{item ? item.first_name + ' ' + item.last_name : null}</Text>
              <TouchableOpacity style={styles.TextIconProfileContainer} onPress={ViewProfile}>
                <Entypo
                  name="eye"
                  size={20}
                  style={{
                    color: 'rgba(105, 89, 222, 1)',
                    marginRight: 10,
                    backgroundColor: 'rgba(242, 242, 242, 1)',
                    borderRadius: 50,
                    padding: 5,
                  }}
                />
                <Text style={[styles.textProfile]}>Voir Profile</Text>
              </TouchableOpacity>
              <Divider
                insetType="middle"
                width={1}
                color="rgba(242, 242, 242, 1)"
                style={{
                  height: 0,
                  width: 340,
                  alignSelf: 'center',
                  marginTop: 5,
                  marginBottom: 5,
                  marginEnd: -23,
                }}
              />
              <TouchableOpacity
                style={styles.TextIconProfileContainer}
                onPress={() => {
                  AddFriend();
                }}
              >
                <Ionicons
                  name="person-add-sharp"
                  size={20}
                  style={{
                    color: 'rgba(105, 89, 222, 1)',
                    marginRight: 18,
                    backgroundColor: 'rgba(242, 242, 242, 1)',
                    borderRadius: 50,
                    padding: 2,
                  }}
                />
                <Text style={[styles.textProfile]}>Ajouter</Text>
              </TouchableOpacity>
            </View>
          ) : type === 'groupesProfil' ? (
            <View style={styles.container}>
              <Divider
                inset={true}
                insetType="middle"
                width={5}
                color="rgba(217, 217, 217, 1)"
                style={{ height: 5, width: 49, alignSelf: 'center', marginTop: 10 }}
              />
              <Text style={styles.horizontalText}>{item ? item.name : null}</Text>
              <TouchableOpacity style={styles.TextIconProfileContainer} onPress={() => JoinGroup()}>
                <Ionicons
                  name="add-circle-outline"
                  size={20}
                  style={{
                    color: 'rgba(105, 89, 222, 1)',
                    marginRight: 10,
                    backgroundColor: 'rgba(242, 242, 242, 1)',
                    borderRadius: 50,
                    padding: 5,
                  }}
                />
                <Text style={[styles.textProfile]}>Rejoindre</Text>
              </TouchableOpacity>
            </View>
          ) : type === '+' ? (
            <View style={styles.container}>
              <Divider
                inset={true}
                insetType="middle"
                width={5}
                color="rgba(217, 217, 217, 1)"
                style={{ height: 5, width: 49, alignSelf: 'center', marginTop: 10 }}
              />
              <Text style={styles.horizontalText}>{item ? item.first_name + ' ' + item.last_name : null}</Text>
              <TouchableOpacity style={styles.TextIconProfileContainer} onPress={RemoveFriend}>
                <Feather
                  name="user-x"
                  size={20}
                  style={{
                    color: 'rgba(243, 62, 62, 1)',
                    marginRight: 10,
                    backgroundColor: 'rgba(242, 242, 242, 1)',
                    borderRadius: 50,
                    padding: 2,
                  }}
                />
                <Text style={[styles.textProfile, { color: 'rgba(243, 62, 62, 1)' }]}>Retirer des amis</Text>
              </TouchableOpacity>
            </View>
          ) : type === 'Members' ? (
            <View style={styles.container}>
              <Divider
                inset={true}
                insetType="middle"
                width={5}
                color="rgba(217, 217, 217, 1)"
                style={{ height: 5, width: 49, alignSelf: 'center', marginTop: 10 }}
              />
              <Text style={styles.horizontalText}>{item ? item.first_name + ' ' + item.last_name : null}</Text>
              <TouchableOpacity style={styles.TextIconProfileContainer} onPress={KickMember}>
                <AntDesign
                  name="deleteusergroup"
                  size={20}
                  style={{
                    color: 'rgba(243, 62, 62, 1)',
                    marginRight: 10,
                    backgroundColor: 'rgba(242, 242, 242, 1)',
                    borderRadius: 50,
                    padding: 2,
                  }}
                />
                <Text style={[styles.textProfile, { color: 'rgba(243, 62, 62, 1)' }]}>Supprimer du Groupe</Text>
              </TouchableOpacity>
            </View>
          ) : null}
        </View>
      </Modal>
    </View>
  );
};
export default ModalComponent;

const styles = StyleSheet.create({
  container: {
    flexDirection: 'column',
    alignSelf: 'flex-start',
    width: '80%',
    marginLeft: 30,
  },
  TextIconContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  TextIconProfileContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  ButtonDefault: {
    alignSelf: 'center',
    width: 196,
    height: 36,
    borderRadius: 10,
    marginTop: 25,
    marginBottom: 18,
    backgroundColor: 'rgba(242, 242, 242, 1)',
  },
  ButtonTriggered: {
    alignSelf: 'center',
    width: 196,
    height: 36,
    borderRadius: 10,
    marginTop: 25,
    marginBottom: 18,
    backgroundColor: 'rgba(105, 89, 222, 1)',
  },
  ButtonTextDefault: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    lineHeight: 27,
    alignSelf: 'center',
    color: 'black',
  },
  ButtonTextTriggered: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 18,
    lineHeight: 27,
    alignSelf: 'center',
    color: 'white',
  },
  text: {
    fontSize: 13,
    lineHeight: 24,
    fontFamily: 'Poppins-SemiBold',
    height: 24,
    marginVertical: 2,
  },
  textProfile: {
    fontFamily: 'Poppins-Regular',
    fontSize: 12,
    lineHeight: 18,
  },
  horizontalText: {
    textAlign: 'center',
    fontSize: 15,
    marginTop: 10,
    width: 311,
    height: 23,
    marginBottom: 15,
    fontFamily: 'Poppins-SemiBold',
    lineHeight: 22,
    color: 'rgba(51, 51, 51, 1)',
  },

  image: {
    width: 170,
    height: 170,
    borderRadius: 0,
    alignSelf: 'center',
    marginTop: 10,
    marginRight: 10,
  },
  horizontalTextChatGroupeProfile: {
    textAlign: 'center',
    fontSize: 20,
    marginTop: 10,
    marginRight: 10,
    marginBottom: 15,
    fontFamily: 'Poppins-Bold',
    lineHeight: 30,
    color: 'white',
  },
});
