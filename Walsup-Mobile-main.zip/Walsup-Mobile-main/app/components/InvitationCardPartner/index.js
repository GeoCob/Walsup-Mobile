import { Text, StyleSheet, View, Image, TouchableOpacity } from 'react-native';
import React, { Component, useEffect } from 'react';
import CustomButton from '../Button';
import { useDispatch } from 'react-redux';
import { subscribeToPartner } from '../../store/social/socialThunk';

//Composant de carde de partenaire
const InvitationCardPartner = (props) => {
  const { item, profileNavigation, subbed, user } = props;
  const dispatch = useDispatch();
  //console.log(user);
  return (
    <View key={item.id} style={styles.Suggestion}>
      <View style={styles.SuggestionInfo}>
        <TouchableOpacity onPress={() => profileNavigation({ ...item, subbed: subbed })}>
          <Image
            style={styles.SuggestionImage}
            source={
              item.imageurl
                ? { uri: item.imageurl.toString().replace('localhost', '10.0.2.2') }
                : require('../../../assets/profile.png')
            }
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => profileNavigation({ ...item, subbed: subbed })}>
          <Text style={styles.SuggstionNameSent}>{item.name ? item.name : 'Partenairesss'}</Text>
        </TouchableOpacity>
        <CustomButton
          title={" S'abonner "}
          onPress={() => {
            // handlePartnerSub(item.id);
            dispatch(subscribeToPartner({ sender_id: user.uid, requested_id: item.id }));
          }}
          style={[styles.AcceptButton]}
          Textstyle={{ color: 'white' }}
        />
      </View>
    </View>
  );
};
export default InvitationCardPartner;

const styles = StyleSheet.create({
  SuggestionInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 5,
    height: 62,
    width: 278,
    marginHorizontal: 10,
  },
  Suggestion: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  SuggestionImage: { width: 50, height: 50, borderRadius: 40, marginBottom: 8, marginRight: 11, marginLeft: 5 },
  SuggstionName: {
    width: 75,
    height: 20,
    marginTop: 15,
    marginBottom: 23,
    fontFamily: 'Poppins-Medium',
    fontSize: 13,
    lineHeight: 20,
  },
  SuggstionNameSent: {
    width: 75,
    height: 20,
    marginTop: 15,
    marginBottom: 23,
    fontFamily: 'Poppins-Medium',
    fontSize: 13,
    lineHeight: 20,
    marginLeft: -57,
  },
  ButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  AcceptButton: {
    position: 'relative',
    right: -65,
    marginHorizontal: 5,
  },
});
