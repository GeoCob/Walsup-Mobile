import { Text, StyleSheet, View, Image, TouchableOpacity } from 'react-native';
import React, { Component } from 'react';
import { useEffect } from 'react';

//Composant de selection d'offre dans la creation de group d'offre
const OffreCardGroupe = (props) => {
  //fetch des données de props
  const { offre, partner, setSelectedOffer, OfferIsSelected, setGroupImage } = props;
  //Fonction de seelction de l'offre
  const handlePress = () => {
    setSelectedOffer(offre.offer_id);
    setGroupImage(offre.offer_imgs[0]);
  };
  return (
    <>
      <TouchableOpacity onPress={() => handlePress()}>
        <View
          style={[
            styles.container,
            OfferIsSelected(offre.offer_id) ? { backgroundColor: 'rgba(105, 89, 222, 1)' } : null,
          ]}
        >
          <Image source={{ uri: offre.offer_imgs[0].replace('localhost', '10.0.2.2') }} style={styles.offreImage} />

          <View style={styles.offerDetailsContainer}>
            <Text style={[styles.Title, OfferIsSelected(offre.offer_id) ? { color: 'white' } : null]}>
              {offre.title}
            </Text>
            <View style={styles.partnerInfoContainer}>
              <Text style={[styles.PartnerNameText, OfferIsSelected(offre.offer_id) ? { color: 'white' } : null]}>
                {partner.partnerName}
              </Text>
              <Text style={[styles.CashbackText, OfferIsSelected(offre.offer_id) ? { color: 'white' } : null]}>
                Cashback <Text style={styles.CashbackValue}>108.00€</Text>
              </Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    </>
  );
};
export default OffreCardGroupe;

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignContent: 'center',
    height: 55,
    width: 330,
    marginTop: 5,
    borderRadius: 10,
  },
  offerDetailsContainer: {
    marginTop: 5,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignContent: 'flex-start',
    width: 225,
    height: 45,
  },
  partnerInfoContainer: { flexDirection: 'row', justifyContent: 'space-between', alignContent: 'flex-start' },
  offreImage: { width: 45, height: 45, borderRadius: 80, marginHorizontal: 20, marginTop: 5 },
  Title: { fontFamily: 'Poppins-SemiBold', fontSize: 13, lineHeight: 19.5 },
  PartnerNameText: { fontFamily: 'Poppins-Regular', fontSize: 13, lineHeight: 19.5, color: 'rgba(133, 133, 133, 1)' },
  CashbackText: { color: 'rgba(51, 51, 51, 1)', fontFamily: 'Poppins-Light', fontSize: 8, lineHeight: 24 },
  CashbackValue: { color: 'rgba(250, 112, 11, 1)', fontFamily: 'Poppins-SemiBold', fontSize: 10, lineHeight: 24 },
});
