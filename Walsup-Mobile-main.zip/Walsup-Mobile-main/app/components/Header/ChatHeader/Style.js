import { StyleSheet } from 'react-native';
export default StyleSheet.create({
  container: {
    width: '100%',
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    paddingTop: '8%',
    justifyContent: 'space-between',
    marginTop: 0,
  },

  text: {
    fontFamily:'Poppins-Bold',
    top: 7,
    fontSize: 20,
  },
  back: {
    bottom: 7,
    left: 2,
  },
  profile: {
    position: 'absolute',
    top: 10,
    left: 70,
    flexDirection: 'row',
    bottom: 10,
  },
  image: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginLeft: -23,
    marginRight: 5,
    zIndex: 2,
  },
  image2: {
    width: 25,
    height: 25,
    borderRadius: 20,
    marginLeft: -23,
    marginRight: 5,
  },
  menu: {
    width: 18,
    height: 18,
    marginLeft: 25,
    marginTop: -15,
  },
  left: {
    bottom: 15,
    right: 20,
    flexDirection: 'row',
    // width: 100,
  },
  notif: {
    left: 15,
  },
});
