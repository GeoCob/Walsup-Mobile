import React from 'react';
import { Text, View, TouchableOpacity, Image, SafeAreaView, TouchableWithoutFeedback } from 'react-native';
import Style from './Style';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import Feather from 'react-native-vector-icons/Feather';
//server swithcer
import NewMessageIcon from '../../../../assets/Icons/components/NewMessageIcon';
import { Divider } from '@rneui/themed';
import { useDispatch, useSelector } from 'react-redux';
import { ClearChatData, pushChatData, clearGroupemebersData } from '../../../store/social/socialSlice';
import { upadatePrivateChatRecieverData, clearPrivateChatRecieverData } from '../../../store/social/privateChatSlice';
import { useEffect } from 'react';
import { useCallback } from 'react';
import { useState } from 'react';
import ModalComponent from '../../Modal';

//Composant de header dans la partie chat
const ChatHeader = (props) => {
  // fetch de données depuis les props
  const { title, goBackTo, hideBackButton, showIcon, navigation, params } = props;
  //Appel aux données d'utilisateur qu'on discute avec depuis le store privatechat
  const { privateChatRecieverData } = useSelector((store) => store.privateChat);
  //appel aux données d'uitilisateur depuis le store d'authentification
  const { user } = useSelector((store) => store.authentification);
  const dispatch = useDispatch();
  //Declaration d'une variable dans le state pour la visibilité de modal
  const [isModalVisible, setisModalVisible] = useState(false);
  //Declaration d'une variable dans le state pour l'ami à supprimer
  const [FriendRemove, setFriendRemove] = useState(null);
  //Declaration d'une variable dans le state pour le groupe
  const [group, setGroup] = useState(null);
  //Declaration d'une variable dans le state pour la modification de popup( modal )
  const [GroupPopUpModifier, setGroupPopUpModifier] = useState(false);

  useEffect(() => {
    if (params != null) {
      console.log(params);
    }
  }, [params]);

  //Fonction de retour et reset de données
  const ongoBack = (Screen) => {
    dispatch(ClearChatData());
    dispatch(clearPrivateChatRecieverData());
    dispatch(clearGroupemebersData());
    navigation.navigate(Screen);
  };
  //Fonction de toggle de visibilité de modal de group
  const ModalVisibiltyToggleGroup = (grp) => {
    setGroupPopUpModifier(false);
    setisModalVisible(!isModalVisible);
    setGroup(grp);
  };
  //Fonction de toggle de visibilité de modal de profile de groupe
  const ModalVisibiltyToggleGroupProfile = (grp) => {
    setGroupPopUpModifier(true);
    setisModalVisible(!isModalVisible);
    setGroup(grp);
  };
  //Fonction de toggle de visibilité de modal des membres de groupe
  const ModalVisibiltyToggle = (friend) => {
    setisModalVisible(!isModalVisible);
    setFriendRemove(friend);
  };

  return (
    <>
      <SafeAreaView style={Style.container}>
        {/* section menu */}
        <View style={Style.back}>
          {!hideBackButton && (
            <TouchableOpacity onPress={() => ongoBack(goBackTo)}>
              <Feather name="chevron-left" color="#130F26" size={30} style={Style.back} />
            </TouchableOpacity>
          )}
        </View>

        {showIcon && title === 'Discussions' ? (
          <View style={Style.profile}>
            <Image
              style={Style.image}
              source={
                privateChatRecieverData?.uid
                  ? privateChatRecieverData?.profile_image
                    ? { uri: privateChatRecieverData.profile_image }
                    : require('../../../../assets/profile.png')
                  : null
              }
            />
            <Text style={Style.text}>
              {privateChatRecieverData?.name ? privateChatRecieverData?.name : null}
              {privateChatRecieverData.first_name || privateChatRecieverData.last_name
                ? privateChatRecieverData.first_name + ' ' + privateChatRecieverData.last_name
                : null}
              {!privateChatRecieverData?.id || !privateChatRecieverData?.uid ? title : null}
            </Text>
          </View>
        ) : (
          <TouchableOpacity
            onPress={() => ModalVisibiltyToggleGroupProfile(params.recieverData)}
            disabled={params && params.type != 'groupe'}
            style={Style.profile}
          >
            <Image
              style={Style.image}
              source={
                privateChatRecieverData?.uid
                  ? privateChatRecieverData?.profile_image
                    ? { uri: privateChatRecieverData.profile_image }
                    : require('../../../../assets/profile.png')
                  : null
              }
            />
            <Text style={Style.text}>
              {privateChatRecieverData?.name ? privateChatRecieverData?.name : null}
              {privateChatRecieverData.first_name || privateChatRecieverData.last_name
                ? privateChatRecieverData.first_name + ' ' + privateChatRecieverData.last_name
                : null}
              {!privateChatRecieverData?.id || !privateChatRecieverData?.uid ? title : null}
            </Text>
          </TouchableOpacity>
        )}

        {showIcon && title === 'Discussions' ? (
          <View style={Style.left}>
            <TouchableOpacity onPress={() => navigation.navigate('CreateChat')}>
              <NewMessageIcon scale={{ width: 25, height: 25, stroke: 1.75 }} />
            </TouchableOpacity>
          </View>
        ) : (
          <View style={Style.left}>
            <TouchableOpacity>
              <Feather
                name="more-vertical"
                size={25}
                style={{ alignSelf: 'center' }}
                onPress={() => {
                  if (params && params?.type === 'groupe') {
                    ModalVisibiltyToggleGroup(params.recieverData);
                  } else {
                    ModalVisibiltyToggle(params.recieverData);
                  }
                }}
              />
            </TouchableOpacity>
          </View>
        )}
      </SafeAreaView>
      <Divider insertType="middle" orientation="horizontal" width={1} style={{ width: '100%' }} color="#F2F2F2" />
      {GroupPopUpModifier ? (
        <ModalComponent
          item={group}
          user={user}
          isModalVisible={isModalVisible}
          ModalVisibiltyToggle={ModalVisibiltyToggleGroupProfile}
          type={'groupesChatProfile'}
        />
      ) : (
        <ModalComponent
          item={params && params?.type === 'groupe' ? group : FriendRemove}
          user={user}
          isModalVisible={isModalVisible}
          ModalVisibiltyToggle={params && params?.type === 'groupe' ? ModalVisibiltyToggleGroup : ModalVisibiltyToggle}
          type={params && params?.type === 'groupe' ? 'groupesChat' : 'amis'}
        />
      )}
    </>
  );
};

export default ChatHeader;
