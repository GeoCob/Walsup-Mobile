import { StyleSheet } from 'react-native';
export default StyleSheet.create({
  container: {
    width: '100%',
    flexDirection: 'row',
    backgroundColor: '#ffffff',
    paddingTop: '8%',
    justifyContent: 'space-between',
    marginTop: 0,
  },

  text: {
    fontFamily: 'Poppins-Bold',
    //fontWeight: 'bold',
    top: 5,
    fontSize: 20,
    marginLeft: 10,
  },
  back: {
    bottom: 7,
    left: 2,
  },
  profile: {
    position: 'absolute',
    top: 10,
    left: 55,
    flexDirection: 'row',
    bottom: 10,
  },
  image: {
    zIndex: 0,
    width: 40,
    height: 40,
    borderRadius: 20,
    marginLeft: -23,
  },
  menu: {
    width: 18,
    height: 18,
    marginLeft: 25,
    marginTop: -15,
  },
  left: {
    bottom: 15,
    left: 20,
    flexDirection: 'row',
    width: 100,
  },
  notif: {
    left: 15,
  },
});
