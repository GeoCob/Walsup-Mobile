import React, { useState } from 'react';
import { Text, View, TouchableOpacity, Image, SafeAreaView, TouchableWithoutFeedback, StyleSheet } from 'react-native';
import { child, get, getDatabase, onValue, ref, push, serverTimestamp, set, off } from 'firebase/database';
import Style from './Style';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { useSelector } from 'react-redux';
import Feather from 'react-native-vector-icons/Feather';
import MessageIcon from '../../../assets/Icons/components/MessageIcon';
//server swithcer
import { serverSection } from '../../../config/servConf';
import NotifSVG from '../../../assets/Icons/components/NotifSVG';
import DrawerSVG from '../../../assets/Icons/components/DrawerSVG';
// css
import { BaseColor, Fonts } from '../../../config/theme';
import { useCallback } from 'react';

//Composant de header principal
const Header = (props) => {
  const { user } = useSelector((store) => store.authentification);

  const { title, goBackTo, hideBackButton, showImg = true } = props;
  const navigation = useNavigation();
  const [badges, setBadge] = useState(0);

  const ongoBack = (Screen) => {
    navigation.navigate(Screen);
  };

  const openMenu = () => {
    navigation.openDrawer();
  };
  useFocusEffect(
    useCallback(() => {
      const db = getDatabase();
      const dbRef = ref(db, `privateChatConversation/${user.uid}`);
      const callbackOnvalue = (snapShot) => {
        const value = snapShot.val();
        if (value) {
          const newData = Object.entries(value).map(([id, value]) => ({ id, ...value }));
          //console.log(newData);
          let sumOfBadges = newData.reduce((total, obj) => total + obj.badges, 0);
          setBadge(sumOfBadges);
        }
      };
      onValue(dbRef, callbackOnvalue);
      return () => off(dbRef, callbackOnvalue);
    }, [])
  );

  return (
    <SafeAreaView style={Style.container}>
      {/* section menu */}
      <View style={Style.back}>
        {!hideBackButton && (
          <TouchableOpacity onPress={() => ongoBack(goBackTo)}>
            <Feather name="chevron-left" color="#6959DE" size={30} style={Style.back} />
          </TouchableOpacity>
        )}
      </View>
      <View style={Style.profile}>
        <TouchableOpacity onPress={openMenu}>
          {showImg ? (
            <>
              <Image
                style={Style.image}
                source={
                  user.profile_image
                    ? { uri: serverSection ? user.profile_image : user.profile_image.replace('localhost', '10.0.2.2') }
                    : require('../../../assets/profile.png')
                }
              />
              <View style={{ zIndex: 1, position: 'absolute', top: '65%', left: '25%' }}>
                <DrawerSVG />
              </View>
            </>
          ) : null}
        </TouchableOpacity>

        <Text style={Style.text}>{title}</Text>
      </View>

      {/* section messag et notif */}
      <View style={Style.left}>
        <TouchableOpacity onPress={() => navigation.navigate('Chat')}>
          {/* <Image 
                  source={require('../../../assets/Icons/messagerie.png')} /> */}
          <MessageIcon scale={{ width: 25, height: 25, stroke: 1.75 }} />
          {/* notification counter */}
          {badges > 0 ? (
            <View style={styles.badgesNotifications}>
              <Text style={styles.badgesNotifications__text}>{badges > 9 ? '9+' : badges.toString()} </Text>
            </View>
          ) : null}
        </TouchableOpacity>
        <TouchableOpacity style={Style.notif} onPress={() => navigation.navigate('Notifications')}>
          <NotifSVG style={{ transform: 'rotate(180deg)' }} scale={{ width: 30, height: 30, stroke: 3 }} />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
};

export default Header;

const styles = StyleSheet.create({
  badgesNotifications: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: 18,
    height: 18,
    borderRadius: 50,
    backgroundColor: BaseColor.redheart,
    position: 'absolute',
    top: -5,
    left: -6,
  },
  badgesNotifications__text: {
    color: BaseColor.white,
    marginLeft: 4,
    fontSize: 11,
    fontWeight: Fonts.font_600,
  },
});
