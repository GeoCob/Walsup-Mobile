import React from 'react';
import { Text, View, TouchableOpacity, Image, SafeAreaView, TouchableWithoutFeedback } from 'react-native';
import Style from './style';
import { useNavigation } from '@react-navigation/native';
import { useSelector } from 'react-redux';
import Feather from 'react-native-vector-icons/Feather';

//Composant de header de drawer
const DrawerHeader = (props) => {
  const { title, goBackTo, background } = props;
  const navigation = useNavigation();

  const ongoBack = (Screen) => {
    navigation.navigate(Screen);
  };

  return (
    <SafeAreaView style={[Style.container, { backgroundColor: background }]}>
      {/* section menu */}
      <View style={Style.backContainer}>
        <TouchableOpacity onPress={() => ongoBack(goBackTo)}>
          <Feather name="chevron-left" color="black" size={28} style={Style.backIcon} />
        </TouchableOpacity>
      </View>
      <View style={Style.profile}>
        <Text style={Style.text}>{title}</Text>
      </View>

      {/* section messag et notif */}
    </SafeAreaView>
  );
};

export default DrawerHeader;
