import { StyleSheet } from 'react-native';
export default StyleSheet.create({
  container: {
    width: '100%',
    flexDirection: 'row',
    backgroundColor: '#0000',
    paddingTop: 15,
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
  },
  text: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 16,
    lineHeight: 24,
  },
  backContainer: { marginLeft: 20 },
  profile: { marginHorizontal: 27, height: 24 },
});
