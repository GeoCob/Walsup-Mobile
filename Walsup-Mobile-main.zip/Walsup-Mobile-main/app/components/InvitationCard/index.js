import { Text, StyleSheet, View, Image, TouchableOpacity } from 'react-native';
import React, { Component, useEffect } from 'react';
import CustomButton from '../Button';
import { useDispatch, useSelector } from 'react-redux';
import {
  AcceptReceivedFollow,
  DeclineReceivedFollow,
  DeleteSentRequest,
  FollowUser,
  GetFollowsReceived,
  GetFollowsSent,
  getfollowedUsers,
  getUnfollowedUsers,
} from '../../store/social/socialThunk';
import { useNavigation } from '@react-navigation/native';

//Composant de card d'invitation d'ami
const InvitationCard = (props) => {
  //fetch de données de props
  const { item, type } = props;
  //appel à l'utilisateur de store d'authnetification
  const { user } = useSelector((store) => store.authentification);
  const dispatch = useDispatch();
  const navigation = useNavigation();

  //Fonction de navigation vers profile d'utilisateur
  const ViewProfile = () => {
    navigation.navigate('ProfileSocial', { item: item, IsFriend: type });
  };

  //Fonction d'envois de demande d'amitié
  const SendRequest = () => {
    const data = {
      sender_id: user.uid,
      requested_id: item.uid,
    };
    dispatch(FollowUser(data));
  };

  //Fonction d'acceptation d'invitation reçue d'amitié
  const AcceptRequest = () => {
    const data = {
      sender_id: item.uid,
      requested_id: user.uid,
    };
    dispatch(AcceptReceivedFollow(data));
  };

  //Fonction de rejet d'invitation reçue d'amitié
  const DeclineRequest = () => {
    const data = {
      sender_id: item.uid,
      requested_id: user.uid,
    };
    dispatch(DeclineReceivedFollow(data));
  };

  //Fonction de suppression (annulation) d'invitation envoyée d'amitié
  const DeleteRequest = () => {
    const data = {
      sender_id: user.uid,
      requested_id: item.uid,
    };
    dispatch(DeleteSentRequest(data));
  };

  return (
    <View style={styles.Suggestion}>
      <View style={styles.SuggestionInfo}>
        <TouchableOpacity
          style={styles.ImageTextContainer}
          onPress={() => {
            ViewProfile();
          }}
        >
          <Image
            style={styles.SuggestionImage}
            source={
              item.profile_image
                ? { uri: item.profile_image.toString().replace('localhost', '10.0.2.2') }
                : require('../../../assets/profile.png')
            }
          />
          <Text style={type === 'received' ? styles.SuggstionName : styles.SuggstionNameSent}>
            {item.first_name && item.last_name ? item.first_name + ' ' + item.last_name : 'Prenom Nom'}
          </Text>
        </TouchableOpacity>
        {type === 'received' ? (
          <View style={styles.ButtonsContainer}>
            <CustomButton
              title={'Accepter'}
              onPress={AcceptRequest}
              style={[styles.AcceptButton]}
              Textstyle={{ color: 'white' }}
            />
            <CustomButton
              title={'Supprimer'}
              onPress={DeclineRequest}
              style={[styles.DeleteButton]}
              Textstyle={{ color: 'black' }}
            />
          </View>
        ) : type === 'sent' ? (
          <CustomButton
            title={'Annuler'}
            onPress={DeleteRequest}
            style={[styles.DeleteButtonSent]}
            Textstyle={{ color: 'black' }}
          />
        ) : (
          <CustomButton
            title={' Ajouter '}
            onPress={SendRequest}
            style={[styles.AddButton]}
            Textstyle={{ color: 'white' }}
          />
        )}
      </View>
    </View>
  );
};
export default InvitationCard;

const styles = StyleSheet.create({
  SuggestionInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 5,
    height: 62,
    width: '100%',
    marginHorizontal: 10,
  },
  Suggestion: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
  },
  SuggestionImage: {
    width: 50,
    height: 50,
    borderRadius: 40,
    marginBottom: 8,
    marginRight: 11,
    marginLeft: 0,
  },
  SuggstionName: {
    width: 200,
    height: 20,
    marginTop: 16,
    marginBottom: 23,
    fontFamily: 'Poppins-Medium',
    fontSize: 13,
    lineHeight: 20,
  },
  SuggstionNameSent: {
    width: 200,
    height: 20,
    marginTop: 15,
    marginBottom: 23,
    fontFamily: 'Poppins-Medium',
    fontSize: 13,
    lineHeight: 20,
  },
  ButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginLeft: -57,
    marginRight: 30,
  },
  AddButton: {
    marginRight: 30,
  },
  AcceptButton: {
    marginLeft: 0,
  },
  DeleteButton: {
    marginRight: 0,
    marginLeft: 7,
    backgroundColor: 'rgba(242, 242, 242, 1)',
  },
  DeleteButtonSent: {
    backgroundColor: 'rgba(242, 242, 242, 1)',
    marginRight: 30,
  },
  ImageTextContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignContent: 'center',
    position: 'relative',
  },
});
