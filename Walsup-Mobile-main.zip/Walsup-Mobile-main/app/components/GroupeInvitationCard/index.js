import { StyleSheet, Text, View, Image } from 'react-native';
import {
  child,
  get,
  getDatabase,
  onValue,
  ref,
  push,
  serverTimestamp,
  set,
  off,
  update,
  runTransaction,
  increment,
} from 'firebase/database';
import React from 'react';
import CustomButton from '../Button';
import { useDispatch, useSelector } from 'react-redux';
import {
  AcceptReceivedGroupInvite,
  DeclineReceivedGroupInvite,
  DeleteGroupeSentRequest,
  RejoindreGroup,
} from '../../store/social/socialThunk';

//Composant de card d'invitation de groupe
const GroupeInvitationCard = (props) => {
  //fetch de données depuis les props
  const { item, type, keys } = props;
  //appel à l'utilisateur depuis le store d'authentification
  const { user } = useSelector((store) => store.authentification);
  const dispatch = useDispatch();

  //Fonction d'envois de demande à un groupe
  const SendRequest = () => {
    const data = { sender_id: user.uid, receiver_id: item.user_admin_id, group_id: item.id };
    dispatch(RejoindreGroup(data));
  };

  //Fonction d'acceptation d'une invitation reçu à un groupe
  const AcceptRequest = async () => {
    const data = { sender_id: item.uid, receiver_id: item.user_admin_id, group_id: item.id };
    dispatch(AcceptReceivedGroupInvite(data));
    const dbRef = ref(getDatabase());
    try {
      //creation de la discussion
      const groupeLastData = await get(child(dbRef, `privateChatConversation/${item.user_admin_id}/${item.id}`));
      if (groupeLastData.exists()) {
        const result = groupeLastData.val();
        const updates = {};
        updates['privateChatConversation/' + item.uid + '/' + item.id + '/badges'] = 0;
        updates['privateChatConversation/' + item.uid + '/' + item.id + '/creationDate'] = serverTimestamp();
        updates['privateChatConversation/' + item.uid + '/' + item.id + '/group_img'] = result.group_img;
        updates['privateChatConversation/' + item.uid + '/' + item.id + '/groupeName'] = result.groupeName;
        updates['privateChatConversation/' + item.uid + '/' + item.id + '/lastMessage'] = result.lastMessage;
        updates['privateChatConversation/' + item.uid + '/' + item.id + '/lastMessageCreationDate'] =
          result.lastMessageCreationDate;
        //console.log(updates);
        await update(dbRef, updates);
      }
    } catch (error) {
      console.log(error);
    }
  };

  //Fonction de rejet d'une invitation à un groupe
  const DeclineRequest = () => {
    const data = { sender_id: item.uid, receiver_id: item.user_admin_id, group_id: item.id };
    dispatch(DeclineReceivedGroupInvite(data));
  };

  //Suppression (annulation) d'invitation à un groupe
  const DeleteRequest = () => {
    const data = { sender_id: user.uid, receiver_id: item.user_admin_id, group_id: item.group_id };
    dispatch(DeleteGroupeSentRequest(data));
  };

  return (
    <View style={styles.SuggestionInfo}>
      {type === 'received' ? (
        <Image
          style={styles.SuggestionImage}
          source={
            item.profile_image
              ? { uri: item.profile_image.toString().replace('localhost', '10.0.2.2') }
              : require('../../../assets/profile.png')
          }
        />
      ) : (
        <Image style={styles.Groupsimage} source={{ uri: item.group_img.replace('localhost', '10.0.2.2') }} />
      )}
      <View style={{ flexDirection: 'column' }}>
        <Text
          style={
            type === 'received'
              ? styles.SuggstionNameReceived
              : type === 'sent'
              ? styles.SuggstionNameSent
              : styles.SuggstionName
          }
        >
          {item.name}
        </Text>
        {type === 'received' ? (
          <Text style={{ fontFamily: 'Poppins-Medium', fontSize: 9, lineHeight: 21, marginLeft: 0 }}>
            {item.first_name + item.last_name}
          </Text>
        ) : null}
      </View>
      {type === 'received' ? (
        <View style={styles.ButtonsContainer}>
          <CustomButton
            title={'Accepter'}
            onPress={AcceptRequest}
            style={[styles.AcceptButton]}
            Textstyle={{ color: 'white' }}
          />
          <CustomButton
            title={'Supprimer'}
            onPress={DeclineRequest}
            style={[styles.DeleteButton]}
            Textstyle={{ color: 'black' }}
          />
        </View>
      ) : type === 'sent' ? (
        <CustomButton
          title={'Annuler'}
          onPress={DeleteRequest}
          style={[styles.DeleteButtonSent]}
          Textstyle={{ color: 'black' }}
        />
      ) : (
        <CustomButton
          title={'Rejoindre'}
          onPress={SendRequest}
          style={[styles.AddButton]}
          Textstyle={{ color: 'white' }}
        />
      )}
    </View>
  );
};
export default GroupeInvitationCard;

const styles = StyleSheet.create({
  SuggestionInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 5,
    height: 62,
    width: '100%',
  },
  SuggestionImage: { width: 50, height: 50, borderRadius: 40, marginBottom: 8, marginRight: 10, marginLeft: 20 },
  SuggstionNameReceived: {
    width: 75,
    height: 20,
    fontFamily: 'Poppins-Medium',
    fontSize: 13,
    lineHeight: 20,
    marginLeft: 0,
    alignSelf: 'center',
  },
  SuggstionName: {
    width: 75,
    height: 20,
    alignSelf: 'center',
    fontFamily: 'Poppins-Medium',
    fontSize: 13,
    lineHeight: 20,
    marginLeft: -100,
  },
  SuggstionNameSent: {
    width: 75,
    height: 20,
    fontFamily: 'Poppins-Medium',
    fontSize: 13,
    lineHeight: 20,
    marginLeft: -100,
    alignSelf: 'center',
  },
  Groupsimage: {
    width: 50,
    height: 50,
    borderRadius: 40,
    marginBottom: 8,
    marginLeft: 20,
  },
  Groupsimage2: {
    position: 'absolute',
    left: 32,
    top: 0,
    width: 28,
    height: 28,
    borderRadius: 40,
  },
  ButtonsContainer: {
    flexDirection: 'row',
    marginLeft: 20,
  },
  AddButton: {
    marginRight: 30,
  },
  AcceptButton: {
    marginRight: 10,
  },
  DeleteButton: {
    marginRight: 20,
    backgroundColor: 'rgba(242, 242, 242, 1)',
  },
  DeleteButtonSent: {
    backgroundColor: 'rgba(242, 242, 242, 1)',
    marginRight: 20,
  },
});
