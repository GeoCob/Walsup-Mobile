import React, { Component, useEffect, useState } from 'react';
import { Divider } from '@rneui/themed';
import { Feather, FontAwesome } from '@expo/vector-icons';
import { Text, TouchableOpacity, StyleSheet, Image, View } from 'react-native';
import { getDiscussionData } from '../../store/social/socialThunk';
//server switcher
import { serverSection } from '../../../config/servConf';
import { useNavigation } from '@react-navigation/native';
import { database } from '../../../config/firebase';
import { child, get, ref } from 'firebase/database';
import { useDispatch, useSelector } from 'react-redux';
//Card d'affichage d'ami
const AmiCard = (props) => {
  //fetch des données de props
  const {
    item,
    type,
    doing,
    selectedFriends,
    setSelectedFriends,
    ModalVisibiltyToggle,
    checkselectedFriends,
    selectedFriendsUids,
    setSelectedFriendsUids,
    group_admin_id,
  } = props;

  //Appel à l'utilsiateur depuis le store d'authentification
  const { user } = useSelector((store) => store.authentification);
  //Declaration d'une variable dans le state pour la verification si l'utilisateur connecté est different de l'utilisateur affiché le button s'affiche
  const [isButtonDisabled, setIsButtonDisabled] = useState(user.uid === item.uid);

  //Fonction de selection d'amis ( pour l'invitation groupe)
  const SelectUser = () => {
    if (checkselectedFriends(item)) {
      setSelectedFriends(selectedFriends.filter((e) => e !== item));
      setSelectedFriendsUids(selectedFriendsUids.filter((e) => e !== item.uid));
    } else {
      setSelectedFriends([...selectedFriends, item]);
      setSelectedFriendsUids([...selectedFriendsUids, item.uid]);
    }
  };

  const dispatch = useDispatch();
  const navigation = useNavigation();
  //Fonction de navigation vers profile d'un utilisateur
  const ProfileHandler = () => {
    navigation.navigate('ProfileSocial', { item: item });
  };

  //Fonction de navigation vers une discussion avec un ami
  const navigateToDiscussion = async (item) => {
    //Appel au reducer de fetch de données d'un discussion
    dispatch(getDiscussionData(item));
    //accées à la discussion dans la base
    const chatRef = ref(database, `chatRooms/${item.friend_request_id}/messages`);
    //fetch de données de la base
    const chatSnapshot = await get(child(chatRef, 'data'));
    if (!chatSnapshot) {
      // Creation de données et initialisation si il n y a pas de données dans la base
      await set(chatRef, {
        data: 'Default chat data',
      });
    }

    // Navigation à la  "Discussion" component si il y a de données déja ou bien crée
    navigation.navigate('Discussion', {
      chatId: item.friend_request_id,
    });
  };

  return (
    <>
      <View key={item.uid} style={styles.Ami}>
        {type === 'groupeCreate' || doing === 'Invite' ? (
          <>
            <TouchableOpacity onPress={() => SelectUser()}>
              <View style={styles.AmiInfo}>
                <Image
                  style={styles.Amisimage}
                  source={{
                    uri: serverSection ? item.profile_image : item.profile_image.replace('localhost', '10.0.2.2'),
                  }}
                />
                <Text style={styles.AmiName}>{item.first_name + ' ' + item.last_name}</Text>
              </View>
              <FontAwesome
                name="check-circle"
                size={20}
                style={[
                  styles.checkCircleIcon,
                  checkselectedFriends(item) ? { color: 'rgba(53, 47, 132, 1)' } : { color: 'rgba(217, 217, 217, 1)' },
                ]}
              />
            </TouchableOpacity>
          </>
        ) : doing === 'Members' ? (
          <>
            <TouchableOpacity style={styles.AmiInfo} onPress={() => ProfileHandler()} disabled={isButtonDisabled}>
              <Image
                style={styles.Amisimage}
                source={{
                  uri: serverSection ? item.profile_image : item.profile_image.replace('localhost', '10.0.2.2'),
                }}
              />
              <Text style={styles.AmiName}>{item.first_name + ' ' + item.last_name}</Text>
              <Text style={styles.MembreStatus}>{item.uid === group_admin_id ? 'Admin' : 'Membre'}</Text>
            </TouchableOpacity>
            <TouchableOpacity>
              {user.uid === group_admin_id ? (
                <Feather
                  name="more-vertical"
                  size={20}
                  style={styles.threeDotsIcon}
                  onPress={() => ModalVisibiltyToggle(item)}
                />
              ) : null}
            </TouchableOpacity>
          </>
        ) : type === 'amis' ? (
          <>
            <TouchableOpacity style={styles.AmiInfo} onPress={() => ProfileHandler()}>
              <Image
                style={styles.Amisimage}
                source={{
                  uri: serverSection ? item.profile_image : item.profile_image.replace('localhost', '10.0.2.2'),
                }}
              />
              <Text style={styles.AmiName}>{item.first_name + ' ' + item.last_name}</Text>
            </TouchableOpacity>
            <TouchableOpacity>
              <Feather
                name="more-vertical"
                size={20}
                style={styles.threeDotsIcon}
                onPress={() => ModalVisibiltyToggle(item)}
              />
            </TouchableOpacity>
          </>
        ) : type === 'amisProfil' ? (
          <>
            <TouchableOpacity style={styles.AmiInfo} onPress={() => ProfileHandler()} disabled={item.uid === user.uid}>
              <Image
                style={styles.Amisimage}
                source={{
                  uri: serverSection ? item.profile_image : item.profile_image.replace('localhost', '10.0.2.2'),
                }}
              />
              <Text style={styles.AmiName}>{item.first_name + ' ' + item.last_name}</Text>
            </TouchableOpacity>
            {/* <TouchableOpacity>
              <Feather
                name="more-vertical"
                size={20}
                style={styles.threeDotsIcon}
                onPress={() => ModalVisibiltyToggle(item)}
              />
            </TouchableOpacity> */}
          </>
        ) : type === 'createNewMessage' ? (
          <>
            <TouchableOpacity
              style={styles.AmiInfo}
              onPress={() => {
                navigateToDiscussion(item);
              }}
            >
              <Image
                style={styles.Amisimage}
                source={{
                  uri: serverSection ? item.profile_image : item.profile_image.replace('localhost', '10.0.2.2'),
                }}
              />
              <Text style={styles.AmiName}>{item.first_name + ' ' + item.last_name}</Text>
            </TouchableOpacity>
          </>
        ) : null}
      </View>
    </>
  );
};

export default AmiCard;
const styles = StyleSheet.create({
  Ami: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 70,
    width: '100%',
    marginLeft: 15,
  },
  AmiInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '80%',
  },
  Amisimage: {
    width: 50,
    height: 50,
    borderRadius: 40,
  },
  AmiName: {
    fontFamily: 'Poppins-Medium',
    height: 40,
    marginTop: 22,
    //fontWeight: '500',
    width: '75%',
    fontSize: 13,
    marginLeft: 10,
  },
  MembreStatus: {
    fontFamily: 'Poppins-thin',
    height: 15,
    marginRight: 50,
    width: '100%',
    fontSize: 10,
  },
  threeDotsIcon: {
    position: 'absolute',
    top: -10,
    right: 30,
    color: 'rgba(53, 47, 132, 1)',
  },
  checkCircleIcon: {
    position: 'absolute',
    top: 21,
    right: 0,
    color: 'rgba(53, 47, 132, 1)',
  },
});
