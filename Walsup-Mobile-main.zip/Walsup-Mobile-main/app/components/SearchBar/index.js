import React, { useEffect, useState } from 'react';
import { StyleSheet, TextInput, View, Keyboard, Button } from 'react-native';
import { Feather, Entypo } from '@expo/vector-icons';
import { BaseColor } from '../../../config/theme';
//svg costum assets
import CreateGroupeIcon from '../../../assets/Icons/components/CreateGroupeIcon';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { useNavigation } from '@react-navigation/native';
import ModalComponent from '../Modal';
//Composant de la barre de recherche
const SearchBarComponent = ({
  clicked,
  searchPhrase,
  setSearchPhrase,
  setClicked,
  search,
  ressetSearch,
  modifierSearchType,
}) => {
  const navigation = useNavigation();
  //Declaration d'une variable dans le state pour le type de la barre de recherche
  const [searshbarType, setSearshbarType] = useState('amis');
  //UseEffect pour le mise à jour de type de la  barre de recherche
  useEffect(() => {
    setSearshbarType(modifierSearchType);
  }, [modifierSearchType]);

  return (
    <View style={styles.container}>
      <View
        style={
          searshbarType !== 'groupes'
            ? clicked
              ? styles.searchBar__clicked
              : styles.searchBar__unclicked
            : clicked
            ? styles.searchBar__clicked__groups
            : styles.searchBar__unclicked__groups
        }
      >
        {/* Input field */}
        <TextInput
          style={styles.input}
          placeholder="Rechercher"
          value={searchPhrase}
          onChangeText={setSearchPhrase}
          onSubmitEditing={search}
          onFocus={() => {
            setClicked(true);
          }}
        />
        {/* cross Icon and search Icon depending on whether the search bar is clicked or not */}
        {clicked ? (
          <Entypo
            name="cross"
            size={20}
            color="black"
            style={styles.searchIcon}
            onPress={() => {
              ressetSearch();
            }}
          />
        ) : (
          /* search Icon */
          <View style={styles.searchIconContainer}>
            <Feather name="search" size={20} color="black" style={styles.searchIcon} />
          </View>
        )}
      </View>
    </View>
  );
};
export default SearchBarComponent;

// styles
const styles = StyleSheet.create({
  container: {
    margin: 15,
    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
    width: '90%',
  },
  searchBar__unclicked: {
    padding: 10,
    flexDirection: 'row',
    width: '100%',
    height: 40,
    backgroundColor: '#F2F2F2',
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  searchBar__unclicked__groups: {
    padding: 10,
    flexDirection: 'row',
    width: '86%',
    height: 40,
    backgroundColor: '#F2F2F2',
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  searchBar__clicked: {
    padding: 10,
    flexDirection: 'row',
    width: '100%',
    height: 40,
    backgroundColor: '#F2F2F2',
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  searchBar__clicked__groups: {
    padding: 10,
    flexDirection: 'row',
    width: '86%',
    height: 40,
    backgroundColor: '#F2F2F2',
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  input: {
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    marginLeft: 10,
    width: '90%',
    color: '#747B84',
  },
  searchIconContainer: {
    alignItems: 'flex-end',
    width: 'auto',
  },
  searchIcon: {
    marginRight: 5,
  },
});
