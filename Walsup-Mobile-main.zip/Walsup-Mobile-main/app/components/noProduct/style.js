import { StyleSheet } from 'react-native';
import { BaseColor, Fonts } from '../../../config/theme';

export default StyleSheet.create({
  mainContainer: {
    width: 360,
    height: 460,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mascotContainer: {
    width: '64%',
    height: '64%',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: -20,
  },
  mascott: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  textHmmm: {
    fontSize: Fonts.font_big + 2,
    fontFamily: 'Poppins-Medium',
  },
  textDescription: {
    fontSize: Fonts.font_normal,
    fontFamily: 'Poppins-Medium',
  },
});
