import React from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';

//Composant de tous les buttons (dans la partie soocial)
const CustomButton = (props) => {
  const { title, onPress, style, Textstyle, disabled } = props;
  return (
    <TouchableOpacity style={[styles.button, style]} onPress={onPress} disabled={disabled}>
      <Text style={[styles.buttonText, Textstyle]}>{title}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    backgroundColor: 'rgba(105, 89, 222, 1)',
    borderRadius: 5,
    width: 82,
    height: 22,
    paddingVertical: 3,
    paddingHorizontal: 10,
    alignItems: 'center',
  },
  buttonText: {
    fontFamily: 'Poppins-Medium',
    color: '#fff',
    fontSize: 10,
    //fontWeight: '500',
  },
});

export default CustomButton;
