import { createSlice } from '@reduxjs/toolkit';
import {
  registerUserWithFacebook,
  registerUserWithGoogle,
  loginUserWithFacebook,
  loginUserWithGoogle,
  registerUser,
  loginUserRun,
  createProfile,
  regenareUserToken,
  getAllPartners,
  SetUserInterests,
} from './authenticationThunk';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { GoogleSignin } from '@react-native-google-signin/google-signin';

GoogleSignin.configure({
  webClientId: '281609768173-ea66e1boqhbsaggou1dsbm1lsfs4pccp.apps.googleusercontent.com',
});

//state initial
const initialState = {
  user: {},
  partners: {},
  RegisterError: null,
  LoginError: null,
  loading: false,
  loading_partners: false,
  signInCompleted: false,
};

//Creation de slice d'authentification
const authentificationSlice = createSlice({
  name: 'authentification',
  initialState,
  //implementation des reducers
  reducers: {
    //Reducer de déconnexion
    logoutUser: async (state, actions) => {
      if (GoogleSignin.getCurrentUser()) {
        await GoogleSignin.signOut();
        await GoogleSignin.revokeAccess();
      }
      AsyncStorage.removeItem('persist:user');
      state.user = {};
      state.RegisterError = null;
      state.LoginError = null;
      state.signInCompleted = false;
      state.loading = false;
    },
    //Reducer pour verification de connexion
    setSignInCompleted: (state, actions) => {
      if (state.user?.uid) {
        state.signInCompleted = true;
      } else {
        state.signInCompleted = false;
      }
    },
    // testauth: (state, actions) => {
    //   console.log("Slice of Auth ===>",actions.payload);
    // },
  },
  extraReducers: (builder) => {
    builder
      //Reducer d'inscription avec google
      .addCase(registerUserWithGoogle.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.RegisterError = null;
        state.loading = true;
      })
      .addCase(registerUserWithGoogle.fulfilled, (state, action) => {
        //Mise à jour de state
        state.RegisterError = null;
        state.loading = false;
        //Mise à jour de l'utilisateur
        state.user = { ...state.user, ...action.payload };
      })
      .addCase(registerUserWithGoogle.rejected, (state, action) => {
        //Reinitialisation de state
        state.loading = false;
        //Mise à jour d'erreur
        state.RegisterError = action.payload;
      })
      //Reducer d'inscription avec Facebook
      .addCase(registerUserWithFacebook.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.RegisterError = null;
        state.loading = true;
      })
      .addCase(registerUserWithFacebook.fulfilled, (state, action) => {
        //Mise à jour de state
        state.RegisterError = null;
        state.loading = false;
        //Mise à jour de l'utilisateur
        state.user = { ...state.user, ...action.payload };
      })
      .addCase(registerUserWithFacebook.rejected, (state, action) => {
        //Reinitialisation de state
        state.loading = false;
        //Mise à jour d'erreur
        state.RegisterError = action.payload;
      })
      //Reducer de connexion avec google
      .addCase(loginUserWithGoogle.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.LoginError = null;
        state.loading = true;
      })
      .addCase(loginUserWithGoogle.fulfilled, (state, action) => {
        //Mise à jour de state
        state.LoginError = null;
        state.loading = false;
        //Mise à jour de l'utilisateur
        state.user = { ...state.user, ...action.payload };
        // state.token = token;
        // AsyncStorage.setItem('loginUser', token)
      })
      .addCase(loginUserWithGoogle.rejected, (state, action) => {
        //Reinitialisation de state
        state.loading = false;
        //Mise à jour d'erreur
        state.LoginError = action.payload;
      })
      //Reducer de connexion avec facebook
      .addCase(loginUserWithFacebook.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.LoginError = null;
        state.loading = true;
      })
      .addCase(loginUserWithFacebook.fulfilled, (state, action) => {
        //Mise à jour de state
        state.LoginError = null;
        state.loading = false;
        //Mise à jour de l'utilisateur
        state.user = { ...state.user, ...action.payload };
        // state.token = token;
        // AsyncStorage.setItem('loginUser', token)
      })
      .addCase(loginUserWithFacebook.rejected, (state, action) => {
        //Reinitialisation de state
        state.loading = false;
        //Mise à jour d'erreur
        state.LoginError = action.payload;
      })
      //Reducer d'inscription d'utilisateur par email et mot de passe
      .addCase(registerUser.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.RegisterError = null;
        state.loading = true;
      })
      .addCase(registerUser.fulfilled, (state, action) => {
        //Mise à jour de state
        state.loading = false;
        state.RegisterError = null;
        //Mise à jour de l'utilisateur
        state.user = { ...state.user, ...action.payload };
      })
      .addCase(registerUser.rejected, (state, action) => {
        //Reinitialisation de state
        state.loading = false;
        //console.log(action.payload);
        //Mise à jour d'erreur
        state.RegisterError = action.payload;
      })
      //Reducer de connexion d'utilisateur email et mot de passe
      .addCase(loginUserRun.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.LoginError = null;
        state.loading = true;
      })
      .addCase(loginUserRun.fulfilled, (state, action) => {
        //Mise à jour de state
        state.LoginError = null;
        state.loading = false;
        //Mise à jour de l'utilisateur
        state.user = { ...state.user, ...action.payload };
        // state.token = token;
        //AsyncStorage.setItem('loginUser', token)
      })
      .addCase(loginUserRun.rejected, (state, action) => {
        //Reinitialisation de state
        state.loading = false;
        //Mise à jour d'erreur
        state.LoginError = action.payload;
        //Reducer de regeneration de token d'utilisateur
      })
      .addCase(regenareUserToken.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.loading = true;
      })
      .addCase(regenareUserToken.fulfilled, (state, action) => {
        //Mise à jour de state
        state.loading = false;
        //Mise à jour de l'utilisateur
        state.user = { ...state.user, ...action.payload };
      })
      .addCase(regenareUserToken.rejected, (state, action) => {
        //Reinitialisation de state
        state.loading = false;
      })
      //Reducer de fetch de tous les partenaires
      .addCase(getAllPartners.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.loading_partners = true;
      })
      .addCase(getAllPartners.fulfilled, (state, action) => {
        //Mise à jour de state
        state.loading_partners = false;
        //Mise à jour des partenaires
        state.partners = action.payload;
      })
      .addCase(getAllPartners.rejected, (state, action) => {
        //Reinitialisation de state
        state.loading_partners = false;
      })
      //Reducer de creation des centres d'interets
      .addCase(SetUserInterests.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.loading = true;
      })
      .addCase(SetUserInterests.fulfilled, (state, action) => {
        //Mise à jour de state
        state.loading = false;
        //Mise à jour des centres d'interets
        state.user.interests_ids = [...action.payload];
      })
      .addCase(SetUserInterests.rejected, (state, action) => {
        //Reinitialisation de state
        state.loading = false;
      })
      //Reducer de creation de profile utilisateur
      .addCase(createProfile.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.loading = true;
      })
      .addCase(createProfile.fulfilled, (state, action) => {
        //Mise à jour de state
        state.loading = false;
        //Mise à jour de l'utilisateur
        state.user = { ...state.user, ...action.payload };
      })
      .addCase(createProfile.rejected, (state, action) => {
        //Reinitialisation de state
        state.loading = false;
      });
  },
});

export const { logoutUser, setSignInCompleted } = authentificationSlice.actions;

export default authentificationSlice.reducer;
