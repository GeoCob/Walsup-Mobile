import { createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { serverSection } from '../../../config/servConf';

const BASE_URL = 'http://10.0.2.2:5001/walsupdev/us-central1/mobile';
const BUILD_URL = 'https://us-central1-walsupdev.cloudfunctions.net/mobile';

//true for buld mode false for local
const linkSwitcher = serverSection;

//Thunk de connexion email et mot de passe
export const loginUserRun = createAsyncThunk('login/loginUserRun', async (datareq, { rejectWithValue }) => {
  try {
    const { email } = datareq;
    //console.log(email, password);
    //Appel au backend deployé ou local et à l'api de connexion email et mot de passe en passant les données en body
    const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/authentification/signIn`, {
      email,
    });
    //console.log('user', resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});

//Thunk d'inscription email et mot de passe
export const registerUser = createAsyncThunk('inscription/registerUser', async (data, { rejectWithValue }) => {
  try {
    const { email, password } = data;
    //Appel au backend deployé ou local et à l'api d'inscription email et mot de passe en passant les données en  body
    const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/authentification/signUp`, {
      email,
      password,
    });
    //console.log(resp)
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log('error', error.response.data.error,typeof error.response.data.error);
    return rejectWithValue(error.response.data);
  }
});
//Thunk d'inscription avec google
export const registerUserWithGoogle = createAsyncThunk(
  'inscription/registerUserWithGoogle',
  async (accessToken, { rejectWithValue }) => {
    try {
      //Appel au backend deployé ou local et à l'api d'inscription avec google en passant les données en body
      const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/authentification/signUpWithGoogle`, {
        accessToken,
      });
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      //console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
// Thunk d'inscription avec Facebook
export const registerUserWithFacebook = createAsyncThunk(
  'inscription/registerUserWithFacebook',
  async (accessToken, { rejectWithValue }) => {
    try {
      //Appel du backend deployé ou local et à l'api d'inscription avec Facebook en passant les données en body
      const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/authentification/signUpWithFacebook`, {
        accessToken,
      });
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      //console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);

//Thunk de connexion avec google
export const loginUserWithGoogle = createAsyncThunk(
  'login/loginUserWithGoogle',
  async (accessToken, { rejectWithValue }) => {
    try {
      // console.log(accessToken);
      //Appel au backend deployé ou local et à l'api de connexion avec google en passant les données en body
      const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/authentification/signInWithGoogle`, {
        accessToken,
      });
      //console.log('Google user', resp.data);
      //Retour de résultat de l'api
      return resp.data;
    } catch (error) {
      //console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk de connexion avec Facebook
export const loginUserWithFacebook = createAsyncThunk(
  'login/loginUserWithFacebook',
  async (accessToken, { rejectWithValue }) => {
    try {
      //Appel au backend deployé ou local et à l'api de connexion avec Facebook en passant les données en body
      const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/authentification/signInWithFacebook`, {
        accessToken,
      });
      //console.log("Facebook user",resp.data.user)
      //Retour de résultat de l'api
      return resp.data;
    } catch (error) {
      //console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk de regeneration de token (n'est pas utilisé)
export const regenareUserToken = createAsyncThunk('login/regenareUserToken', async (token, { rejectWithValue }) => {
  try {
    //Appel au backend deployé ou local et à l'api de regeneration de token en passant les données en headers
    const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/authentification/verifyUserToken`, null, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    //retour de résultat de l'api
    const userfeeduid = resp.data.user;
    //Appel au backend deployé ou local et à l'api de fetch de data d'utilisateur en passant le token en body
    const respUser = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/authentification/getUserById`, {
      ...userfeeduid,
    });
    //Structuration des données
    const finalUser = {
      ...userfeeduid,
      ...respUser.data,
    };
    //retour de résultat des deux Apis
    return finalUser;
  } catch (error) {
    //console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});

//============================================================
//==================== Partner data ==========================
//============================================================
//Thunk de fetch de tous les partenaires
export const getAllPartners = createAsyncThunk('get/partner_id', async (_, { rejectWithValue }) => {
  try {
    //Appel au backend deployé ou local et à l'api de fetch de tous les partenaires
    const { data } = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/authentification/getAllUsers`);
    //console.log("DATAAA",data)
    //Retour de résultat de l'api
    return data;
  } catch (error) {
    return rejectWithValue(error.message);
  }
});
//Thunk de creation des centres d'interets d'utilisateur
export const SetUserInterests = createAsyncThunk('/SetUserInterests', async (data, { rejectWithValue }) => {
  try {
    const { uid, interests_ids } = data;
    //Appel au backend deployé ou local et à l'api de creation des centres d'interets d'utilisateur en passant les données en body
    const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/authentification/SetUserInterests`, {
      uid,
      interests_ids,
    });
    // console.log('rsp', resp.data);
    //Retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log('error', error.response.data);
    return rejectWithValue(error.message);
  }
});
//Thunk de creation de profile utilisateur
export const createProfile = createAsyncThunk('/createProfile', async (data, { rejectWithValue }) => {
  try {
    const { first_name, last_name, image, uid, birth_date, genre, adresse, tel } = data;
    //console.log("DATA IN THUNK",data);
    //Appel au backend deployé ou local et à l'api de creation de profile utilisateur en panssant les données en body
    const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/authentification/createProfile`, {
      first_name,
      last_name,
      image,
      uid,
      birth_date,
      genre,
      adresse,
      tel,
    });
    //console.log('rsp CreateProf', resp.data);
    //Retour de résultat de l'api
    return resp.data;
  } catch (error) {
    console.log('error', error.response.data);
    return rejectWithValue(error.message);
  }
});
