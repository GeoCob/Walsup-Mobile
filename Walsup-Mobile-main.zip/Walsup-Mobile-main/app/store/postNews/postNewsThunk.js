import { createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { serverSection } from '../../../config/servConf';

/**==================== Thunk calls ======================= */

const URL_Post = 'http://10.0.2.2:5001/walsupdev/us-central1/mobile/offers';
const BUILD_Post = 'https://us-central1-walsupdev.cloudfunctions.net/mobile/offers';

//true for buld mode false for local
const linkSwitcher = serverSection;

//Thunk de fetch des offres publicitaires (non plus utilisé)
export const fetchAllPostsNews = createAsyncThunk('GET_ALL_POSTNEWS', async (user_id, thunkAPI) => {
  try {
    //Appel au backend deployé ou local et à l'api de fetch des offres publicitaires en passant les données en params
    const resp = await axios.get(`${linkSwitcher ? BUILD_Post : URL_Post}/getAllAdvertisingOffers`, {
      params: { user_id },
    });
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    return thunkAPI.rejectWithValue(`Error fetching all posts data ERROR : ${error}`);
  }
});

//Thunk de fetch des offre publicitaires avec category et filter
export const getAllAdevertisingOffersByCategory = createAsyncThunk(
  'GET_ALL_POSTNEWS_BY_CATGORY',
  async (data, thunkAPI) => {
    try {
      const { interests, user_id, filters } = data;
      //Appel au backend deployé ou local et à l'api de fetch des offres publicitaires avec category et filtres passés comme données en params
      const resp = await axios.get(`${linkSwitcher ? BUILD_Post : URL_Post}/getAllAdevertisingOffersByCategory`, {
        params: { interests, user_id, filters },
      });
      //console.log('Chomk posts =>', resp.data);
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(`Error fetching all commercial data ERROR : ${error}`);
    }
  }
);

//Thunk de fetch d'offre publicitaire par Id
export const getAdvertisingOfferById = createAsyncThunk('GET_POST_BY_ID', async (data, { rejectWithValue }) => {
  try {
    const { user_id, offer_id } = data;
    // console.log("get post by id ==>", user_id, offer_id);
    //Appel au backend deployé ou local et à l'api de fetch d'offre publicitaire par Id en passant les données en params
    const resp = await axios.get(`${linkSwitcher ? BUILD_Post : URL_Post}/getAdvertisingOfferById`, {
      params: { user_id, offer_id },
    });
    //extraction des commentaire
    const commentsParse = JSON.parse(resp.data[0].comments);
    const Data = resp.data[0];
    const combineData = {
      ...Data,
      comments: commentsParse,
    };
    //console.log("posts thunk recieved data =111====>", combineData);
    //retour de résultat de l'api en format {...data, comments:{...}}(data sont les données de l'offre nom image ...)
    return combineData;
  } catch (error) {
    //console.log(error);
    return rejectWithValue(error.response.data);
  }
});

//==================== likes posts ==========================
//Thunk de creation de j'aime
export const likeAdvertisingOffer = createAsyncThunk('LIKE_ADVERTISE', async (data, { rejectWithValue }) => {
  try {
    const { user_id, ads_id } = data;
    // console.log("userID: ", user_id,"\noffer_id: ", ads_id);
    //Appel au backend deployé ou local et à l'api de creation de j'aime en passant les données en body
    const resp = axios.post(`${linkSwitcher ? BUILD_Post : URL_Post}/createAdvertisingOfferLike`, { user_id, ads_id });
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log(error);
    return rejectWithValue(error.response.data);
  }
});
//Thunk de suppression de j'aime
export const unLikeAdvertisingOffer = createAsyncThunk('UNLIKE_ADVERTISE', async (data, { rejectWithValue }) => {
  try {
    const { user_id, ads_id } = data;
    // console.log("userID: ", user_id,"\noffer_id: ", ads_id);
    //Appel au backend deployé ou local et à l'api de suppression de j'aime en passant les données en body
    const resp = axios.post(`${linkSwitcher ? BUILD_Post : URL_Post}/removeAdvrtisingOfferLike`, { user_id, ads_id });
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log(error);
    return rejectWithValue(error.response.data);
  }
});

// add comment post
//Thunk de creation des commentaires
export const createAdvertisingOfferComment = createAsyncThunk('ADD_COMMENT_POST', async (data, { rejectWithValue }) => {
  try {
    const { user_id, offer_id, comment_msg } = data;
    // console.log("thunk ads ===>", user_id, offer_id, comment_msg);
    //Appel au backend deployé ou local et à l'api de creation des commentaires en passant les données body
    const resp = await axios.post(`${linkSwitcher ? BUILD_Post : URL_Post}/createAdvertisingOfferComment`, {
      user_id,
      offer_id,
      comment_msg,
    });
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log(error);
    return rejectWithValue(error.response.data);
  }
});

// =========== fetch all comment by post ID ==============
//Thunk de fetch des commentaires d'une offre
export const getAllAdvertisingComments = createAsyncThunk(
  'GET_ALL_COMMENT_POST_ID',
  async (data, { rejectWithValue }) => {
    try {
      const { ads_id } = data;
      //Appel au backend deployé ou local et à l'api de fetch des commentaires d'une offre en passant les données en params
      const resp = await axios.get(`${linkSwitcher ? BUILD_Post : URL_Post}/getAllAdvertisingComments`, {
        params: { ads_id },
      });
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      //console.log(error);
      return rejectWithValue(error.response.data);
    }
  }
);
