import { createSlice } from '@reduxjs/toolkit';
import { unlikeCommercialOffer } from '../commercialOffers/commercialOffersThunk';
import {
  fetchAllPostsNews,
  getAllAdevertisingOffersByCategory,
  likeAdvertisingOffer,
  unLikeAdvertisingOffer,
  createAdvertisingOfferComment,
  getAdvertisingOfferById,
  getAllAdvertisingComments,
} from './postNewsThunk';

//state de slice des offres pubilicitaires
const initialState = {
  loadingPost: false,
  loadingAdsLike: false,
  loadPostByID: false,
  loadingPostComment: false,
  postData: [],
  postById: {},
  commentsForPost: [],
  newComment: {},
  filtersnews: [],
};

//creation de slice des offres publicitaires
const postyNewsSlice = createSlice({
  name: 'postNews',
  initialState,
  //implementation des reducers
  reducers: {
    //Reintitialisation de l'offre
    emptyPostByIB: (state) => {
      state.postById = {};
    },
    //Reintialisatiosation des commentaires
    emptyPostComment: (state) => {
      state.commentsForPost = [];
    },
    //Mise à jour de filtre des offres
    setfiltersNewsSlice: (state, action) => {
      state.filtersnews = action.payload;
    },
    //Reinitialisation de filtre des offres
    resetfiltersNewsSlice: (state) => {
      state.filtersnews = [];
    },
  },
  extraReducers: (builder) => {
    builder
      //Reducer de fetch des offres publicitaires( n'est plus utilisé)
      .addCase(fetchAllPostsNews.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.loadingPost = true;
      })
      .addCase(fetchAllPostsNews.fulfilled, (state, action) => {
        //Mise à jour de state
        state.loadingPost = false;
        //Mise à jour des offres publicitaires
        state.postData = action.payload;
      })
      .addCase(fetchAllPostsNews.rejected, (state, action) => {
        //Reinitialisation de state
        state.loadingPost = false;
      })
      //Reducer de fetch des offres publicitaires
      .addCase(getAllAdevertisingOffersByCategory.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.loadingPost = true;
      })
      .addCase(getAllAdevertisingOffersByCategory.fulfilled, (state, action) => {
        //Mise à jour de state
        state.loadingPost = false;
        //Mise à jour des offres publicitaires
        state.postData = action.payload;
      })
      .addCase(getAllAdevertisingOffersByCategory.rejected, (state, action) => {
        //Reinitialisation de state
        state.loadingPost = false;
      })
      //Reducer de creation de j'aime
      .addCase(likeAdvertisingOffer.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.loadingAdsLike = true;
      })
      .addCase(likeAdvertisingOffer.fulfilled, (state, action) => {
        //mise à jour de state
        state.loadingAdsLike = false;
        // console.log(action.payload);
      })
      .addCase(likeAdvertisingOffer.rejected, (state, action) => {
        //Reinittialisation de state
        state.loadingAdsLike = false;
      })
      //Reducer de suppression de j'aime
      .addCase(unLikeAdvertisingOffer.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.loadingAdsLike = true;
      })
      .addCase(unLikeAdvertisingOffer.fulfilled, (state, action) => {
        //mise à jour de state
        state.loadingAdsLike = false;
        // console.log(action.payload);
      })
      //Reducer de creation de commentaire
      .addCase(createAdvertisingOfferComment.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.loadingPostComment = true;
      })
      .addCase(createAdvertisingOfferComment.fulfilled, (state, action) => {
        //Mise à jour de state
        state.loadingPostComment = false;
      })
      .addCase(createAdvertisingOfferComment.rejected, (state, action) => {
        //Reinitialisation de state
        state.loadingPostComment = false;
      })
      //Reducer de fetch d'une offre publicitaire
      .addCase(getAdvertisingOfferById.pending, (state) => {
        //Initialisation de state
        state.loadPostByID = true;
      })
      .addCase(getAdvertisingOfferById.fulfilled, (state, action) => {
        //Mise à jour de state
        state.loadPostByID = false;
        //Mise à jour de l'offre publicitaire
        state.postById = action.payload;
      })
      .addCase(getAdvertisingOfferById.rejected, (state, action) => {
        //Reinitialisation de state
        state.loadPostByID = false;
      })
      //Reducer de fetch des commentaire des offres publicitaires
      .addCase(getAllAdvertisingComments.pending, (state) => {
        //Initalisation de state
        state.loadingPostComment = true;
      })
      .addCase(getAllAdvertisingComments.fulfilled, (state, action) => {
        //Mise à jour de state
        state.loadingPostComment = false;
        //Mise à jour des commentaires
        state.commentsForPost = action.payload;
      })
      .addCase(getAllAdvertisingComments.rejected, (state, action) => {
        //Reinitialisation de state
        state.loadingPostComment = false;
      });
  },
});

export const { emptyPostByIB, emptyPostComment, setfiltersNewsSlice, resetfiltersNewsSlice } = postyNewsSlice.actions;
export default postyNewsSlice.reducer;
