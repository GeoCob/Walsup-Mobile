import { createSlice } from '@reduxjs/toolkit';
import {
  fetchAllCommercialOffers,
  getAllCommercialOffersByCategory,
  likeCommercialOffer,
  unlikeCommercialOffer,
  getCommercialOfferById,
  createCommercialOfferComment,
  getAllcommercialComments,
} from './commercialOffersThunk';

//state de slice des offres commercials
const initialState = {
  loadingOffers: false,
  loadingLike: false,
  loadingOfferByID: false,
  loadingofferComment: false,
  offersData: [],
  OfferByID: {},
  commentsForOffer: [],
  newComment: {},
  filters: [],
};

//creation de slice des offres commercials
const commercialOffersSlice = createSlice({
  name: 'commercialOffers',
  initialState,
  //implementation des reducers
  reducers: {
    //Reintitialisation de l'offre
    emptyOfferByID: (state) => {
      state.OfferByID = {};
    },
    //Reintialisatiosation des commentaires
    emptyComments: (state) => {
      state.commentsForOffer = [];
    },
    //Mise à jour de filtre des offres
    setfiltersCommercialSlice: (state, action) => {
      state.filters = action.payload;
    },
    //Reinitialisation de filtre des offres
    resetfiltersCommercialSlice: (state) => {
      state.filters = [];
    },
  },
  extraReducers: (builder) => {
    builder
      //Reducer de fetch des offres commercials(n'est plus utilisé)
      .addCase(fetchAllCommercialOffers.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.loadingOffers = true;
      })
      .addCase(fetchAllCommercialOffers.fulfilled, (state, action) => {
        //Mise à jour de state
        state.loadingOffers = false;
        //Mise à jour des offres commercials
        state.offersData = action.payload;
      })
      .addCase(fetchAllCommercialOffers.rejected, (state, action) => {
        //Reinitialisation de state
        state.loadingOffers = false;
      })
      //Reducer de fetch des offres commercials
      .addCase(getAllCommercialOffersByCategory.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.loadingOffers = true;
        //console.log('pending');
      })
      .addCase(getAllCommercialOffersByCategory.fulfilled, (state, action) => {
        //Mise à jour de state
        state.loadingOffers = false;
        //Mise à jour des offres publicitaires
        state.offersData = action.payload;
        //console.log('offersData', action.payload);
      })
      .addCase(getAllCommercialOffersByCategory.rejected, (state, action) => {
        //Reinitialisation de state
        state.loadingOffers = false;
        //console.log('rejected',action.payload);
      })
      //Reducer de creation de j'aime
      .addCase(likeCommercialOffer.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.loadLikes = true;
      })
      .addCase(likeCommercialOffer.fulfilled, (state, action) => {
        //mise à jour de state
        state.loadLikes = false;
      })
      .addCase(likeCommercialOffer.rejected, (state, action) => {
        //Reinittialisation de state
        state.loadLikes = false;
      })
      //Reducer de suppression de j'aime
      .addCase(unlikeCommercialOffer.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.loadingLike = true;
      })
      .addCase(unlikeCommercialOffer.fulfilled, (state, action) => {
        //mise à jour de state
        state.loadingLike = false;
      })
      .addCase(unlikeCommercialOffer.rejected, (state, action) => {
        //Reinittialisation de state
        state.loadingLike = false;
      })
      //Reducer de fetch d'une offre commercial
      .addCase(getCommercialOfferById.pending, (state) => {
        //Initialisation de state
        state.loadingOfferByID = true;
      })
      .addCase(getCommercialOfferById.fulfilled, (state, action) => {
        //Mise à jour de state
        state.loadingOfferByID = false;
        //Mise à jour de l'offre commercial
        state.OfferByID = action.payload;
      })
      .addCase(getCommercialOfferById.rejected, (state, action) => {
        //Reinitialisation de state
        state.loadingOfferByID = false;
      })
      //Reducer de creation de commentaire
      .addCase(createCommercialOfferComment.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.loadingofferComment = true;
      })
      .addCase(createCommercialOfferComment.fulfilled, (state, action) => {
        //Mise à jour de state
        state.loadingofferComment = false;
        //Mise à jour de commentaire
        state.newComment = action.payload;
      })
      .addCase(createCommercialOfferComment.rejected, (state, action) => {
        //Reinitialisation de state
        state.loadingofferComment = false;
      })
      //Reducer de fetch des commentaire des offres commercials
      .addCase(getAllcommercialComments.pending, (state) => {
        //Initalisation de state
        state.loadingofferComment = true;
      })
      .addCase(getAllcommercialComments.fulfilled, (state, action) => {
        //Mise à jour de state
        state.loadingofferComment = false;
        //Mise à jour des commentaires
        state.commentsForOffer = action.payload;
        // console.log("slice comments test", commentsForOffer);
      })
      .addCase(getAllcommercialComments.rejected, (state, action) => {
        //Reinitialisation de state
        state.loadingofferComment = false;
        //console.log(action.payload.rejected);
      });
  },
});

export const { emptyOfferByID, emptyComments, setfiltersCommercialSlice, resetfiltersCommercialSlice } =
  commercialOffersSlice.actions;
export default commercialOffersSlice.reducer;
