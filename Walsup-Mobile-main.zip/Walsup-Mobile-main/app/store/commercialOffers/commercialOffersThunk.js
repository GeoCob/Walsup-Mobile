import { createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { serverSection } from '../../../config/servConf';

/**==================== Thunk calls ======================= */

const URL_Commercial = 'http://10.0.2.2:5001/walsupdev/us-central1/mobile/offers';
const BUILD_Commercial = 'https://us-central1-walsupdev.cloudfunctions.net/mobile/offers';

//true for buld mode false for local
const linkSwitcher = serverSection;

//Thunk de fetch des offres commercials (non plus utilisé)
export const fetchAllCommercialOffers = createAsyncThunk('GET_ALL_OFFERCOM', async (user_id, thunkAPI) => {
  try {
    //Appel au backend deployé ou local et l'api de fetch des offres commercials en passant les données en params
    const resp = await axios.get(`${linkSwitcher ? BUILD_Commercial : URL_Commercial}/getAllCommercialOffers`, {
      params: { user_id },
    });
    //console.log("thunk commercial offer ===>", resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    return thunkAPI.rejectWithValue(`Error fetching all commercial data ERROR : ${error}`);
  }
});
//Thunk de fetch des offres commercials avec category et filter
export const getAllCommercialOffersByCategory = createAsyncThunk(
  'GET_ALL_OFFERCOM_BY_CATGORY',
  async (data, thunkAPI) => {
    try {
      const { interests, user_id, filters } = data;
      //Appel au backend deployé ou local et à l'api de fetch des offres commecials avec category et filter en passant les données en params
      const resp = await axios.get(
        `${linkSwitcher ? BUILD_Commercial : URL_Commercial}/getAllCommercialOffersByCategory`,
        { params: { interests, user_id, filters } }
      );
      //console.log('Chomk GETALLOFFERSBYCAT =>', resp);
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      return thunkAPI.rejectWithValue(`Error fetching all commercial data ERROR : ${error}`);
    }
  }
);

//Thunk de fetch d'une offre commercial par Id
export const getCommercialOfferById = createAsyncThunk('GET_OFFER_BY_ID', async (data, { rejectWithValue }) => {
  try {
    const { user_id, offer_id } = data;
    // console.log(user_id,"---------" , offer_id);
    //Appel au backend deployé ou local et à l'api de fetch d'une offre commercial en passant les données comme params
    const resp = await axios.get(`${linkSwitcher ? BUILD_Commercial : URL_Commercial}/getCommercialOfferById`, {
      params: { user_id, offer_id },
    });
    //Extraction des commentaire
    const commentsParse = JSON.parse(resp.data[0].comments);
    delete resp.data[0].comments;
    const Data = resp.data[0];
    const combineData = {
      ...Data,
      comments: commentsParse,
    };
    // console.log("thunk commercial ID ===>",combineData);
    //retour de résultat de l'api (format : {...data(données de l'offre), comments:{...commentaires}})
    return combineData;
  } catch (error) {
    //console.log(error);
    return rejectWithValue(error.response.data);
  }
});

//Thunk de création de j'aime
export const likeCommercialOffer = createAsyncThunk('LIKE_OFFER', async (data, { rejectWithValue }) => {
  try {
    const { user_id, offer_id } = data;
    //Appel au backend deployé ou local et à l'api de création de j'aime en passant les données comme body
    const resp = axios.post(`${linkSwitcher ? BUILD_Commercial : URL_Commercial}/createCommercialOfferLike`, {
      user_id,
      offer_id,
    });
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log(error);
    return rejectWithValue(error.response.data);
  }
});

//Thunk de suppression de j'aime
export const unlikeCommercialOffer = createAsyncThunk('UNLIKE_OFFER', async (data, { rejectWithValue }) => {
  try {
    const { user_id, offer_id } = data;
    //Appel au backend ou local et à l'api de suppression de j'aime en passant les données en body
    const resp = axios.post(`${linkSwitcher ? BUILD_Commercial : URL_Commercial}/removeCommercialOfferLike`, {
      user_id,
      offer_id,
    });
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log(error);
    return rejectWithValue(error.response.data);
  }
});

//Thunk de creation de commentaire
export const createCommercialOfferComment = createAsyncThunk('ADD_COMMENT_OFFER', async (data, { rejectWithValue }) => {
  try {
    const { user_id, offer_id, comment_msg } = data;
    //Appel au backend ou local et à l'api de creation de commentaire en passant les données en body
    const resp = await axios.post(`${linkSwitcher ? BUILD_Commercial : URL_Commercial}/createCommercialOfferComment`, {
      user_id,
      offer_id,
      comment_msg,
    });
    // console.log(resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    // console.log(error);
    return rejectWithValue(error.response.data);
  }
});

//Thunk de fetch de tous les commentaires des offres
export const getAllcommercialComments = createAsyncThunk(
  'GET_ALL_COMMENT_OFFER_ID',
  async (data, { rejectWithValue }) => {
    try {
      const { offer_id } = data;
      // console.log("thunk for commentatries test ==>", offer_id)
      //Appel au backend deployé ou local et à l'api de fetch de tous les commentaires des offres en passant les données comme params
      const resp = await axios.get(`${linkSwitcher ? BUILD_Commercial : URL_Commercial}/getAllcommercialComments`, {
        params: { offer_id },
      });
      // console.log("thunk resp back for commentatries test ==>",resp.data);
      //Retour de résultat de l'api
      return resp.data;
    } catch (error) {
      console.log(error);
      return rejectWithValue(error.response.data);
    }
  }
);
