import { configureStore } from '@reduxjs/toolkit';
//importing slices
import commercialOffersReducer from './commercialOffers/commercialOffersSlice';
import postNewsReducer from './postNews/postNewsSlice';
import authentificationReducr from './authentication/authenticationSlice';
import socialReducer from './social/socialSlice';
import privateChatReducer from './social/privateChatSlice';
import groupeChatReducer from './social/groupeChatSlice';
import { persistReducer, persistStore } from 'redux-persist';
import AsyncStorage from '@react-native-async-storage/async-storage';

//Persistance d'utilisateur connecté
const persistConfig = {
  key: 'user',
  storage: AsyncStorage,
  whitelist: ['user'],
};

//persistance d'utilisateur depuis authentifcationReducr
const persistedReducer = persistReducer(persistConfig, authentificationReducr);

//Creation de store avec les reducers et middleware
export const store = configureStore({
  reducer: {
    commercialOffers: commercialOffersReducer,
    postNews: postNewsReducer,
    authentification: persistedReducer,
    social: socialReducer,
    privateChat: privateChatReducer,
    groupeChat: groupeChatReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      immutableCheck: false,
      serializableCheck: false,
    }),
});

export const persistor = persistStore(store);
