import { createSlice } from '@reduxjs/toolkit';

//state initial
const initialState = {
  chatdata: {},
  privateChatRecieverData: {
    uid: '',
    first_name: '',
    last_name: '',
    name: '',
    profile_image: '',
  },
};
//creation de slice chat privé
const privateChatSlice = createSlice({
  name: 'privateChatSlice',
  initialState,
  //implementation des reducers
  reducers: {
    //Reducer de mise à jour de données de chat privé
    upadatePrivateChatRecieverData: (state, action) => {
      //mise à jour d'utilisateur (uid)
      state.privateChatRecieverData.uid = action.payload.uid ? action.payload.uid : action.payload.id;
      //mise à jour de son prénom
      state.privateChatRecieverData.first_name = action.payload.first_name ? action.payload.first_name : '';
      //mise à jour de son nom
      state.privateChatRecieverData.last_name = action.payload.last_name ? action.payload.last_name : '';
      //mise à jour de son name (si c'est un groupe)
      state.privateChatRecieverData.name = action.payload.name ? action.payload.name : '';
      //mise à jour de l'image
      state.privateChatRecieverData.profile_image = action.payload.profile_image
        ? action.payload.profile_image
        : action.payload.group_img;
    },
    //Reducer de reintialsiation de state et nettoyage des données
    clearPrivateChatRecieverData: (state) => {
      state.privateChatRecieverData.uid = '';
      state.privateChatRecieverData.first_name = '';
      state.privateChatRecieverData.last_name = '';
      state.privateChatRecieverData.name = '';
      state.privateChatRecieverData.profile_image = '';
    },
  },
});

export const { upadatePrivateChatRecieverData, clearPrivateChatRecieverData } = privateChatSlice.actions;
export default privateChatSlice.reducer;
