import { createSlice } from '@reduxjs/toolkit';
import { getGroupMembers } from './socialThunk';

//state de slice
const initialState = {
  privateChatRecieverData: {
    uid: '',
    first_name: '',
    last_name: '',
    profile_image: '',
  },
  GroupMembersChat: [],
  GroupMembersChatLoader: false,
  GroupMembersChatError: null,
};

//creation de slice de chat du groupe
const groupeeChatSlice = createSlice({
  name: 'privateChatSlice',
  initialState,
  //implementation des reducers
  reducers: {
    //Reducer de mise à jour des données d'utilisateur connecté de chat du groupe
    upadateGroupeChatRecieverData: (state, action) => {
      state.privateChatRecieverData.uid = action.payload.uid;
      state.privateChatRecieverData.first_name = action.payload.first_name;
      state.privateChatRecieverData.last_name = action.payload.last_name;
      state.privateChatRecieverData.profile_image = action.payload.profile_image;
    },
    //Reducer de nettoyage de state et de données
    clearGroupeChatRecieverData: (state) => {
      state.privateChatRecieverData.uid = '';
      state.privateChatRecieverData.first_name = '';
      state.privateChatRecieverData.last_name = '';
      state.privateChatRecieverData.profile_image = '';
    },
  },
  extraReducers: (builder) => {
    builder
      //Reducer de fetch des membres de groupe
      .addCase(getGroupMembers.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.GroupMembersChatError = null;
        state.GroupMembersChatLoader = true;
      })
      .addCase(getGroupMembers.fulfilled, (state, action) => {
        //Mise à jour de state
        state.GroupMembersChatError = null;
        state.GroupMembersChatLoader = false;
        //Mise à jour des membres de groupe
        state.GroupMembersChat = [...action.payload];
      })
      .addCase(getGroupMembers.rejected, (state, action) => {
        //Reinitialisation de state
        state.GroupMembersChatLoader = false;
        //Mise à jour d'erreur
        state.GroupMembersChatError = action.payload;
      });
  },
});

export const { upadateGroupeChatRecieverData, clearGroupeChatRecieverData } = groupeeChatSlice.actions;
export default groupeeChatSlice.reducer;
