import { createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { serverSection } from '../../../config/servConf';

const BASE_URL = 'http://10.0.2.2:5001/walsupdev/us-central1/mobile';
const BUILD_URL = 'https://us-central1-walsupdev.cloudfunctions.net/mobile';

//true for buld mode false for local
const linkSwitcher = serverSection;

// Thunk de fetch des suggestions d'utilisateurs
export const getUnfollowedUsers = createAsyncThunk('social/getUnfollowedUsers', async (uid, { rejectWithValue }) => {
  try {
    // console.log('uid in thunk =>', uid);
    //Appel au backend deployé ou local et à l'api de fetch des suggestions d'utilisateurs en passant les données en params
    const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/getUnfollowedUsers`, {
      params: { uid },
    });
    // console.log('unfollowedusers =>', resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});
//Thunk de fetch d'état d'amitié
export const GetFriendShipState = createAsyncThunk('social/GetFriendShipState', async (data, { rejectWithValue }) => {
  try {
    const { uid, friend_uid } = data;
    //axios refactoring 01
    //Appel au backend deployé ou local et à l'api de fetch d'état d'amitié en passant les données en params
    const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/GetFriendShipState`, {
      params: { uid, friend_uid },
    });
    // console.log('GetFriendShipState =>', resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});
//Thunk de fetch des amis
export const getfollowedUsers = createAsyncThunk('social/getfollowedUsers', async (uid, { rejectWithValue }) => {
  try {
    // console.log('uid in thunk =>', uid);
    //Appel au backend deployé ou local et à l'api de fetch des amis en passant les données en params
    const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/getfollowedUsers`, {
      params: { uid },
    });
    // console.log('followedusers =>', resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    // console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});
//Thunk de fetch des amis d'un ami
export const getFriendfollowedUsers = createAsyncThunk(
  'social/getFriendfollowedUsers',
  async (uid, { rejectWithValue }) => {
    try {
      // console.log('uid in thunk =>', uid);
      //Appel au backend deployé ou local et à l'api de fetch des amis d'un ami en passant les données en params
      const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/getfollowedUsers`, {
        params: { uid },
      });
      //console.log('followedusers =>', resp.data);
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      //console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk de fetch des invitations d'amitié reçues
export const GetFollowsReceived = createAsyncThunk('social/GetFollowsReceived', async (uid, { rejectWithValue }) => {
  try {
    // console.log('uid in thunk =>', uid);
    //Appel au backend deployé ou local et à l'api de fetch des invitations d'amitié reçues en passant les données en params
    const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/GetFollowsReceived`, {
      params: { uid },
    });
    //console.log('Follows in thunk =>', resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});
//Thunk de fetch des invitations d'amitié envoyés
export const GetFollowsSent = createAsyncThunk('social/GetFollowsSent', async (uid, { rejectWithValue }) => {
  try {
    // console.log('uid in thunk =>', uid);
    //Appel au backend deployé ou local et à l'api de fetch des invitations d'amitié envoyés en passant les données en params
    const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/GetFollowsSent`, {
      params: { uid },
    });
    //console.log('Follows in thunk =>', resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});
//Thunk d'acceptation des invitations d'amitié reçues
export const AcceptReceivedFollow = createAsyncThunk(
  'social/AcceptReceivedFollow',
  async (data, { rejectWithValue }) => {
    try {
      // console.log('uid in thunk =>', uid);
      const { sender_id, requested_id } = data;
      //Appel au backend deployé ou local et à l'api d'acceptation des invitations d'amitié reçues en passant les données en body
      const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/AcceptReceivedFollow`, {
        sender_id,
        requested_id,
      });
      // console.log('unfollowedusers =>', resp.data);
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      //console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk de suppression des invitations d'amitié envoyés
export const DeleteSentRequest = createAsyncThunk('social/DeleteSentRequest', async (data, { rejectWithValue }) => {
  try {
    // console.log('uid in thunk =>', uid);
    const { sender_id, requested_id } = data;
    //Appel au backend deployé ou local et à l'api de suppression des invitations d'amitié envoyés en passant les données en body
    const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/DeleteSentRequest`, {
      sender_id,
      requested_id,
    });
    // console.log('unfollowedusers =>', resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});
//Thunk de rejet des invitations d'amitié reçues
export const DeclineReceivedFollow = createAsyncThunk(
  'social/DeclineReceivedFollow',
  async (data, { rejectWithValue }) => {
    try {
      // console.log('uid in thunk =>', uid);
      const { sender_id, requested_id } = data;
      //Appel au backend deployé ou local et l'api de rejet des invitations d'amitié reçues en passant les données en body
      const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/DeclineReceivedFollow`, {
        sender_id,
        requested_id,
      });
      // console.log('unfollowedusers =>', resp.data);
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      // console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk d'envois des invitations d'amitié
export const FollowUser = createAsyncThunk('social/FollowUser', async (data, { rejectWithValue }) => {
  try {
    // console.log('uid in thunk =>', uid);
    const { sender_id, requested_id } = data;
    //Appel au backend deployé ou local et à l'api d'envois des invitations d'amitié en passant les données en body
    const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/FollowUser`, {
      sender_id,
      requested_id,
    });
    // console.log('unfollowedusers =>', resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});
//Thunk d'envois de demande pour rejoindre un groupe
export const RejoindreGroup = createAsyncThunk('social/RejoindreGroup', async (data, { rejectWithValue }) => {
  try {
    // console.log('uid in thunk =>', uid);
    const { sender_id, receiver_id, group_id } = data;
    //Appel au backend deployé ou local et à l'api d'envois de demande pour rejoindre un groupe en passant les données en body
    const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/RejoindreGroup`, {
      sender_id,
      receiver_id,
      group_id,
    });
    // console.log('unfollowedusers =>', resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});
//Thunk de retirer un ami de la liste des amis
export const RemoveUserFromFriends = createAsyncThunk(
  'social/RemoveUserFromFriends',
  async (data, { rejectWithValue }) => {
    try {
      // console.log('uid in thunk =>', uid);
      const { sender_id, requested_id } = data;
      //Appel au backend deployé ou local et à l'api de retirer un ami de la liste des amis en passant les données en body
      const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/RemoveUserFromFriends`, {
        sender_id,
        requested_id,
      });
      // console.log('unfollowedusers =>', resp.data);
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      //console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk de retirer membre d'un groupe
export const RemoveMemberFromGroup = createAsyncThunk(
  'social/RemoveMemberFromGroup',
  async (data, { rejectWithValue }) => {
    try {
      // console.log('uid in thunk =>', uid);
      const { uid, group_id } = data;
      //Appel au backend deployé ou local et à l'api de retirer membre d'un groupe en passant des données en body
      const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/RemoveMemberFromGroup`, {
        uid,
        group_id,
      });
      // console.log('unfollowedusers =>', resp.data);
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      //console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk de fetch des groupes d'un ami
export const getFirendAllGroupsById = createAsyncThunk(
  'social/getFirendAllGroupsById',
  async (uid, { rejectWithValue }) => {
    try {
      // console.log('uid in thunk =>', uid);
      //Appel au backend deployé ou local et l'api de fetch des groupes d'un ami en passant des données en params
      const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/getAllGroupsById`, {
        params: { uid },
      });
      //console.log('followedusers =>', resp.data);
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      //console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk de fetch des groupes
export const getAllGroupsById = createAsyncThunk('social/getAllGroupsById', async (uid, { rejectWithValue }) => {
  try {
    // console.log('uid in thunk =>', uid);
    //Appel au backend deployé ou local et à l'api de fetch des groupes en passant les données en params
    const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/getAllGroupsById`, {
      params: { uid },
    });
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});
//Thunk de fetch des suggestions de groupes
export const getAllGroupsSuggestionsByUid = createAsyncThunk(
  'social/getAllGroupsSuggestionsByUid',
  async (uid, { rejectWithValue }) => {
    try {
      // console.log('uid in thunk =>', uid);
      //Appel au backend deployé ou local et à l'api de fetch des suggestions de groupes en passant les données en params
      const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/getAllGroupsSuggestionsByUid`, {
        params: { uid },
      });
      //console.log('SUGG GROUPS', resp.data);
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      //console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk d'acceptation de demande de rejoindre un groupe
export const AcceptReceivedGroupInvite = createAsyncThunk(
  'social/AcceptReceivedGroupInvite',
  async (data, { rejectWithValue }) => {
    try {
      // console.log('uid in thunk =>', uid);
      const { sender_id, receiver_id, group_id } = data;
      //Appel au backend deployé ou local et à l'api d'acceptation de demande de rejoindre un groupe en passant les données en body
      const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/AcceptReceivedGroupInvite`, {
        sender_id,
        receiver_id,
        group_id,
      });
      // console.log('unfollowedusers =>', resp.data);
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      // console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk de suppression de demande de rejoindre un groupe envoyé (annulation)
export const DeleteGroupeSentRequest = createAsyncThunk(
  'social/DeleteGroupeSentRequest',
  async (data, { rejectWithValue }) => {
    try {
      // console.log('uid in thunk =>', uid);
      const { sender_id, receiver_id, group_id } = data;
      //Appel au backend deployé ou local et à l'api de suppression de demande de rejoindre un groupe envoyé en passant les données en body
      const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/DeleteGroupeSentRequest`, {
        sender_id,
        receiver_id,
        group_id,
      });
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      //console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk de rejet de demande de rejoindre un groupe reçue
export const DeclineReceivedGroupInvite = createAsyncThunk(
  'social/DeclineReceivedGroupInvite',
  async (data, { rejectWithValue }) => {
    try {
      // console.log('uid in thunk =>', uid);
      const { sender_id, receiver_id, group_id } = data;
      //Appel au backend deployé ou local et à l'api de rejet de demande de rejoindre un groupe reçue
      const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/DeclineReceivedGroupInvite`, {
        sender_id,
        receiver_id,
        group_id,
      });
      // console.log('unfollowedusers =>', resp.data);
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      //console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk de fetch des demandes de rejoindre un groupe reçues
export const GetGroupeReceivedInvitations = createAsyncThunk(
  'social/GetGroupeReceivedInvitations',
  async (uid, { rejectWithValue }) => {
    try {
      // console.log('uid in thunk =>', uid);
      //Appel au backend deployé ou local et à l'api de fetch des demandes de rejoindre un groupe reçues en passant des données en params
      const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/GetGroupeReceivedInvitations`, {
        params: { uid },
      });
      //console.log('Follows in thunk =>', resp.data);
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      //console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk de fetch des demandes de rejoindre un groupe envoyés
export const GetGroupeSentInvitations = createAsyncThunk(
  'social/GetGroupeSentInvitations',
  async (uid, { rejectWithValue }) => {
    try {
      // console.log('uid in thunk =>', uid);
      //Appel au backend deployé ou local et à l'api de fetch des demandes de rejoindre un groupe envoyés en passant les données en params
      const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/GetGroupeSentInvitations`, {
        params: { uid },
      });
      //console.log('Follows in thunk =>', resp.data);
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      //console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk de fetch des membres de groupe
export const getGroupMembers = createAsyncThunk('GET_GROUP_MEMBERS', async (members_ids, { rejectWithValue }) => {
  try {
    //Appel au backend deployé ou local et à l'api de fetch des membres de groupe en passant les données en params
    const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/getGroupMembers`, {
      params: { members_ids },
    });
    // console.log("social thunk section /getAllPartners ==>",resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});

// =================== PARTNERS RELATED THUNKS =============== //
//Thunk de fetch des partenaires
export const getAllPartnersFromDB = createAsyncThunk('GET_ALL_PARTNERS_DB', async (_, { rejectWithValue }) => {
  try {
    //Appel au backend deployé ou local et à l'api de fetch des partenaires
    const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/getAllPartners`);
    // console.log("social thunk section /getAllPartners ==>",resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});

//Thunk de fetch des suggestions des partenaires (non abonnées)
export const getSuggestionPartners = createAsyncThunk(
  'GET_ALL_SUGGESTION_PARTNERS_DB',
  async (dataSend, { rejectWithValue }) => {
    try {
      const { user_uid, suggestionType } = dataSend;
      // console.log(dataSend);
      //Appel au backend deployé ou local et à l'api de fetch des suggestions des partenaires en passant les données en params
      const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/getSuggestedPartners`, {
        params: { user_uid: user_uid, suggestionType: suggestionType },
      });
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);

//Thunk de fetch des partenaire aboonées
export const getAllSubscribedPartners = createAsyncThunk(
  'GET_ALL_SUB_PARTNER_BD',
  async (dataSend, { rejectWithValue }) => {
    try {
      const { user_uid } = dataSend;
      //Appel au backend deployé ou local et à l'api de fetch des partenaires abonnées en passant les données en params
      const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/getAllSubscribedPartners`, {
        params: { user_uid: user_uid },
      });
      //retour de réslutat de l'api
      return resp.data;
    } catch (error) {
      console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk de fetch des partenaires abonnées d'un ami
export const getFriendAllSubscribedPartners = createAsyncThunk(
  'GET_FRIEND_ALL_SUB_PARTNER_BD',
  async (dataSend, { rejectWithValue }) => {
    try {
      const { user_uid } = dataSend;
      //Appel au backend deployé ou local et à l'api de fetch des partenaires abonnées d'un ami en passant les données en params
      const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/getAllSubscribedPartners`, {
        params: { user_uid: user_uid },
      });
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);
//Thunk d'abonnement aux partenaires
export const subscribeToPartner = createAsyncThunk('POST_SUBSCRIBE_PARTNER', async (dataSend, { rejectWithValue }) => {
  try {
    const { requested_id, sender_id } = dataSend;
    //Appel au backend deployé ou local et à l'api d'abonnement aux partenaires en passant les données en body
    const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/subscribeToPartner`, {
      partner_uid: requested_id,
      user_uid: sender_id,
    });
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});

//Thunk de désabonnement aux partenaires
export const unSubscribeToPartner = createAsyncThunk(
  'POST_UNSUBSCRIBE_PARTNER',
  async (dataSend, { rejectWithValue }) => {
    try {
      const { partner_uid, user_uid } = dataSend;
      // console.log(dataSend);
      //Appel au backend deployé ou local et à l'api de désabonnement aux partenaires en passant les données en body
      const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/unSubscribeToPartner`, {
        partner_uid: partner_uid,
        user_uid: user_uid,
      });
      //retour de résultat de l'api
      return resp.data;
    } catch (error) {
      console.log('error', error.response.data);
      return rejectWithValue(error.response.data);
    }
  }
);

// =================== GROUPES RELATED THUNKS =============== //
//Thunk de création de groupe
export const CreateGroupeApi = createAsyncThunk('social/CreateGroupeApi', async (data, { rejectWithValue }) => {
  try {
    const { GroupeType, name, commercial_offer_id, user_ids, user_admin_id, group_img } = data;
    //console.log('data', data);
    //Appel au backend deployé ou local et à l'api de création de groupe en passant des données en body
    const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/CreateGroup`, {
      GroupeType,
      name,
      commercial_offer_id,
      user_ids,
      user_admin_id,
      group_img,
    });
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log('error', error.response);
    return rejectWithValue(error.response.data);
  }
});
//Thunk de quitter un groupe
export const RemoveUserFromGroup = createAsyncThunk('social/RemoveUserFromGroup', async (data, { rejectWithValue }) => {
  try {
    // console.log('uid in thunk =>', uid);
    const { uid, group_id } = data;
    //Appel au backend deployé ou local et à l'api de quitter un groupe en passant des données en body
    const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/RemoveUserFromGroup`, {
      uid,
      group_id,
    });
    // console.log('unfollowedusers =>', resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});
//Thunk d'inviter un ami au groupe
export const InviteFriendToGroup = createAsyncThunk('social/InviteFriendToGroup', async (data, { rejectWithValue }) => {
  try {
    // console.log('uid in thunk =>', uid);
    const { user_ids, group_id } = data;
    //Appel au backend deployé ou local et à l'api d'inviter un ami au groupe en passant des données en body
    const resp = await axios.post(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/InviteFriendToGroup`, {
      user_ids,
      group_id,
    });
    // console.log('unfollowedusers =>', resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    //console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});
//Thunk de fetch de discussions (non utilisé)
export const getDiscussions = createAsyncThunk('social/getUserDiscussionsByUid', async (data, { rejectWithValue }) => {
  try {
    // console.log('uid in thunk =>', uid);
    const { uid } = data;
    //Appel au backend deployé ou local et à l'api de fetch de discussions (non utilisés)
    const resp = await axios.get(`${linkSwitcher ? BUILD_URL : BASE_URL}/social/getUserDiscussionsByUid`, {
      uid,
    });
    // console.log('unfollowedusers =>', resp.data);
    //retour de résultat de l'api
    return resp.data;
  } catch (error) {
    console.log('error', error.response.data);
    return rejectWithValue(error.response.data);
  }
});
//Thunk de fetch des données des discussions (non utilisé)
export const getDiscussionData = createAsyncThunk('social/getDiscussionData', async (item, { rejectWithValue }) => {
  try {
    return item;
  } catch (error) {
    return rejectWithValue(error);
  }
});
