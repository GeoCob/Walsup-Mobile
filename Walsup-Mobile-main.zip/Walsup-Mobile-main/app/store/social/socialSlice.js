import { createSlice } from '@reduxjs/toolkit';
import { useDispatch } from 'react-redux';
import {
  GetFollowsReceived,
  GetFollowsSent,
  GetFriendShipState,
  FollowUser,
  AcceptReceivedFollow,
  getUnfollowedUsers,
  DeclineReceivedFollow,
  DeleteSentRequest,
  getfollowedUsers,
  getAllGroupsById,
  getAllGroupsSuggestionsByUid,
  getAllPartnersFromDB,
  getSuggestionPartners,
  getAllSubscribedPartners,
  RemoveUserFromFriends,
  RemoveMemberFromGroup,
  CreateGroupeApi,
  RejoindreGroup,
  AcceptReceivedGroupInvite,
  DeclineReceivedGroupInvite,
  DeleteGroupeSentRequest,
  GetGroupeReceivedInvitations,
  GetGroupeSentInvitations,
  RemoveUserFromGroup,
  InviteFriendToGroup,
  getFriendfollowedUsers,
  getFirendAllGroupsById,
  getDiscussions,
  subscribeToPartner,
  unSubscribeToPartner,
  getFriendAllSubscribedPartners,
  getDiscussionData,
  getGroupMembers,
} from './socialThunk';

//state de slice social
const initialState = {
  UnfollowedUsers: [],
  UnfollowedUsersLoader: false,
  UnfollowedUsersError: null,
  followedUsers: [],
  followedUsersLoader: false,
  followedUsersError: null,
  FriendfollowedUsers: [],
  FriendfollowedUsersLoader: false,
  FriendfollowedUsersError: null,
  UserGroups: [],
  UserGroupsLoader: false,
  UserGroupsError: null,
  FriendUserGroups: [],
  FriendUserGroupsLoader: false,
  FriendUserGroupsError: null,
  UserGroupsSuggestions: [],
  UserGroupsSuggestionsLoader: false,
  UserGroupsSuggestionsError: null,
  CreateGroupeLoader: false,
  CreateGroupeError: null,
  FollowUserError: null,
  FollowUserLoader: false,
  RejoindreGroupError: null,
  RejoindreGroupLoader: false,
  InviteFriendToGroupError: null,
  InviteFriendToGroupLoader: false,
  RemoveUserFromFriendsError: null,
  RemoveUserFromFriendsLoader: false,
  RemoveMemberFromGroupError: null,
  RemoveMemberFromGroupLoader: false,
  RemoveUserFromGroupError: null,
  RemoveUserFromGroupLoader: false,
  AcceptReceivedFollowError: null,
  AcceptReceivedFollowLoader: false,
  AcceptReceivedGroupInviteError: null,
  AcceptReceivedGroupInviteLoader: false,
  DeclineReceivedFollowError: null,
  DeclineReceivedFollowLoader: false,
  DeclineReceivedGroupInviteError: null,
  DeclineReceivedGroupInviteLoader: false,
  DeleteSentRequestError: null,
  DeleteSentRequestLoader: false,
  DeleteGroupeSentRequestError: null,
  DeleteGroupeSentRequestLoader: false,
  FollowsReceived: [],
  FollowsReceivedError: null,
  FollowsReceivedLoader: false,
  GroupeReceivedInvitations: [],
  GroupeReceivedInvitationsError: null,
  GroupeReceivedInvitationsLoader: false,
  FollowsSent: [],
  FollowsSentError: null,
  FollowsSentLoader: false,
  GroupeSentInvitations: [],
  GroupeSentInvitationsError: null,
  GroupeSentInvitationsLoader: false,
  getDiscussionsError: null,
  getDiscussionsLoader: false,
  discussions: {},
  //partners states
  partnersAll: [],
  partnersSuggestions: [],
  partnersSubscribed: [],
  partnersLoader: false,
  partnersSubsLoader: false,
  FriendpartnersSubscribed: [],
  FriendpartnersLoader: false,
  FriendpartnersSubsLoader: false,
  partnersSuggestionLoader: false,
  partnersReciecedError: null,
  FriendpartnersReciecedError: null,
  partnerSuccesMessage: '',
  IsFriend: '',
  IsFriendError: null,
  IsFriendLoader: false,
  CreatedGroup: {},
  ChatData: {},
  GroupMembers: [],
  GroupMembersLoader: false,
  GroupMembersError: null,
};

//creation de slice social
const socialSlice = createSlice({
  name: 'social',
  initialState,
  //implementation des reducers
  reducers: {
    //reducer qui supprime les données de chat
    ClearChatData: (state, actions) => {
      state.ChatData = {};
    },
    //reducer qui ajoute les données de chat
    pushChatData: (state, action) => {
      state.ChatData = action.payload;
    },
    //reducer qui mis à jour les données d'un group crée
    updateCreatedGroupe: (state, action) => {
      state.CreatedGroup = action.payload;
    },
    //reducer qui supprime les données d'un group crée
    clearCreatdGroupe: (state) => {
      state.CreatedGroup = {};
    },
    //reducer qui supprime les données des membres d'un groupe
    clearGroupemebersData: (state) => {
      state.GroupMembers = [];
    },
  },
  extraReducers: (builder) => {
    builder
      //Reducer de fetch des suggestions d'amis
      .addCase(getUnfollowedUsers.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.UnfollowedUsersError = null;
        state.UnfollowedUsersLoader = true;
      })
      .addCase(getUnfollowedUsers.fulfilled, (state, action) => {
        //Mise à jour de state
        state.UnfollowedUsersError = null;
        state.UnfollowedUsersLoader = false;
        //Mise à jour de suggestions d'amis
        state.UnfollowedUsers = [...action.payload];
      })
      .addCase(getUnfollowedUsers.rejected, (state, action) => {
        //Reinitialisation de state
        state.UnfollowedUsersLoader = false;
        //Mise à jour d'erreur
        state.UnfollowedUsersError = action.payload;
      })
      //Reducer de fetch de status d'amitié entre les utilisateurs
      .addCase(GetFriendShipState.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.IsFriendError = null;
        state.IsFriendLoader = true;
      })
      .addCase(GetFriendShipState.fulfilled, (state, action) => {
        //Mise à jour de state
        state.IsFriendError = null;
        state.IsFriendLoader = false;
        //Mise à jour de suggestions d'amis
        state.IsFriend = action.payload.isFriend;
      })
      .addCase(GetFriendShipState.rejected, (state, action) => {
        //Reinitialisation de state
        state.IsFriendLoader = false;
        //Mise à jour d'erreur
        state.IsFriendError = action.payload;
      })
      //Reducer de fetch de suggestions des groupes
      .addCase(getAllGroupsSuggestionsByUid.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.UserGroupsSuggestionsError = null;
        state.UserGroupsSuggestionsLoader = true;
      })
      .addCase(getAllGroupsSuggestionsByUid.fulfilled, (state, action) => {
        //Mise à jour de state
        state.UserGroupsSuggestionsError = null;
        state.UserGroupsSuggestionsLoader = false;
        //Mise à jour de suggestions des groupes
        state.UserGroupsSuggestions = [...action.payload];
      })
      .addCase(getAllGroupsSuggestionsByUid.rejected, (state, action) => {
        //Reinitialisation de state
        state.UserGroupsSuggestionsLoader = false;
        //Mise à jour d'erreur
        state.UserGroupsSuggestionsError = action.payload;
      })
      //Reducer de fetch des amis
      .addCase(getfollowedUsers.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.followedUsersError = null;
        state.followedUsersLoader = true;
      })
      .addCase(getfollowedUsers.fulfilled, (state, action) => {
        //Mise à jour de state
        state.followedUsersError = null;
        state.followedUsersLoader = false;
        //Mise à jour des amis
        state.followedUsers = [...action.payload];
      })
      .addCase(getfollowedUsers.rejected, (state, action) => {
        //Reinitialisation de state
        state.followedUsersLoader = false;
        //Mise à jour d'erreur
        state.followedUsersError = action.payload;
      })
      //Reducer de fetch des amis d'un ami
      .addCase(getFriendfollowedUsers.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.FriendfollowedUserssError = null;
        state.FriendfollowedUserssLoader = true;
      })
      .addCase(getFriendfollowedUsers.fulfilled, (state, action) => {
        //Mise à jour de state
        state.FriendfollowedUserssError = null;
        state.FriendfollowedUserssLoader = false;
        //Mise à jour des amis d'un ami
        state.FriendfollowedUsers = [...action.payload];
      })
      .addCase(getFriendfollowedUsers.rejected, (state, action) => {
        //Reinitialisation de state
        state.FriendfollowedUsersLoader = false;
        //Mise à jour d'erreur
        state.FriendfollowedUsersError = action.payload;
      })
      //Reducer de fetch des groupes d'utilisateur
      .addCase(getAllGroupsById.pending, (state, action) => {
        //initialisation de state et lancement de loader
        state.UserGroupsError = null;
        state.UserGroupsLoader = true;
      })
      .addCase(getAllGroupsById.fulfilled, (state, action) => {
        //Mise à jour de state
        state.UserGroupsError = null;
        state.UserGroupsLoader = false;
        //Mise à jour des groupes
        state.UserGroups = [...action.payload];
      })
      .addCase(getAllGroupsById.rejected, (state, action) => {
        //Reinitialisation de state
        state.UserGroupsLoader = false;
        //Mise à jour d'erreur
        state.UserGroupsError = action.payload;
      })
      //Reducer de fetch des membres de groupes
      .addCase(getGroupMembers.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.GroupMembersError = null;
        state.GroupMembersLoader = true;
      })
      .addCase(getGroupMembers.fulfilled, (state, action) => {
        //Mise à jour de state
        state.GroupMembersError = null;
        state.GroupMembersLoader = false;
        //Mise à jour des membres de groupes
        state.GroupMembers = [...action.payload];
      })
      .addCase(getGroupMembers.rejected, (state, action) => {
        //Reinitialisation de state
        state.GroupMembersLoader = false;
        //Mise à jour d'erreur
        state.GroupMembersError = action.payload;
      })
      //Reducer de fetch des groupes d'un ami
      .addCase(getFirendAllGroupsById.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.FriendUserGroupsError = null;
        state.FriendUserGroupsLoader = true;
      })
      .addCase(getFirendAllGroupsById.fulfilled, (state, action) => {
        //Mise à jour de state
        state.FriendUserGroupsError = null;
        state.FriendUserGroupsLoader = false;
        //Mise à jour des groupes d'un ami
        state.FriendUserGroups = [...action.payload];
      })
      .addCase(getFirendAllGroupsById.rejected, (state, action) => {
        //Reinitialisation de state
        state.FriendUserGroupsLoader = false;
        //Mise à jour d'erreur
        state.FriendUserGroupsError = action.payload;
      })
      //Reducer de fetch des invitations d'amitié reçues
      .addCase(GetFollowsReceived.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.FollowsReceivedError = null;
        state.FollowsReceivedLoader = true;
      })
      .addCase(GetFollowsReceived.fulfilled, (state, action) => {
        //Mise à jour de state
        state.FollowsReceivedError = null;
        state.FollowsReceivedLoader = false;
        //Mise à jour des invitations d'amitié reçues
        state.FollowsReceived = [...action.payload];
      })
      .addCase(GetFollowsReceived.rejected, (state, action) => {
        //Reinitialisation de state
        state.FollowsReceivedLoader = false;
        //Mise à jour d'erreur
        state.FollowsReceivedError = action.payload;
      })
      //Reducer de fetch des invitations de groupes reçues
      .addCase(GetGroupeReceivedInvitations.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.GroupeReceivedInvitationsError = null;
        state.GroupeReceivedInvitationsLoader = true;
      })
      .addCase(GetGroupeReceivedInvitations.fulfilled, (state, action) => {
        //Mise à jour de state
        state.GroupeReceivedInvitationsError = null;
        state.GroupeReceivedInvitationsLoader = false;
        //Mise à jour des invitations de groupes reçues
        state.GroupeReceivedInvitations = [...action.payload];
      })
      .addCase(GetGroupeReceivedInvitations.rejected, (state, action) => {
        //Reinitialisation de state
        state.GroupeReceivedInvitationsLoader = false;
        //Mise à jour d'erreur
        state.GroupeReceivedInvitationsError = action.payload;
      })
      //Reducer de fetch des invitations d'amitié envoyés
      .addCase(GetFollowsSent.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.FollowsSentError = null;
        state.FollowsSentLoader = true;
      })
      .addCase(GetFollowsSent.fulfilled, (state, action) => {
        //Mise à jour de state
        state.FollowsSentError = null;
        state.FollowsSentLoader = false;
        //Mise à jour des invitations d'amitié envoyés
        state.FollowsSent = [...action.payload];
      })
      .addCase(GetFollowsSent.rejected, (state, action) => {
        //Reinitialisation de state
        state.FollowsSentLoader = false;
        //Mise à jour d'erreur
        state.FollowsSentError = action.payload;
      })
      //Reducer de fetch des invitations de groupes envoyés
      .addCase(GetGroupeSentInvitations.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.GroupeSentInvitationsError = null;
        state.GroupeSentInvitationsLoader = true;
      })
      .addCase(GetGroupeSentInvitations.fulfilled, (state, action) => {
        //Mise à jour de state
        state.GroupeSentInvitationsError = null;
        state.GroupeSentInvitationsLoader = false;
        //Mise à jour des invitations de groupes envoyés
        state.GroupeSentInvitations = [...action.payload];
      })
      .addCase(GetGroupeSentInvitations.rejected, (state, action) => {
        //Reinitialisation de state
        state.GroupeSentInvitationsLoader = false;
        //Mise à jour d'erreur
        state.GroupeSentInvitationsError = action.payload;
      })
      //Reducer d'envois d'invitation d'amitié
      .addCase(FollowUser.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.FollowUserError = null;
        state.FollowUserLoader = true;
      })
      .addCase(FollowUser.fulfilled, (state, action) => {
        //Mise à jour de state et de suggestions d'amis
        state.UnfollowedUsers = state.UnfollowedUsers.filter((user) => user.uid != action.payload.uid);
        state.IsFriend = 'Sent';
        state.FollowUserError = null;
        state.FollowUserLoader = false;
      })
      .addCase(FollowUser.rejected, (state, action) => {
        //Reinitialisation de state
        state.FollowUserLoader = false;
        //Mise à jour d'erreur
        state.FollowUserError = action.payload;
      })
      //Reducer d'envois d'invitation de rejoindre un groupe
      .addCase(RejoindreGroup.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.RejoindreGroupError = null;
        state.RejoindreGroupLoader = true;
      })
      .addCase(RejoindreGroup.fulfilled, (state, action) => {
        //Mise à jour de state et de suggestions de groupes
        //console.log(action.payload);
        state.UserGroupsSuggestions = state.UserGroupsSuggestions.filter((group) => group.id != action.payload.id);
        //console.log(state.UserGroupsSuggestions);
        state.RejoindreGroupError = null;
        state.RejoindreGroupLoader = false;
      })
      .addCase(RejoindreGroup.rejected, (state, action) => {
        //Reinitialisation de state
        state.RejoindreGroupLoader = false;
        //Mise à jour d'erreur
        state.RejoindreGroupError = action.payload;
      })
      //Reducer d'inviter des amis à un groupe
      .addCase(InviteFriendToGroup.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.InviteFriendToGroupError = null;
        state.InviteFriendToGroupLoader = true;
      })
      .addCase(InviteFriendToGroup.fulfilled, (state, action) => {
        //Mise à jour de state
        state.InviteFriendToGroupError = null;
        state.InviteFriendToGroupLoader = false;
      })
      .addCase(InviteFriendToGroup.rejected, (state, action) => {
        //Reinitialisation de state
        state.InviteFriendToGroupLoader = false;
        //Mise à jour d'erreur
        state.InviteFriendToGroupError = action.payload;
      })
      //Reducer de creation de groupe
      .addCase(CreateGroupeApi.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.CreatedGroup = {};
        state.CreateGroupeError = null;
        state.CreateGroupeLoader = true;
      })
      .addCase(CreateGroupeApi.fulfilled, (state, action) => {
        //Mise à jour de state
        state.CreateGroupeError = null;
        state.CreateGroupeLoader = false;
        //Mise à jour de creation de groupe
        state.CreatedGroup = action.payload;
      })
      .addCase(CreateGroupeApi.rejected, (state, action) => {
        //Reinitialisation de state
        state.CreateGroupeLoader = false;
        //Mise à jour d'erreur
        state.CreateGroupeError = action.payload;
      })
      //Reducer de retirer de la liste d'amis
      .addCase(RemoveUserFromFriends.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.RemoveUserFromFriendsError = null;
        state.RemoveUserFromFriendsLoader = true;
      })
      .addCase(RemoveUserFromFriends.fulfilled, (state, action) => {
        //mise à jour de state et de la liste d'amis
        state.followedUsers = state.followedUsers.filter((user) => user.uid != action.payload.uid);
        state.RemoveUserFromFriendsError = null;
        state.RemoveUserFromFriendsLoader = false;
      })
      .addCase(RemoveUserFromFriends.rejected, (state, action) => {
        //Reinitialisation de state
        state.RemoveUserFromFriendsLoader = false;
        //Mise à jour d'erreur
        state.RemoveUserFromFriendsError = action.payload;
      })
      //Reducer pour exclure un membre du groupe
      .addCase(RemoveMemberFromGroup.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.RemoveMemberFromGroupError = null;
        state.RemoveMemberFromGroupLoader = true;
      })
      .addCase(RemoveMemberFromGroup.fulfilled, (state, action) => {
        //Mise à jour de state et de la liste de membres de groupe
        state.GroupMembers = state.GroupMembers.filter((member) => member.uid != action.payload.uid);
        state.RemoveMemberFromGroupError = null;
        state.RemoveMemberFromGroupLoader = false;
      })
      .addCase(RemoveMemberFromGroup.rejected, (state, action) => {
        //Reinitialisation de state
        state.RemoveMemberFromGroupLoader = false;
        //Mise à jour d'erreur
        state.RemoveMemberFromGroupError = action.payload;
      })
      //Reducer pour quitter un groupe
      .addCase(RemoveUserFromGroup.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.RemoveUserFromGroupError = null;
        state.RemoveUserFromGroupLoader = true;
      })
      .addCase(RemoveUserFromGroup.fulfilled, (state, action) => {
        //Mise à jour de state et de la liste des groupes
        state.UserGroups = state.UserGroups.filter((group) => group.id != action.payload.id);
        state.RemoveUserFromGroupError = null;
        state.RemoveUserFromGroupLoader = false;
      })
      .addCase(RemoveUserFromGroup.rejected, (state, action) => {
        //Reinitialisation de state
        state.RemoveUserFromGroupLoader = false;
        //Mise à jour d'erreur
        state.RemoveUserFromGroupError = action.payload;
      })
      //Reducer pour accepter une invitation reçue d'amitié
      .addCase(AcceptReceivedFollow.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.AcceptReceivedFollowError = null;
        state.AcceptReceivedFollowLoader = true;
      })
      .addCase(AcceptReceivedFollow.fulfilled, (state, action) => {
        //Mise à jour de state et de la liste des invitations reçues
        state.FollowsReceived = state.FollowsReceived.filter((user) => user.uid != action.payload.uid);
        state.IsFriend = 'Ami';
        state.AcceptReceivedFollowError = null;
        state.AcceptReceivedFollowLoader = false;
      })
      .addCase(AcceptReceivedFollow.rejected, (state, action) => {
        //Reinitialisation de state
        state.AcceptReceivedFollowLoader = false;
        //Mise à jour d'erreur
        state.AcceptReceivedFollowError = action.payload;
      })
      //Reducer pour accepter une invitation reçue d'un group
      .addCase(AcceptReceivedGroupInvite.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.AcceptReceivedGroupInviteError = null;
        state.AcceptReceivedGroupInviteLoader = true;
      })
      .addCase(AcceptReceivedGroupInvite.fulfilled, (state, action) => {
        //Mise à jour de state et de la liste des invitations reçues
        state.GroupeReceivedInvitations = state.GroupeReceivedInvitations.filter(
          (groupe) => !(groupe.id === action.payload.id && groupe.uid === action.payload.sender_id)
        );
        state.AcceptReceivedGroupInviteError = null;
        state.AcceptReceivedGroupInviteLoader = false;
      })
      .addCase(AcceptReceivedGroupInvite.rejected, (state, action) => {
        //Reinitialisation de state
        state.AcceptReceivedGroupInviteLoader = false;
        //Mise à jour d'erreur
        state.AcceptReceivedGroupInviteError = action.payload;
      })
      //Reducer pour rejeter une invitation reçue d'amitié
      .addCase(DeclineReceivedFollow.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.DeclineReceivedFollowError = null;
        state.DeclineReceivedFollowLoader = true;
      })
      .addCase(DeclineReceivedFollow.fulfilled, (state, action) => {
        //Mise à jour de state et de la liste des invitations reçues
        state.FollowsReceived = state.FollowsReceived.filter((user) => user.uid != action.payload.uid);
        state.IsFriend = 'Suggestion';
        state.DeclineReceivedFollowError = null;
        state.DeclineReceivedFollowLoader = false;
      })
      .addCase(DeclineReceivedFollow.rejected, (state, action) => {
        //Reinitialisation de state
        state.DeclineReceivedFollowLoader = false;
        //Mise à jour d'erreur
        state.DeclineReceivedFollowError = action.payload;
      })
      //Reducer pour rejeter l'invitation de groupe reçue
      .addCase(DeclineReceivedGroupInvite.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.DeclineReceivedGroupInviteError = null;
        state.DeclineReceivedGroupInviteLoader = true;
      })
      .addCase(DeclineReceivedGroupInvite.fulfilled, (state, action) => {
        //Mise à jour de state et de la liste des groupe d'invitations reçues
        state.GroupeReceivedInvitations = state.GroupeReceivedInvitations.filter(
          (groupe) => !(groupe.id === action.payload.id && groupe.uid === action.payload.sender_id)
        );
        state.DeclineReceivedGroupInviteError = null;
        state.DeclineReceivedGroupInviteLoader = false;
      })
      .addCase(DeclineReceivedGroupInvite.rejected, (state, action) => {
        //Reinitialisation de state
        state.DeclineReceivedGroupInviteLoader = false;
        //Mise à jour d'erreur
        state.DeclineReceivedGroupInviteError = action.payload;
      })
      //Reducer pour supprimer une invitation envoyé (annuler)
      .addCase(DeleteSentRequest.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.DeleteSentRequestError = null;
        state.DeleteSentRequestLoader = true;
      })
      .addCase(DeleteSentRequest.fulfilled, (state, action) => {
        //Mise à jour de state et de la liste des invitations envoyés
        state.FollowsSent = state.FollowsSent.filter((user) => user.uid != action.payload.uid);
        state.IsFriend = 'Suggestion';
        state.DeleteSentRequestError = null;
        state.DeleteSentRequestLoader = false;
      })
      .addCase(DeleteSentRequest.rejected, (state, action) => {
        //Reinitialisation de state
        state.DeleteSentRequestLoader = false;
        //Mise à jour d'erreur
        state.DeleteSentRequestError = action.payload;
      })
      //Reducer pour supprimer une invitation envoyé de groupe (annuler)
      .addCase(DeleteGroupeSentRequest.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.DeleteGroupeSentRequestError = null;
        state.DeleteGroupeSentRequestLoader = true;
      })
      .addCase(DeleteGroupeSentRequest.fulfilled, (state, action) => {
        //Mise à jour de state et de la liste des invitations envoyés
        state.GroupeSentInvitations = state.GroupeSentInvitations.filter(
          (groupe) => groupe.group_id != action.payload.group_id
        );
        state.DeleteGroupeSentRequestError = null;
        state.DeleteGroupeSentRequestLoader = false;
      })
      .addCase(DeleteGroupeSentRequest.rejected, (state, action) => {
        //Reinitialisation de state
        state.DeleteGroupeSentRequestLoader = false;
        //Mise à jour d'erreur
        state.DeleteGroupeSentRequestError = action.payload;
      })
      //Reducer pour fetch des discussions
      .addCase(getDiscussions.pending, (state, action) => {
        //Initialisation de state et lancement de loader
        state.getDiscussionsError = null;
        state.getDiscussionsLoader = true;
      })
      .addCase(getDiscussions.fulfilled, (state, action) => {
        //Mise à jour de state et de la liste de discussions
        state.getDiscussionsError = null;
        state.getDiscussionsLoader = false;
        state.discussions = action.payload;
      })
      .addCase(getDiscussions.rejected, (state, action) => {
        //Reinitialisation de state
        state.getDiscussionsLoader = false;
        //Mise à jour d'erreur
        state.getDiscussionsError = action.payload;
      })
      //Reducer de fetch de tous les partenaires
      .addCase(getAllPartnersFromDB.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.partnersLoader = true;
        state.partnersReciecedError = null;
      })
      .addCase(getAllPartnersFromDB.fulfilled, (state, action) => {
        //Mise à jour de state et de la liste des partenaires
        state.partnersLoader = false;
        state.partnersReciecedError = null;
        state.partnersAll = action.payload;
      })
      .addCase(getAllPartnersFromDB.rejected, (state, action) => {
        //Reinitialisation de state
        state.partnersLoader = false;
        //Mise à jour d'erreur
        state.partnersReciecedError = action.payload;
      })
      //Reducer de fetch de suggestions des partenaires
      .addCase(getSuggestionPartners.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.partnersLoader = true;
        state.partnersReciecedError = null;
      })
      .addCase(getSuggestionPartners.fulfilled, (state, action) => {
        //Mise à jour de state et de la liste des suggestions de partenaires
        state.partnersLoader = false;
        state.partnersReciecedError = null;
        state.partnersSuggestions = action.payload;
      })
      .addCase(getSuggestionPartners.rejected, (state, action) => {
        //Reinitialisation de state
        state.partnersLoader = false;
        //Mise à jour d'erreur
        state.partnersReciecedError = null;
        state.partnersSuggestions = action.payload;
      })
      //Reducer de fetch de tous les partenaires abonnées
      .addCase(getAllSubscribedPartners.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.partnersLoader = true;
        state.partnersReciecedError = null;
      })
      .addCase(getAllSubscribedPartners.fulfilled, (state, action) => {
        //Mise à jour de state et de la liste des partenaires abonnées
        state.partnersLoader = false;
        state.partnersReciecedError = null;
        state.partnersSubscribed = action.payload;
      })
      .addCase(getAllSubscribedPartners.rejected, (state, action) => {
        //Reinitialisation de state
        state.partnersLoader = false;
        //Mise à jour d'erreur
        state.partnersReciecedError = action.payload;
      })
      //Reducer de fetch de tous les partenaires abonnées d'un ami
      .addCase(getFriendAllSubscribedPartners.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.FriendpartnersLoader = true;
        state.FriendpartnersReciecedError = null;
      })
      .addCase(getFriendAllSubscribedPartners.fulfilled, (state, action) => {
        //Mise à jour de state
        state.FriendpartnersLoader = false;
        state.FriendpartnersReciecedError = null;
        //Mise à jour de la liste des partenaires abonnées d'un ami
        state.FriendpartnersSubscribed = action.payload;
      })
      .addCase(getFriendAllSubscribedPartners.rejected, (state, action) => {
        //Reinitialisation de state
        state.FriendpartnersLoader = false;
        //Mise à jour d'erreur
        state.FriendpartnersReciecedError = action.payload;
      })

      //Reducer d'abonnement aux partenaires
      .addCase(subscribeToPartner.pending, (state) => {
        //initialisation de state et lancement de loader
        state.partnersLoader = true;
        state.partnersSubsLoader = true;
        state.partnersReciecedError = null;
        state.partnerSuccesMessage = '';
      })
      .addCase(subscribeToPartner.fulfilled, (state, action) => {
        //Mise à jour de state et de la liste de suggestions des partenaires et la liste des partenaires abonnées
        state.partnersSuggestions = state.partnersSuggestions.filter((partner) => partner.id != action.payload.id);
        state.partnersSubscribed.push(action.payload);
        state.partnersLoader = false;
        state.partnersSubsLoader = false;
        state.partnersReciecedError = null;
        state.partnerSuccesMessage = action.payload;
      })
      .addCase(subscribeToPartner.rejected, (state, action) => {
        //Reinitialisation de state
        state.partnersLoader = false;
        state.partnersSubsLoader = false;
        //Mise à jour d'erreur
        state.partnersReciecedError = action.payload;
        state.partnerSuccesMessage = '';
      })
      //Reducer de désabonnement aux partenaires
      .addCase(unSubscribeToPartner.pending, (state) => {
        //Initialisation de state et lancement de loader
        state.partnersLoader = true;
        state.partnersSuggestionLoader = true;
        state.partnersReciecedError = null;
        state.partnerSuccesMessage = '';
      })
      .addCase(unSubscribeToPartner.fulfilled, (state, action) => {
        //Mise à jour de state et de la liste des partenaires abonnées
        state.partnersSubscribed = state.partnersSubscribed.filter((partner) => partner.id != action.payload.id);
        state.partnersSuggestions.push(action.payload);
        state.partnersLoader = false;
        state.partnersSuggestionLoader = false;
        state.partnersReciecedError = null;
      })
      .addCase(unSubscribeToPartner.rejected, (state, action) => {
        //Reintialisation de state
        state.partnersLoader = false;
        state.partnersSuggestionLoader = false;
        //Mise à jour d'erreur
        state.partnersReciecedError = action.payload;
        state.partnerSuccesMessage = '';
      });
  },
});
export const { ClearChatData, pushChatData, clearCreatdGroupe, updateCreatedGroupe, clearGroupemebersData } =
  socialSlice.actions;
export default socialSlice.reducer;
