// import * as React from 'react';
// import { createNativeStackNavigator } from '@react-navigation/native-stack';
// import AuthentificationScreen from '../screens/Authentification';
// import SignInScreen from '../screens/SignIn';
// import SignUpScreen from '../screens/SignUp';
// import WhoWeAreSliderScreen from '../screens/whoWeAreSlider';
// import BackButton from '../components/BackButton';
// import ForgotPasswordScreen from '../screens/ForgotPassword';

// const AuthStack = createNativeStackNavigator();

// const AuthNavigator = () => {

//     <AuthStack.Navigator initialRouteName="Authentification">
//       <AuthStack.Screen name="Authentification" component={AuthentificationScreen} options={{ headerShown: false }} />
//       <AuthStack.Screen
//         name="SignIn"
//         component={SignInScreen}
//         options={{ headerTitle: '', headerShadowVisible: false, headerLeft: () => <BackButton /> }}
//       />
//       <AuthStack.Screen
//         name="SignUp"
//         component={SignUpScreen}
//         options={{ headerTitle: '', headerShadowVisible: false, headerLeft: () => <BackButton /> }}
//       />
//       <AuthStack.Screen name="WhoWeAreSlider" component={WhoWeAreSliderScreen} options={{ headerShown: false }} />
//       <AuthStack.Screen
//         name="ForgotPassword"
//         component={ForgotPasswordScreen}
//         options={{ headerTitle: '', headerShadowVisible: false, headerLeft: () => <BackButton /> }}
//       />
//     </AuthStack.Navigator>

// };
// export default AuthNavigator;
