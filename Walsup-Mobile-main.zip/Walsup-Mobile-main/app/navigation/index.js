import * as React from 'react';
import { useEffect, useState } from 'react';
import { NavigationContainer, useNavigation } from '@react-navigation/native';
// import DrawerNavigator from './DrawerNavigator';
import { useDispatch, useSelector } from 'react-redux';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import AuthentificationScreen from '../screens/Authentification';
import SignInScreen from '../screens/SignIn';
import SignUpScreen from '../screens/SignUp';
import WhoWeAreSliderScreen from '../screens/whoWeAreSlider';
import BackButton from '../components/BackButton';
import ForgotPasswordScreen from '../screens/ForgotPassword';
import SigninSuccess from '../screens/SigninSuccess';
import DrawerNavigator from './DrawerNavigator';
import { setSignInCompleted } from '../store/authentication/authenticationSlice';
import { AppState } from 'react-native';
import { getDatabase, ref, child, push, update } from 'firebase/database';
import { useRef } from 'react';

//Creation d'un stack navigator
const AuthStack = createNativeStackNavigator();

// Creation du navigator
const Navigator = () => {
  //Appel à l'utilisateur et à l'etat d'utilisateur connecté
  const { signInCompleted, user } = useSelector((store) => store.authentification);
  //Verification de l'état d'application (background // foreground)
  const appState = useRef(AppState.currentState);
  //Declaration d'une variable dans le state pour l'état d'application
  const [appStateVisible, setAppStateVisible] = useState(appState.current);

  const dispatch = useDispatch();
  //USEEFFECT
  useEffect(() => {
    //Disptach de reducer de verifiaction si l'utilisateur est connecté ou non
    dispatch(setSignInCompleted());
  }, []);

  //USEEFFECT
  useEffect(() => {
    console.log('Navigator mounted, AppState is', appState.current);
    if (!user?.uid) {
      console.log('User is not defined yet.');
      return;
    }

    // Connexion à Realtime database firebase
    const db = getDatabase();
    const updates = {};
    //Ajout d'un listener sur l'état d'application et mise à jour dans la db
    const subscription = AppState.addEventListener('change', (nextAppState) => {
      if (appState.current.match(/inactive|background/) && nextAppState === 'active') {
        updates[`/UserState/${user.uid}/online`] = true;
      } else {
        updates[`/UserState/${user.uid}/online`] = false;
      }
      appState.current = nextAppState;
      setAppStateVisible(appState.current);
      update(ref(db), updates);
      console.log('AppState', appState.current);
    });

    return () => {
      console.log('Navigator unmounted');
      subscription.remove();
    };
  }, [user]);

  //Navigateur qui retourne soit le drawer navigator ou AuthStack( navigateur de page connexion et inscription)
  return (
    <NavigationContainer>
      {signInCompleted && user?.uid ? (
        <DrawerNavigator />
      ) : (
        <AuthStack.Navigator initialRouteName="Authentification">
          <AuthStack.Screen
            name="Authentification"
            component={AuthentificationScreen}
            options={{ headerShown: false }}
          />
          <AuthStack.Screen
            name="SignIn"
            component={SignInScreen}
            options={{ headerTitle: '', headerShadowVisible: false, headerLeft: () => <BackButton /> }}
          />
          <AuthStack.Screen
            name="SignUp"
            component={SignUpScreen}
            options={{ headerTitle: '', headerShadowVisible: false, headerLeft: () => <BackButton /> }}
          />
          <AuthStack.Screen
            name="SigninSuccess"
            component={SigninSuccess}
            options={{ headerTitle: '', headerShadowVisible: false, headerLeft: () => <BackButton /> }}
          />
          <AuthStack.Screen name="WhoWeAreSlider" component={WhoWeAreSliderScreen} options={{ headerShown: false }} />
          <AuthStack.Screen
            name="ForgotPassword"
            component={ForgotPasswordScreen}
            options={{ headerTitle: '', headerShadowVisible: false, headerLeft: () => <BackButton /> }}
          />
        </AuthStack.Navigator>
      )}
    </NavigationContainer>
  );
};

export default Navigator;
