import React, { useState, useEffect } from 'react';
import { useNavigation } from '@react-navigation/native';
import Social from '../screens/Social';
import Header from '../components/Header/Header';
import { useSelector } from 'react-redux';
import Invitations from '../screens/Invitations';
import Suggestions from '../screens/Suggsetions';
import ProfileSocial from '../screens/ProfileSocial';
import SelectFriends from '../screens/SelectFriends';
import CreateGroupe from '../screens/CreateGroupe';
import PartnerProfile from '../screens/PartnerProfile';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Discussions from '../screens/Discussions';
import ChatHeader from '../components/Header/ChatHeader/ChatHeader';
import CreateChat from '../screens/CreateChat';
import ChatScreen from '../screens/Chat';

//Creation d'un stack navigator pour la partie social
const SocialStack = createNativeStackNavigator();

const SocialNavigator = () => {
  const navigation = useNavigation();
  //Appel à l'utilisateur
  const { user } = useSelector((store) => store.authentification);

  //retour des Screen (pages) de stack navigator social (la partie / section social)
  return (
    <SocialStack.Navigator initialRouteName="SocialScreen">
      <SocialStack.Screen
        name="SocialScreen"
        component={Social}
        options={{
          header: ({ navigation, scene }) => <Header title="Social" navigation={navigation} hideBackButton={true} />,
        }}
      />
      <SocialStack.Screen
        name="CreateGroupe"
        component={CreateGroupe}
        options={{
          header: ({ navigation, scene }) => (
            <Header title="Création du groupe" goBackTo="SocialScreen" navigation={navigation} hideBackButton={false} />
          ),
        }}
      />

      <SocialStack.Screen
        name="PartnerProfile"
        component={PartnerProfile}
        options={{
          header: ({ navigation, scene }) => (
            <Header goBackTo="SocialScreen" title="Profil" navigation={navigation} hideBackButton={false} />
          ),
        }}
      />

      <SocialStack.Screen
        name="SelectFriends"
        component={SelectFriends}
        options={{
          header: ({ navigation, scene }) => (
            <Header
              title="Gestion des membres"
              goBackTo="SocialScreen"
              navigation={navigation}
              hideBackButton={false}
            />
          ),
        }}
      />

      <SocialStack.Screen
        name="ProfileSocial"
        component={ProfileSocial}
        options={{
          header: ({ navigation, scene }) => (
            <Header title="Social" goBackTo="SocialScreen" navigation={navigation} hideBackButton={false} />
          ),
        }}
      />
      <SocialStack.Screen
        name="Suggestions"
        component={Suggestions}
        options={{
          header: ({ navigation, scene }) => (
            <Header title="Social" goBackTo="SocialScreen" navigation={navigation} hideBackButton={false} />
          ),
        }}
      />
      <SocialStack.Screen
        name="Invitations"
        component={Invitations}
        options={{
          header: ({ navigation, scene }) => (
            <Header title="Social" goBackTo="SocialScreen" navigation={navigation} hideBackButton={false} />
          ),
        }}
      />
      <SocialStack.Screen
        name="Chat"
        component={Discussions}
        options={{
          header: ({ navigation, scene }) => (
            <ChatHeader
              title="Discussions"
              goBackTo="SocialScreen"
              navigation={navigation}
              hideBackButton={false}
              showIcon={true}
            />
          ),
        }}
      />
      <SocialStack.Screen
        name="CreateChat"
        component={CreateChat}
        options={{
          header: ({ navigation, scene }) => (
            <Header
              title="Nouveau message"
              goBackTo="Chat"
              navigation={navigation}
              hideBackButton={false}
              showImg={false}
            />
          ),
        }}
      />
      <SocialStack.Screen
        name="Discussion"
        component={ChatScreen}
        options={{
          header: ({ navigation, route }) => (
            <ChatHeader goBackTo="Chat" navigation={navigation} showIcon={true} params={route.params} />
          ),
        }}
      />
    </SocialStack.Navigator>
  );
};
export default SocialNavigator;
