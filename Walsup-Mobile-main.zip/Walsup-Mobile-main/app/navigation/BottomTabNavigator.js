import React, { useState, useEffect } from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

import { useFocusEffect, useNavigation } from '@react-navigation/native';

import WorkInProgressScreen from '../screens/WorkInProgress';
import MarketplaceScreen from '../screens/marketplace';
import Feather from 'react-native-vector-icons/Feather';
import OfferDetails from '../screens/OfferDetails';
import PostDetails from '../screens/PostDetails';
import { Image } from 'react-native';
import Header from '../components/Header/Header';
import CreateProfile from '../screens/CreateProfile';
import { useSelector } from 'react-redux';
import WishlistSvg from '../../assets/Icons/components/WishlistSvg';
import SocialSvg from '../../assets/Icons/components/SocialSvg';
import CartSvg from '../../assets/Icons/components/CartSvg';
import SocialNavigator from './SocialNavigator';

//Creation d'un bootom tab navigator
const Tab = createBottomTabNavigator();

function BottomTabNavigator() {
  const navigation = useNavigation();
  //Appel d'utilisateur de store d'authentification
  const { user } = useSelector((store) => store.authentification);

  useEffect(() => {
    //navigation à la partie social pour l'initiation de chat ( car si on accede au chat avant d'accéder à la partie social pour charger les amis et les groupes la partie chat se bug)
    //donc se code c'est pour naviguer à la partie social pour 100 ms et retourner à marketplace
    const unsubscribe = navigation.addListener('focus', () => {
      navigation.navigate('Social');
      setTimeout(() => {
        navigation.navigate('Marketplace');
      }, 100);
    });

    return unsubscribe;
  }, [navigation]);

  //retour des tab Screens (les pages de navigateur bottom tab)
  return (
    <Tab.Navigator
      initialRouteName={user?.gender ? 'Marketplace' : 'CreateProfile'}
      screenOptions={{
        tabBarActiveTintColor: 'rgba(105, 89, 222, 1)',
        tabBarInactiveTintColor: 'grey',
      }}
    >
      <Tab.Screen
        name="Marketplace"
        component={MarketplaceScreen}
        options={{
          header: ({ navigation, scene }) => (
            <Header title="Fill D'actualité" navigation={navigation} hideBackButton={true} />
          ),
          tabBarIcon: ({ color, size, focused }) => {
            return <Feather name="rss" color={color} size={size + 2} fontWeight="bold" />;
          },
          tabBarLabel: () => null,
        }}
      />
      <Tab.Screen
        name="Social"
        component={SocialNavigator}
        options={{
          headerShown: false,
          tabBarIcon: ({ color, size, focused }) => {
            return <SocialSvg scale={{ width: 42, height: 32 }} color={color} />;
          },
          tabBarLabel: () => {
            return null;
          },
        }}
      />
      <Tab.Screen
        name="OfferDetails"
        component={OfferDetails}
        options={{
          tabBarItemStyle: { display: 'none' },
          headerShown: false,
        }}
      />
      <Tab.Screen
        name="PostDetails"
        component={PostDetails}
        options={{
          tabBarItemStyle: { display: 'none' },
          headerShown: false,
        }}
      />

      <Tab.Screen
        name="Wallet"
        component={WorkInProgressScreen}
        options={{
          header: ({ navigation, scene }) => <Header title="Wallet" navigation={navigation} hideBackButton={true} />,
          tabBarIcon: ({ color, size, focused }) => (
            <Image
              source={
                focused
                  ? require(`../../assets/Icons/iconeWalsup.png`)
                  : require(`../../assets/Icons/walsupinactive.png`)
              }
              style={{ top: 6 }}
            />
          ),
          //<Image source={require('../../assets/Icons/iconeWalsup.png')} />,
          tabBarLabel: () => {
            return null;
          },
          tabBarOnPress: ({ navigation }) => {
            handleIconPress();
            navigation.navigate(WorkInProgressScreen);
          },
        }}
      />
      <Tab.Screen
        name="Wishlist"
        component={WorkInProgressScreen}
        options={{
          header: ({ navigation, scene }) => <Header title="Wishlist" navigation={navigation} hideBackButton={true} />,
          tabBarIcon: ({ color, size, focused }) => {
            return <WishlistSvg scale={{ width: 24, height: 32 }} color={color} />;
            // <Ionicons name="bookmark-outline" color={color} size={size + 2} fontWeight="bold" />;
          },
          tabBarLabel: () => {
            return null;
          },
        }}
      />
      <Tab.Screen
        name="Cart"
        component={WorkInProgressScreen}
        options={{
          header: ({ navigation, scene }) => <Header title="Cart" navigation={navigation} hideBackButton={true} />,
          tabBarIcon: ({ color, size }) => (
            <CartSvg scale={{ width: 42, height: 32 }} color={color} />
            // <Feather name="shopping-cart" color={color} size={size} />
          ),
          tabBarLabel: () => {
            return null;
          },
        }}
      />
      <Tab.Screen
        name="CreateProfile"
        component={CreateProfile}
        options={{
          tabBarItemStyle: { display: 'none' },
          headerTitle: 'Gestion de Profile',
          headerShadowVisible: false,
          headerTitleStyle: { alignSelf: 'center' },
          tabBarStyle: { display: 'none' },
        }}
      />
      <Tab.Screen
        name="WorkInProgressScreen"
        component={WorkInProgressScreen}
        options={{
          header: ({ navigation, scene }) => (
            <Header title="WorkInProgress" navigation={navigation} hideBackButton={true} />
          ),
          tabBarItemStyle: { display: 'none' },
        }}
      />
      <Tab.Screen
        name="Notifications"
        component={WorkInProgressScreen}
        options={{
          header: ({ navigation, scene }) => (
            <Header title="Notifications" navigation={navigation} hideBackButton={true} />
          ),
          tabBarItemStyle: { display: 'none' },
        }}
      />
    </Tab.Navigator>
  );
}

export default BottomTabNavigator;
