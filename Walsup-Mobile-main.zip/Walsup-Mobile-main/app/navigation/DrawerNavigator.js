import * as React from 'react';

import { createDrawerNavigator } from '@react-navigation/drawer';
import WorkInProgressScreen from '../screens/WorkInProgress';
import BottomTabNavigator from './BottomTabNavigator';
import Disconnect from '../screens/Disconnect';
import Authentification from '../screens/Authentification';
import UpdateProfile from '../screens/UpdateProfile';
import Preferences from '../screens/Preferences';
import Interests from '../screens/Interests';
import DrawerHeader from '../components/Header/DrawerHeader/DrawerHeader';
import Header from '../components/Header/Header';
import { Image, Text, TouchableWithoutFeedback, View } from 'react-native';
import Feather from 'react-native-vector-icons/Feather';
import { useNavigation } from '@react-navigation/native';
import PreferenceSvg from '../../assets/Icons/components/PreferenceSvg';
import ProfileSvg from '../../assets/Icons/components/ProfileSvg';
import { useSelector } from 'react-redux';
import { useState } from 'react';
import Filtre from '../screens/FiltreMarketplace/Filtre';

//creation d'un Drawer navigateur
const Drawer = createDrawerNavigator();

//creation du navigateur
function DrawerNavigator() {
  //Appel à l'utilisateur de store de authentifiaction
  const { user } = useSelector((store) => store.authentification);

  const navigation = useNavigation();
  const [marginTabs, setMarginTabs] = useState({
    horizontal: 20,
    vertical: 20,
    bottom: 20,
    finBottom: 90,
    TopBottom: 80,
  });

  //retour des pages (Screens) de Drawer
  return (
    <Drawer.Navigator
      initialRouteName="Accueil"
      screenOptions={{
        drawerStyle: {
          backgroundColor: 'rgba(242, 242, 242, 1)',
          width: '80%',
        },
        drawerContentContainerStyle: { flex: 1, flexDirection: 'column', justifyContent: 'flex-end' },
        drawerActiveBackgroundColor: 'rgba(105, 89, 222, 0.3)',
        drawerInactiveBackgroundColor: 'rgba(255, 255, 255, 1)',
      }}
    >
      <Drawer.Screen
        name={'Gestion de Profile'}
        component={UpdateProfile}
        options={{
          drawerItemStyle: {
            width: '90%',
            height: 93,
            top: '-9%',
            marginRight: 10,
            borderRadius: 10,
          },
          header: (props) => <DrawerHeader background="white" title="Gestion de Profile" goBackTo="Accueil" />,
          drawerLabel: () => {
            return (
              <View
                style={{
                  marginTop: 12,
                  flexDirection: 'row',
                  justifyContent: 'flex-start',
                  width: '100%',
                  height: '100%',
                }}
              >
                <View>
                  <Image
                    style={{ width: 48, height: 48, borderRadius: 10, marginRight: 10, marginLeft: 10 }}
                    source={
                      user.profile_image
                        ? {
                            uri: user.profile_image.replace('localhost', '10.0.2.2'),
                          }
                        : require('../../assets/profile.png')
                    }
                  />
                </View>
                <View>
                  <Text
                    style={[
                      {
                        fontFamily: 'Poppins-Bold',
                        lineHeight: 30,
                        height: 30,
                        color: 'rgba(19, 15, 38, 1)',
                      },
                      user?.last_name?.length >= 10
                        ? { fontSize: 17 }
                        : user?.first_name?.length >= 10
                        ? { fontSize: 17 }
                        : { fontSize: 20 },
                      ,
                    ]}
                  >
                    {user?.first_name && user?.last_name ? user?.first_name + ' ' + user?.last_name : 'walsup'}
                  </Text>
                  <Text
                    style={[
                      {
                        fontFamily: 'Poppins-Regular',
                        lineHeight: 18,
                        height: 18,
                        color: 'rgba(19, 15, 38, 1)',
                      },
                      user?.last_name?.length >= 10
                        ? { fontSize: 10 }
                        : user?.first_name?.length >= 10
                        ? { fontSize: 10 }
                        : { fontSize: 12 },
                      ,
                    ]}
                  >
                    @{user?.first_name && user?.last_name ? user?.first_name + '.' + user?.last_name : 'walsup'}
                  </Text>
                </View>
              </View>
            );
          },
        }}
      />
      <Drawer.Screen
        name="Accueil"
        component={BottomTabNavigator}
        options={{
          drawerItemStyle: {
            display: 'none',
          },
          headerShown: false,
          drawerIcon: ({ color, size }) => <Feather name="home" color="#6959DE" size={size} />,
          drawerLabelStyle: {
            fontSize: 17,
            fontFamily: 'Poppins-Regular',
            lineHeight: 24,
            height: 24,
            marginBottom: 1,
            color: 'rgba(19, 15, 38, 1)',
            letterSpacing: 0.5,
          },
        }}
      />
      <Drawer.Screen
        name="Mon compte"
        component={WorkInProgressScreen}
        options={{
          drawerItemStyle: {
            marginBottom: marginTabs.bottom,
            width: '80%',
            height: 56,
            borderRadius: 10,
            marginHorizontal: 20,
            paddingVertical: 3,
          },
          header: (props) => <DrawerHeader title="Mon compte" goBackTo="Accueil" />,
          drawerIcon: () => <ProfileSvg scale={{ width: 25, height: 25, stroke: 3 }} />,
          drawerLabelStyle: {
            fontSize: 17,
            fontFamily: 'Poppins-Regular',
            lineHeight: 24,
            height: 24,
            marginBottom: 1,
            color: 'rgba(19, 15, 38, 1)',
            letterSpacing: 0.5,
          },
        }}
      />
      <Drawer.Screen
        name="Mes Preferences"
        component={Preferences}
        options={{
          drawerItemStyle: {
            marginBottom: marginTabs.bottom,
            width: '80%',
            height: 56,
            borderRadius: 10,
            marginHorizontal: 20,
            paddingVertical: 3,
          },
          header: (props) => <DrawerHeader title="Mes Preferences" goBackTo="Accueil" />,
          drawerIcon: ({ color, size }) => <PreferenceSvg scale={{ width: 25, height: 25, stroke: 2 }} />,
          drawerLabelStyle: {
            fontSize: 17,
            fontFamily: 'Poppins-Regular',
            lineHeight: 24,
            height: 24,
            marginBottom: 1,
            color: 'rgba(19, 15, 38, 1)',
            letterSpacing: 0.5,
          },
        }}
      />
      <Drawer.Screen
        name="Interests"
        component={Interests}
        options={{
          drawerItemStyle: { display: 'none' },
          header: (props) => <DrawerHeader background="white" title="Centres d'intérêt" goBackTo="Mes Preferences" />,
        }}
      />
      <Drawer.Screen
        name="Filtre"
        component={Filtre}
        options={{
          drawerItemStyle: { display: 'none' },
          header: (props) => <DrawerHeader background="white" title="Filtres" goBackTo="Marketplace" />,
        }}
      />
      <Drawer.Screen
        name="Sécurité"
        component={WorkInProgressScreen}
        options={{
          drawerItemStyle: {
            marginBottom: marginTabs.bottom,
            width: '80%',
            height: 56,
            borderRadius: 10,
            marginHorizontal: 20,
            paddingVertical: 3,
          },
          header: (props) => <DrawerHeader title="Sécurité" goBackTo="Accueil" />,
          drawerIcon: ({ color, size }) => <Feather name="unlock" color="#6959DE" size={size} />,
          drawerLabelStyle: {
            fontSize: 17,
            fontFamily: 'Poppins-Regular',
            lineHeight: 24,
            height: 24,
            marginBottom: 1,
            color: 'rgba(19, 15, 38, 1)',
            letterSpacing: 0.5,
          },
        }}
      />
      <Drawer.Screen
        name="Contact-nous"
        component={WorkInProgressScreen}
        options={{
          drawerItemStyle: {
            marginBottom: marginTabs.bottom,
            width: '80%',
            height: 56,
            borderRadius: 10,
            marginHorizontal: 20,
            paddingVertical: 3,
          },
          header: (props) => <DrawerHeader title="Contact-nous" goBackTo="Accueil" />,
          drawerIcon: ({ color, size }) => <Feather name="phone-call" color="#6959DE" size={size} />,
          drawerLabelStyle: {
            fontSize: 17,
            fontFamily: 'Poppins-Regular',
            lineHeight: 24,
            height: 24,
            marginBottom: 1,
            color: 'rgba(19, 15, 38, 1)',
            letterSpacing: 0.5,
          },
        }}
      />
      <Drawer.Screen
        name="A propos"
        component={WorkInProgressScreen}
        options={{
          drawerItemStyle: {
            marginBottom: marginTabs.finBottom,
            width: '80%',
            height: 56,
            borderRadius: 10,
            marginHorizontal: 20,
            paddingVertical: 3,
          },
          header: (props) => <DrawerHeader title="A propos" goBackTo="Accueil" />,
          drawerIcon: ({ color, size }) => <Feather name="alert-circle" color="#6959DE" size={size} />,
          drawerLabelStyle: {
            fontSize: 17,
            fontFamily: 'Poppins-Regular',
            lineHeight: 24,
            height: 24,
            marginBottom: 1,
            color: 'rgba(19, 15, 38, 1)',
            letterSpacing: 0.5,
          },
        }}
      />

      <Drawer.Screen
        name="Déconnexion"
        component={Disconnect}
        options={{
          drawerItemStyle: {
            width: '80%',
            bottom: '2%',
            height: 56,
            borderRadius: 10,
            marginHorizontal: 20,
          },
          headerShown: false,
          drawerIcon: ({ color, size }) => <Feather name="log-out" color="#6959DE" size={size} />,
          drawerLabelStyle: {
            fontSize: 17,
            fontFamily: 'Poppins-Regular',
            lineHeight: 24,
            height: 24,
            marginBottom: 1,
            color: 'rgba(19, 15, 38, 1)',
            letterSpacing: 0.5,
          },
        }}
      />
      <Drawer.Screen
        name="Authentification"
        component={Authentification}
        options={{
          headerShown: false,
          drawerItemStyle: { display: 'none' },
        }}
      />
      <Drawer.Screen
        name="WorkInProgress"
        component={WorkInProgressScreen}
        options={{
          header: (props) => <DrawerHeader goBackTo="Accueil" title="WorkInProgress" />,
          drawerItemStyle: { display: 'none' },
        }}
      />
    </Drawer.Navigator>
  );
}
export default DrawerNavigator;
