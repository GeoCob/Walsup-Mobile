// useEffect(() => {
//     async function fetchData() {
//       await dispatch(getAllGroupsById(user.uid));
//       await dispatch(getfollowedUsers(user.uid));
//     }
//     fetchData();
//   }, []);




// useFocusEffect(
  //   useCallback(() => {
  //     const friendsChat = [];
  //     const groupsChat = [];
  //     const chatRef = ref(database, `chatRooms`);
  //     setLoading(true);
  //     onValue(chatRef, (snapshot) => {
  //       const chatData = snapshot.val();
  //       if (followedUsers) {
  //         followedUsers.forEach((user) => {
  //           const friendChat = {
  //             ...user,
  //             lastMessage: chatData[user.friend_request_id]
  //               ? chatData[user.friend_request_id]['messages'][
  //                   Object.keys(chatData[user.friend_request_id]['messages']).pop()
  //                 ]['text']
  //               : '',
  //           };
  //           chatData[user.friend_request_id] ? friendsChat.push(friendChat) : null;
  //         });
  //       }
  //       if (UserGroups) {
  //         // console.log(UserGroups)
  //         UserGroups.forEach((group) => {
  //           const groupChat = {
  //             ...group,
  //             lastMessage: chatData[group.id]
  //               ? chatData[group.id]['messages'][Object.keys(chatData[group.id]['messages']).pop()]['text']
  //               : '',
  //           };
  //           groupsChat.push(groupChat);
  //         });
  //       }
  //       setData([...friendsChat, ...groupsChat]);
  //     });
  //     setLoading(false);
  //   }, [UserGroups, followedUsers])
  // );
  // useEffect(() => {
  //   console.log("data",data)
  // }, [data])




  // const navigateToDiscussion = async (item, type) => {
  //   dispatch(getDiscussionData(item));
  //   if (type === 'group') {
  //     const chatRef = ref(database, `chatRooms/${item.id}`);
  //     const chatSnapshot = await get(child(chatRef, 'members'));
  //     if (!chatSnapshot) {
  //       // Create some default data in chatRef if no data exists
  //       await set(chatRef, {
  //         members: item.user_ids,
  //       });
  //     }
  //   } else if (type === 'individual') {
  //     const chatRef = ref(database, `chatRooms/${item.friend_request_id}/messages`);
  //     const chatSnapshot = await get(child(chatRef, 'data'));
  //     if (!chatSnapshot) {
  //       // Create some default data in chatRef if no data exists
  //       await set(chatRef, {
  //         data: 'Default chat data',
  //       });
  //     }
  //   }
  //   // Navigate to the "Discussion" component
  //   navigation.navigate('Discussion', {
  //     chatId: type === 'group' ? item.id : item.friend_request_id,
  //   });
  // };




//   {searchResults?.length && searchPhrase && searchResults ? (
//     searchResults?.map((item, i) => {
//       return item.id ? (
//         <View style={styles.Group} key={i}>
//           <View style={styles.Group}>
//             <TouchableOpacity style={styles.GroupInfo} onPress={() => console.log("handle navigations HERE!!")}>
//               {item.commercial_offer_id == null ? (
//                 <Image
//                   style={styles.Groupsimage2}
//                   source={{ uri: item.group_imgs[1].replace('localhost', '10.0.2.2') }}
//                 />
//               ) : null}
//               <Image
//                 style={styles.Groupsimage}
//                 source={{ uri: item.group_imgs[0].replace('localhost', '10.0.2.2') }}
//               />
//               <Text style={styles.GroupName}>{item.name}</Text>
//               <Text style={styles.GroupName}>{item.lastMessage}</Text>
//             </TouchableOpacity>
//             <TouchableOpacity>
//               <Feather name="more-vertical" size={20} style={styles.threeDotsIcon} onPress={() => {}} />
//             </TouchableOpacity>
//           </View>
//         </View>
//       ) : (
//         <View style={styles.Ami} key={i}>
//           <TouchableOpacity style={styles.AmiInfo} onPress={() => console.log("handle navigations HERE!!")}>
//             <Image
//               style={styles.Amisimage}
//               source={{
//                 uri: serverSection ? item.profile_image : item.profile_image.replace('localhost', '10.0.2.2'),
//               }}
//             />
//             <Text style={styles.AmiName}>{item.first_name + ' ' + item.last_name}</Text>
//             <Text style={styles.AmiName}>{item.lastMessage}</Text>
//           </TouchableOpacity>
//           <TouchableOpacity>
//             <Feather name="more-vertical" size={20} style={styles.threeDotsIcon} onPress={() => {}} />
//           </TouchableOpacity>
//         </View>
//       );
//     })
//   ) : !searchResults?.length && searchPhrase && searchResults ? (
//     <NoSocialData Description="Auccun amis de ce nom" />
    // 
    // Groupe section after !!!!!
    // 
//   ) : (
//     data?.map((item, i) =>
//       item.id ? (
//         <View style={styles.Group} key={i}>
//           <View style={styles.Group}>
//             <TouchableOpacity style={styles.GroupInfo} onPress={() => console.log("handle navigations HERE!!")}>
//               {item.commercial_offer_id == null ? (
//                 <Image
//                   style={styles.Groupsimage2}
//                   source={{ uri: item.group_imgs[1].replace('localhost', '10.0.2.2') }}
//                 />
//               ) : null}
//               <Image
//                 style={styles.Groupsimage}
//                 source={{ uri: item.group_imgs[0].replace('localhost', '10.0.2.2') }}
//               />
//               <Text style={styles.GroupName}>{item.name}</Text>
//               <Text style={styles.GroupName}>{item.lastMessage}</Text>
//             </TouchableOpacity>
//             <TouchableOpacity>
//               <Feather name="more-vertical" size={20} style={styles.threeDotsIcon} onPress={() => {}} />
//             </TouchableOpacity>
//           </View>
//         </View>
//       ) : (
        
//       )
//     )
//   )}

//   : !loading && data.length === 0 ? (
//     <NoSocialData Description="Liste des Amis est Vide" />
//   ) : null}

// const onValueCallbackGroupe = snapShot =>{
//   const value = snapShot.val()
//   if(value){
//     let array_1 = value;
//     let array_2 = UserGroups;
//     array_2 = array_2.map(obj => ({ ...obj, id: obj.id.toString() }));

//     let mergedObject = {...array_1};
//     array_2.forEach(obj2 => {
//         let key = obj2.id;
//         if (mergedObject[key]) {
//             mergedObject[key] = { ...mergedObject[key], ...obj2 };
//         } else {
//             mergedObject[key] = obj2;
//         }
//     });
//     let mergedArray = Object.values(mergedObject);
//     setGroupeConversations(mergedArray);
//   } else{
//     setGroupeConversations([]);
//   }
//   setLoadingGroupes(false);
// };