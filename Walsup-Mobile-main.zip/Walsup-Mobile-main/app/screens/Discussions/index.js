import { StyleSheet, Text, View, TouchableOpacity, Image, ScrollView, ActivityIndicator } from 'react-native';
import React, { useCallback, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { serverSection } from '../../../config/servConf';
import { child, get, getDatabase, onValue, ref, push, serverTimestamp, set, off } from 'firebase/database';
import { useFocusEffect } from '@react-navigation/native';
import SearchBarComponent from '../../components/SearchBar';
import NoSocialData from '../../components/noSocialData';
import { ClearChatData } from '../../store/social/socialSlice';
import { clearPrivateChatRecieverData } from '../../store/social/privateChatSlice';
import { clearGroupeChatRecieverData } from '../../store/social/groupeChatSlice';
import CardChatUser from '../CreateChat/CardChatUser';
import { getfollowedUsers, getAllGroupsById, getGroupMembers } from '../../store/social/socialThunk';
import { FlatList } from 'react-native-gesture-handler';

//Composant principal de discussions
const Discussions = ({ navigation }) => {
  const dispatch = useDispatch();
  //Appel à l'utilisateur depuis le store d'authentification
  const { user } = useSelector((store) => store.authentification);
  //Appel aux amis ,groupes et membres des groupes depuis le store social et le loader
  const { followedUsers, UserGroups, GroupMembers, GroupMembersLoader } = useSelector((store) => store.social);
  //const [data, setData] = useState([]);
  //Declaration d'une variable dans le state pour le stockage des conversations
  const [privateConversations, setPrivateConversations] = useState([]);
  //Declaration d'une variable dans le state pour loading
  const [loading, setLoading] = useState(false);
  //Declaration d'une variable dans le state pour le click sur une discussion
  const [clicked, setClicked] = useState(false);
  //Declaration d'une varaible dans le state pour la phrase de recherche
  const [searchPhrase, setSearchPhrase] = useState('');
  //Declaration d'une variable dans le state pour la status de recherche et de la bar de recherche
  const [searchingStatus, setSearchStatus] = useState(false);
  //Declaration d'une variable dans le state pour le résultat de recherche
  const [searchResults, setSearchResults] = useState([]);
  //Fonction de recherche (filtre des conversations )
  const SearchHandle = () => {
    const newState = privateConversations?.filter((search) =>
      search.first_name
        ? search.first_name.toLowerCase().includes(searchPhrase.toLowerCase()) ||
          search.last_name.toLowerCase().includes(searchPhrase.toLowerCase())
        : search.groupeName.toLowerCase().includes(searchPhrase.toLowerCase())
    );
    //Mise à jour de la recherche
    setSearchResults(newState);
    setSearchStatus(true);
  };
  //Fonction de reset d'état de recherche
  const ressetSearch = () => {
    setSearchResults([]);
    setSearchPhrase('');
    setSearchStatus(false);
    setClicked(false);
  };
  //UseFocusEffect pour le reset des conversations
  useFocusEffect(
    useCallback(() => {
      //Appel au reducer pour reset de données de chat
      dispatch(ClearChatData());
      //Appel au reducer pour reset des données de l'utilisateur qu'on discute avec dans un chat individuel
      dispatch(clearPrivateChatRecieverData());
      //Appel au reducer pour reset des données de groupe qu'on discute avec dans un chat de groupe
      dispatch(clearGroupeChatRecieverData());
    }, [])
  );
  //useFocusEffect
  useFocusEffect(
    useCallback(() => {
      if (user.uid) {
        // dispatch(ClearChatData());
        // Appel au reducer de fetch des amis;
        dispatch(getfollowedUsers(user.uid));
        // Appel au reducer de fetch des groupes
        dispatch(getAllGroupsById(user.uid));
      }
    }, [followedUsers?.length, UserGroups?.length, user.uid])
  );
  //UseFocusEffect pour fetch des données depuis la base de données firebase pour les conversations
  useFocusEffect(
    useCallback(() => {
      //reset de données des conversations
      setPrivateConversations([]);
      //Lancement d'un loader
      setLoading(true);
      //Appel à la base de données firebase
      const db = getDatabase();
      //reference à la base de données
      const dbRef = ref(db, `privateChatConversation/${user.uid}`);
      //Fonction de fetch des conversations d'utilisateur connecté
      const onValueCallbackPrivate = (snapShot) => {
        const value = snapShot.val();
        if (value) {
          //Mise à jour des données des conversations s'ils existent
          const newData = Object.entries(value).map(([id, value]) => ({ id, ...value }));
          newData.sort((a, b) => b.lastMessageCreationDate - a.lastMessageCreationDate);
          setPrivateConversations(newData);
        } else {
          //Sinon reset des données des conversations
          setPrivateConversations([]);
        }
        //reset de loader
        setLoading(false);
      };
      //Appel à la fonction de fetch des conversations
      onValue(dbRef, onValueCallbackPrivate);
      //Appel à la fonction de fetch des conversations pour le mise à jour
      return () => off(dbRef, onValueCallbackPrivate);
    }, [privateConversations?.length])
  );

  // ===================================== //
  // flattening the freinds and groupes arrays in one collection
  // ===================================== //

  //Fonction d'accées à une discussion individuelle si elle existe dans la base sinon on la crée dans la base de données
  const handleChatAccessNavigation = async (conversationID, recieverId) => {
    //Filtre et extraction de l'ami à discuter avec
    const recieverData = followedUsers.filter((item) => item.uid === recieverId);
    //navigation vers la discussion on passant l'id de la conversation , l'id d'utilisateur et ses données
    navigation.navigate('Discussion', {
      conversationId: conversationID,
      recieverId: recieverId,
      recieverData: recieverData[0],
      type: 'default',
    });
  };
  //Fonction d'accées à une discussion de groupe si elle existe dans la base de données sinon on la crée
  const handleChatGroupeNavigation = async (groupeId, membersData) => {
    //filtre des groupes d'utilisateur connecté à discuter avec
    const groupeData = UserGroups.filter((item) => item.id.toString() === groupeId);
    //extraction des membres
    const members = groupeData[0].member_ids;
    //Appel au reducer de fetch des membres (leurs données)
    dispatch(getGroupMembers(members));
    //restructuration des membres
    let groupeMembersObject = GroupMembers.reduce((acc, item) => {
      acc[item.uid] = item;
      return acc;
    }, {});

    console.log(groupeMembersObject[groupeData[0].member_ids[0]]['first_name']);
    //Si les membres sont chargé on navigue vers la discussion on passant l'id de conversation , les membres et leurs données
    if (groupeMembersObject[groupeData[0].member_ids[0]]['first_name']) {
      navigation.navigate('Discussion', {
        conversationId: groupeId,
        GroupMembers: groupeMembersObject,
        recieverData: groupeData[0],
        type: 'groupe',
      });
    }
  };

  // don't forget to implement the ssearch for the conversations

  return (
    <View
      style={{
        backgroundColor: 'white',
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'flex-start',
        alignContent: 'center',
      }}
    >
      <SearchBarComponent
        clicked={clicked}
        setClicked={setClicked}
        searchPhrase={searchPhrase}
        setSearchPhrase={setSearchPhrase}
        search={SearchHandle}
        setSearchStatus={setSearchStatus}
        ressetSearch={ressetSearch}
      />
      {!loading && privateConversations?.length > 0 ? (
        <ScrollView style={{ flex: 0.9, backgroundColor: 'white' }}>
          {searchResults?.length && searchPhrase && searchResults ? (
            searchResults?.map((item, index) => (
              <CardChatUser
                item={item}
                key={index}
                type={'discussions'}
                handleCallOne={item?.profile_image ? handleChatAccessNavigation : handleChatGroupeNavigation}
              />
            ))
          ) : !searchResults?.length && searchPhrase && searchResults && searchingStatus ? (
            <NoSocialData Description="Auccun resulta" />
          ) : (
            privateConversations?.map((item, index) => (
              <CardChatUser
                item={item}
                key={index}
                type={'discussions'}
                handleCallOne={item?.profile_image ? handleChatAccessNavigation : handleChatGroupeNavigation}
              />
            ))
          )}
        </ScrollView>
      ) : !loading && !privateConversations?.length ? (
        <NoSocialData Description="Liste des Amis est Vide" />
      ) : (
        <ActivityIndicator />
      )}
    </View>
  );
};

export default Discussions;
