import { Text, StyleSheet, Image, View, TouchableOpacity } from 'react-native';
import {
  child,
  get,
  getDatabase,
  onValue,
  ref,
  push,
  serverTimestamp,
  set,
  off,
  update,
  runTransaction,
  increment,
} from 'firebase/database';
import React, { Component } from 'react';
import { useEffect } from 'react';
import SearchBarComponent from '../../components/SearchBar';
import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import AmiCard from '../../components/AmiCard';
import { serverSection } from '../../../config/servConf';
import { ScrollView } from 'react-native-gesture-handler';
import CustomButton from '../../components/Button';
import { AntDesign } from '@expo/vector-icons';
import {
  CreateGroupeApi,
  getDiscussionData,
  getGroupMembers,
  InviteFriendToGroup,
} from '../../store/social/socialThunk';
import { useNavigation } from '@react-navigation/native';
import NoSocialData from '../../components/noSocialData';
import ModalComponent from '../../components/Modal';

//Composant de selection des amis à ajouter dans un groupe
const SelectFriends = ({ route, navigation }) => {
  //Appel de groupeType , type , doing ,item de params de route
  const { GroupeType, type, doing, item } = route.params;
  //Declaration d'une variable dans le state initialisé par false pour la bar de recherche
  const [clicked, setClicked] = useState(false);
  //Appel à l'utilisateur depuis le store d'authentification
  const { user } = useSelector((store) => store.authentification);
  //Declaration d'une variable dans le state initilisé par string vide pour la phrase de recherche
  const [searchPhrase, setSearchPhrase] = useState('');
  //Declaration d'une variable dans le state pour la recherche selon la fonctionnalité à faire (creation de groupe , invitation de membres...)
  const [modifierSearchType, setModifierSearchType] = useState('CreationGroupe');
  //Appel des amis et loader ,des membres de groupes (si le groupe est déjà crée) depuis le store social
  const { followedUsers, followedUsersLoader, CreatedGroup, GroupMembers } = useSelector((store) => store.social);
  //Declaration d'une variable dans le state initialisé par false pour l'état de recherche
  const [searchingStatus, setSearchStatus] = useState(false);
  //Declaration d'un variable dans le state pour les amis selectionnées intialisé par array vide
  const [selectedFriends, setSelectedFriends] = useState([]);
  //Declaration d'une variable dans le state pour les Ids des amis selectionnées intialisé par array vide
  const [selectedFriendsUids, setSelectedFriendsUids] = useState([]);
  //Declaration d'une variable dans le state intialisé par array vide pour la résultat de recherche
  const [searchResults, setSearchResults] = useState([]);
  //Declaration d'une variable dans le state pour les utilisateurs à inviter initialisé par array vide
  const [UsresToInvite, setUsersToInvite] = useState([]);
  //Declaration d'une variable dans le state pour la visibilité de modal intialisé par false
  const [isModalVisible, setisModalVisible] = useState(false);
  //Declaration d'une variable dans le state pour l'utilisateur (membre) à expulser du groupe
  const [MemberToKick, setMemberToKick] = useState(false);
  const dispatch = useDispatch();

  //Fonction de toggle de visibilité de modal des membres
  const ModalVisibiltyToggleMemebers = (user) => {
    setMemberToKick(user);
    setisModalVisible(!isModalVisible);
  };

  //UseEffect pour le reset de state
  useEffect(() => {
    setSelectedFriends([]);
    setSelectedFriendsUids([]);
  }, [GroupeType]);

  //UseEffect
  useEffect(() => {
    //Reset de state
    setSelectedFriends([]);
    setSelectedFriendsUids([]);
    //doing c'est une variable qui a une valeur soit Invite soit Membres ou bien null(creation de groupe)
    if (doing === 'Invite') {
      //set dans le state des utilisateur amis avec l'utilisateur connecté qui ne sont ni admin ni membre de groupe
      setUsersToInvite(
        followedUsers.filter((user) => !item.member_ids.includes(user.uid) && user.uid != item.user_admin_id)
      );
    } else if (doing === 'Members') {
      //Appel de reducer de fetch des membres de groupe
      // console.log('group members uids', item.member_ids);
      dispatch(getGroupMembers(item.member_ids));
      // console.log('group members users', GroupMembers);
    }
  }, [item, doing]);

  //Fonction de check (symbol check) d'utilisateur selectionné
  const checkselectedFriends = (user) => {
    return selectedFriends.includes(user);
  };

  //Fonction de recherche qui filtre l'utilisateur selon la recherche
  const SearchHandle = () => {
    if (doing === 'Invite') {
      const newState = UsresToInvite?.filter(
        (search) =>
          search.first_name.toLowerCase().includes(searchPhrase.toLowerCase()) ||
          search.last_name.toLowerCase().includes(searchPhrase.toLowerCase())
      );
      setSearchResults(newState);
      setSearchStatus(true);
    } else if (doing === 'Members') {
      const newState = GroupMembers?.filter(
        (search) =>
          search.first_name.toLowerCase().includes(searchPhrase.toLowerCase()) ||
          search.last_name.toLowerCase().includes(searchPhrase.toLowerCase())
      );
      setSearchResults(newState);
      setSearchStatus(true);
    } else if (type === 'groupeCreate') {
      const newState = followedUsers?.filter(
        (search) =>
          search.first_name.toLowerCase().includes(searchPhrase.toLowerCase()) ||
          search.last_name.toLowerCase().includes(searchPhrase.toLowerCase())
      );
      setSearchResults(newState);
      setSearchStatus(true);
    }
  };

  //Fonction de reset de la recherche
  const ressetSearch = () => {
    setSearchResults([]);
    setSearchPhrase('');
    setSearchStatus(false);
    setClicked(false);
  };

  //Fonction de submission de selection des amis pour la creation de groupe
  const SubmitFriends = () => {
    //Navigation vers la page de creation de groupe
    navigation.navigate('CreateGroupe', {
      GroupeType: GroupeType,
      selectedFriendsUids: selectedFriendsUids,
      setSelectedFriendsUids: setSelectedFriendsUids,
      setSelectedFriends: setSelectedFriends,
    });
  };

  //Fonction d'invitation des amis
  const InviteFriends = async () => {
    //set des données de selection dans un objet
    const data = {
      user_ids: selectedFriendsUids,
      group_id: item.id,
    };
    //Appel au reducer  d'invitation des amis à un groupe
    dispatch(InviteFriendToGroup(data));
    //refernce à la base de données firebase
    const dbRef = ref(getDatabase());
    try {
      //fetch de conversation de groupe
      const groupeLastData = await get(child(dbRef, `privateChatConversation/${item.user_admin_id}/${item.id}`));
      //si la conversation existe
      if (groupeLastData.exists()) {
        const result = groupeLastData.val();
        let updates = {};
        //pour chaque nouveau de membre creation et insertion des données dans la base
        selectedFriendsUids.forEach((elem) => {
          updates['privateChatConversation/' + elem + '/' + item.id + '/badges'] = 0;
          updates['privateChatConversation/' + elem + '/' + item.id + '/creationDate'] = serverTimestamp();
          updates['privateChatConversation/' + elem + '/' + item.id + '/group_img'] = result.group_img;
          updates['privateChatConversation/' + elem + '/' + item.id + '/groupeName'] = result.groupeName;
          updates['privateChatConversation/' + elem + '/' + item.id + '/lastMessage'] = result.lastMessage;
          updates['privateChatConversation/' + elem + '/' + item.id + '/lastMessageCreationDate'] =
            result.lastMessageCreationDate;
        });
        //console.log(updates);
        await update(dbRef, updates);
      }
    } catch (error) {
      console.log(error);
    }
    setSelectedFriends([]);
    setSelectedFriendsUids([]);
    //Navigation vers la page social
    navigation.navigate('SocialScreen');
  };

  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      <SearchBarComponent
        clicked={clicked}
        setClicked={setClicked}
        searchPhrase={searchPhrase}
        setSearchPhrase={setSearchPhrase}
        search={SearchHandle}
        modifierSearchType={modifierSearchType}
        setSearchStatus={setSearchStatus}
        ressetSearch={ressetSearch}
      />
      <View style={selectedFriends.length === 0 ? null : { flex: 0.2 }}>
        {(type === 'groupeCreate' || doing === 'Invite') && selectedFriends.length > 0 ? (
          <>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', height: 100, width: 375 }}>
              <ScrollView
                contentContainerStyle={{ justifyContent: 'space-between', flexDirection: 'row' }}
                horizontal={true}
              >
                {selectedFriends.map((item) => {
                  return (
                    <View style={styles.AmiInfoContainer} key={item.uid}>
                      <TouchableOpacity
                        style={{ zIndex: 2, backgroundColor: 'white' }}
                        onPress={() => {
                          setSelectedFriends(selectedFriends.filter((e) => e !== item));
                          setSelectedFriendsUids(selectedFriendsUids.filter((e) => e !== item.uid));
                        }}
                      >
                        <AntDesign name="closecircleo" size={15} style={styles.RemoveIcon} />
                      </TouchableOpacity>
                      <Image
                        style={styles.Amisimage}
                        source={{
                          uri: serverSection ? item.profile_image : item.profile_image.replace('localhost', '10.0.2.2'),
                        }}
                      />
                      <Text style={styles.AmiName}>{item.first_name + ' ' + item.last_name}</Text>
                    </View>
                  );
                })}
              </ScrollView>
              {selectedFriends.length >= 2 || (doing === 'Invite' && selectedFriends.length >= 1) ? (
                <CustomButton
                  title="Suivant"
                  style={{ backgroundColor: '#0000', position: 'relative', top: 20 }}
                  Textstyle={styles.ButtonDefault}
                  onPress={() => {
                    doing === 'Invite' ? InviteFriends() : SubmitFriends();
                  }}
                />
              ) : null}
            </View>
          </>
        ) : null}
      </View>
      <Text style={styles.title}>{doing === 'Members' ? 'Membres du Group' : 'Suggestions'}</Text>
      {!followedUsersLoader && followedUsers?.length > 0 ? (
        <ScrollView style={selectedFriends.length === 0 ? null : { flex: 0.8 }}>
          {searchResults?.length && searchPhrase && searchResults ? (
            searchResults?.map((item) => {
              return (
                <AmiCard
                  key={item.uid}
                  item={item}
                  type={type}
                  doing={doing}
                  selectedFriends={selectedFriends}
                  setSelectedFriends={setSelectedFriends}
                  checkselectedFriends={checkselectedFriends}
                  selectedFriendsUids={selectedFriendsUids}
                  setSelectedFriendsUids={setSelectedFriendsUids}
                />
              );
            })
          ) : !searchResults?.length && searchPhrase && searchResults && searchingStatus ? (
            <NoSocialData Description="Auccun amis de ce nom" />
          ) : doing === 'Invite' ? (
            UsresToInvite.map((item) => (
              <AmiCard
                key={item.uid}
                item={item}
                type={type}
                doing={doing}
                selectedFriends={selectedFriends}
                setSelectedFriends={setSelectedFriends}
                checkselectedFriends={checkselectedFriends}
                selectedFriendsUids={selectedFriendsUids}
                setSelectedFriendsUids={setSelectedFriendsUids}
              />
            ))
          ) : doing === 'Members' ? (
            GroupMembers.map((member) => (
              <AmiCard
                key={member.uid}
                item={member}
                type={type}
                doing={doing}
                group_admin_id={item.user_admin_id}
                ModalVisibiltyToggle={ModalVisibiltyToggleMemebers}
              />
            ))
          ) : (
            followedUsers.map((item) => (
              <AmiCard
                key={item.uid}
                item={item}
                type={type}
                doing={doing}
                selectedFriends={selectedFriends}
                setSelectedFriends={setSelectedFriends}
                checkselectedFriends={checkselectedFriends}
                selectedFriendsUids={selectedFriendsUids}
                setSelectedFriendsUids={setSelectedFriendsUids}
              />
            ))
          )}
        </ScrollView>
      ) : null}
      <ModalComponent
        item={MemberToKick}
        user={user}
        group={item}
        isModalVisible={isModalVisible}
        ModalVisibiltyToggle={ModalVisibiltyToggleMemebers}
        type={'Members'}
      />
    </View>
  );
};
export default SelectFriends;

const styles = StyleSheet.create({
  AmiInfoContainer: {
    marginVertical: 5,
    marginHorizontal: 15,
    width: 70,
    height: 54,
  },
  title: {
    fontFamily: 'Poppins-Medium',
    height: 20,
    fontSize: 12,
    lineHeight: 20,
    marginLeft: 20,
    color: 'rgba(133, 133, 133, 1)',
  },
  Amisimage: {
    width: 50,
    height: 50,
    borderRadius: 40,
    marginBottom: 5,
    alignSelf: 'center',
  },
  RemoveIcon: { position: 'absolute', top: 0, right: 10, backgroundColor: 'white', borderRadius: 100 },
  ButtonDefault: {
    color: 'rgba(82, 89, 245, 1)',
    textAlign: 'center',
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    lineHeight: 19.6,
  },
  AmiName: { alignSelf: 'center', textAlign: 'center', fontFamily: 'Poppins-Regular', fontSize: 10, lineHeight: 15 },
});
