const groupeCreated = {
    commercial_offer_id: "99",
     group_img: "https://storage.googleapis.com/download/storage/v1/b/walsupdev.appspot.com/o/offre-image%2F88f5e78ce4ff37d04e84jpeg?generation=1683650537801134&alt=media",
    id: 139,
    members: ["qwuKg2VF7zaEhRnOMzzxSExPvzJ3", "KUiRwH150BSKR13DQBxXc64Gd8r1", "jbLQNe34oUVDmWwd0IyOSWzHFih2"],
    name: "the Ghramel", 
    user_admin_id: "qwuKg2VF7zaEhRnOMzzxSExPvzJ3"}