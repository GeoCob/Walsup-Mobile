import {
  Text,
  Image,
  StyleSheet,
  View,
  TextInput,
  ActivityIndicator,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import React, { Component, useEffect, useState } from 'react';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import CustomButton from '../../components/Button';
import SearchBarComponent from '../../components/SearchBar';
import { useDispatch, useSelector } from 'react-redux';
import OffreCardGroupe from '../../components/OffreCardGroupe';
import { CreateGroupeApi, getDiscussionData } from '../../store/social/socialThunk';
import { BaseColor } from '../../../config/theme';
import { LogBox } from 'react-native';
import NoSocialData from '../../components/noSocialData';
import { fetchAllCommercialOffers } from '../../store/commercialOffers/commercialOffersThunk';
import { getAllPartners } from '../../store/authentication/authenticationThunk';
import * as ImagePicker from 'expo-image-picker';
import { clearCreatdGroupe } from '../../store/social/socialSlice';
import {
  child,
  get,
  getDatabase,
  onValue,
  ref,
  push,
  serverTimestamp,
  set,
  off,
  update,
  runTransaction,
} from 'firebase/database';

//Composant de creation de groupe
const CreateGroupe = ({ route, navigation }) => {
  //Appel des amis selectionnées(invités),et le type de groupe à créer (social/offre) de route params
  const { GroupeType, selectedFriendsUids, setSelectedFriendsUids, setSelectedFriends } = route.params;
  //Declaration d'une variable dans le state pour le nom de groupe
  const [GroupeName, setGroupeName] = useState('');
  //Declaration d'une variable dans le state pour l'erreur du nom de groupe
  const [NameError, setNameError] = useState('');
  //Declaration d'une variable dans le state pour l'erreur d'une offre
  const [OffreError, setOffreError] = useState('');
  //Declaration d'une variable dans le state pour l'erreur de selection d'image
  const [ImageError, setImageError] = useState('');
  //Decalration d'une variable dans le state pour l'état de recherche et de la barre de recherche
  const [searchingStatus, setSearchStatus] = useState(false);
  //Appeel de groupe crée et son loader de store social
  const { CreatedGroup, CreateGroupeLoader } = useSelector((store) => store.social);
  //Appel des offres commercials et son loader de store d'offres commercials
  const { offersData, loadingOffers } = useSelector((store) => store.commercialOffers);
  //Appel des partenaires , loader de partenaire et l'utilisateur de store d'authentification
  const { partners, loading_partners, user } = useSelector((store) => store.authentification);
  //Declaration de variable dans le state pour le clique de la barre de recherche
  const [clicked, setClicked] = useState(false);
  //Declaration de variable dans le state pour la phrase de recherche
  const [searchPhrase, setSearchPhrase] = useState('');
  const [modifierSearchType, setModifierSearchType] = useState('CreationGroupeOffer');
  //Declaration de variable dans le state pour l'offre selectionné (pour le groupe de type offre)
  const [selectedOffer, setSelectedOffer] = useState('');
  //Declaration de variable dans le state pour l'image de groupe (image d'offre / image de groupe social)
  const [groupImage, setGroupImage] = useState(null);
  //Declaration de variable dans le state pour l'url d'image base64 (groupe social)
  const [imageUri, setImageUri] = useState(null);
  //Declaration de varaible dans le state pour l'activation de button
  const [isButtonDisabled, setIsButtonDisabled] = useState(false);
  const dispatch = useDispatch();
  //Declaration d'une variable dans le state pour le résultat de la recherche
  const [searchResults, setSearchResults] = useState([]);
  //ignore d'alerte
  LogBox.ignoreLogs(['Non-serializable values were found in the navigation state']);

  //Fonction de selection d'offre
  const OfferIsSelected = (id) => {
    if (selectedOffer === id) {
      return true;
    } else {
      return false;
    }
  };

  //Fonction de recherche
  const SearchHandle = () => {
    //filtre d'offres selon la phrase de recherche
    const newState = offersData?.filter((search) => search.title.toLowerCase().includes(searchPhrase.toLowerCase()));
    //mise à jour de résultat de la recherche et de l'état de la recherche
    setSearchResults(newState);
    setSearchStatus(true);
  };

  //Fonction de reset de la recherche
  const ressetSearch = () => {
    setSearchResults([]);
    setSearchPhrase('');
    setSearchStatus(false);
    setClicked(false);
  };

  //Fonction d'upload d'une image (groupe social)
  const UploadImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      base64: true,
      aspect: [1, 1],
      quality: 1,
    });
    //console.log(result);

    if (!result.canceled) {
      setGroupImage(`data:image/${result.assets[0].uri.split('.').pop()};base64,` + result.assets[0].base64);
      setImageUri(result.assets[0].uri);
    }
  };
  // =============================== //
  // start create groupe method call
  // =============================== //
  //Fonction de submission de creation de groupe
  const SubmitGroupeCreation = async () => {
    setIsButtonDisabled(true); // disable the button
    if (GroupeType === 'Offer') {
      //si le groupe de type offre
      if (GroupeName != '') {
        //si le groupe a un nom
        setNameError('');
        setIsButtonDisabled(false); // disable the button
        if (selectedOffer != '') {
          //si une offre est selectionnée
          setIsButtonDisabled(false); // disable the button
          setOffreError('');
          //Set des données dans un objet
          const data = {
            GroupeType: GroupeType,
            name: GroupeName,
            commercial_offer_id: selectedOffer,
            user_ids: selectedFriendsUids,
            user_admin_id: user.uid,
            group_img: groupImage,
          };
          //Appel au reducer de creation de groupe
          await dispatch(CreateGroupeApi(data));
          //activation de button
          setTimeout(() => setIsButtonDisabled(false), 2000);
          //reset de formulaire
          setGroupeName('');
          setNameError('');
          setSelectedOffer('');
          setGroupImage(null);
          setImageUri(null);
          setSelectedFriendsUids([]);
          setSelectedFriends([]);
          //navigation vers la screen social
          navigation.navigate('SocialScreen');
        } else {
          //trigger d'erreur de selection d'offre
          setOffreError("S'il vous plait Chosissez une offre");
          setIsButtonDisabled(false);
        }
      } else {
        //trigger d'erreur de nom
        setNameError("S'il vous plait Donnez un Nom au Groupe");
        setIsButtonDisabled(false);
      }
    } else {
      //si le groupe de type social (la meme methode sauf au lieu de verification d'offre selectionné il y a une verification d'image de groupe)
      if (GroupeName != '') {
        setNameError('');
        setIsButtonDisabled(false);
        if (groupImage != null) {
          setImageError('');
          setIsButtonDisabled(false);
          const data = {
            GroupeType: GroupeType,
            name: GroupeName,
            commercial_offer_id: selectedOffer,
            user_ids: selectedFriendsUids,
            user_admin_id: user.uid,
            group_img: groupImage,
          };
          await dispatch(CreateGroupeApi(data));
          setTimeout(() => setIsButtonDisabled(false), 2000);
          setGroupeName('');
          setNameError('');
          setSelectedOffer('');
          setGroupImage(null);
          setImageUri(null);
          setSelectedFriendsUids([]);
          setSelectedFriends([]);
          navigation.navigate('SocialScreen');
        } else {
          setImageError("S'il vous plait Donnez une Image au Groupe");
          setIsButtonDisabled(false);
        }
      } else {
        setNameError("S'il vous plait Donnez un Nom au Groupe");
        setIsButtonDisabled(false);
      }
    }
  };
  // =============================== //
  // end create groups method call
  // =============================== //
  //UseEffect
  useEffect(() => {
    //si le groupe est de type offre
    if (GroupeType === 'Offer') {
      //Appel au reducer de fetch des offres commercials et des partenaires
      dispatch(fetchAllCommercialOffers(user.uid));
      dispatch(getAllPartners());
    }
  }, [user]);

  //UseEffect
  useEffect(() => {
    //Creation de conversation de groupe
    const handleGroupeConversationCreation = async () => {
      if (CreatedGroup.id) {
        //si le groupe est crée
        console.log('groupe created details ============>', CreatedGroup);
        // creation des conversations
        const groupeDataSource = CreatedGroup;
        //Appel à la base de données firebase
        const db = getDatabase();
        //set de données de groupe dans un objet
        const groupeData = {
          groupeName: CreatedGroup.name,
          group_img: CreatedGroup.group_img,
          creationDate: serverTimestamp(),
          lastMessage: '',
          lastMessageCreationDate: serverTimestamp(),
          badges: 0,
        };
        let CreationPathData = {};
        //creation de conversation pour chaque membre
        for (let index = 0; index < groupeDataSource.members.length; index++) {
          const element = groupeDataSource.members[index];
          CreationPathData['/privateChatConversation/' + element + '/' + groupeDataSource.id] = groupeData;
        }
        console.log(CreationPathData);
        try {
          await update(ref(db), CreationPathData);
        } catch (error) {
          console.log(error);
          console.log('realtime DB node not created');
        }

        // handle creating the groupeMessages
        dispatch(clearCreatdGroupe());
      } else {
        console.log('groupe created details ============> WAIIIITING for DATA !!!!!!');
      }
    };
    handleGroupeConversationCreation();
  }, [CreateGroupeLoader]);

  return !CreateGroupeLoader ? (
    <View style={styles.Container}>
      <View style={styles.TitleIconContainer}>
        <MaterialCommunityIcons name="message-reply-outline" size={20} color="black" style={[styles.messageIcon]} />
        <MaterialCommunityIcons name="message-reply-outline" size={20} color="black" style={[styles.messageIcon2]} />
        <Text style={styles.Title}> Discuter à propos d'une offre / post ?</Text>
        <CustomButton
          title="Créer"
          style={{ backgroundColor: '#0000', position: 'relative', right: -50, top: -5 }}
          Textstyle={[
            styles.ButtonDefault,
            (GroupeName != '' && GroupeType === 'Social' && groupImage != '') ||
            (GroupeName != '' && GroupeType === 'Offer' && selectedOffer)
              ? { color: 'rgba(82, 89, 245, 1)' }
              : { color: 'rgba(140, 140, 140, 1)' },
          ]}
          disabled={isButtonDisabled}
          onPress={() => {
            SubmitGroupeCreation();
          }}
        />
      </View>
      <View style={styles.TitleGroupeContainer}>
        <Text style={styles.Title2}> Nom de groupe</Text>
        <TextInput
          style={styles.input}
          placeholder="Entrer le nom du groupe"
          value={GroupeName}
          onChangeText={(text) => setGroupeName(text)}
        />
        {NameError != '' ? <Text style={{ color: 'red' }}>{NameError}</Text> : null}
        {OffreError != '' && GroupeType === 'Offer' ? <Text style={{ color: 'red' }}>{OffreError}</Text> : null}

        {GroupeType === 'Offer' ? (
          <View style={{ width: '107%', position: 'relative', left: -19 }}>
            <SearchBarComponent
              clicked={clicked}
              setClicked={setClicked}
              searchPhrase={searchPhrase}
              setSearchPhrase={setSearchPhrase}
              search={SearchHandle}
              setSearchStatus={setSearchStatus}
              ressetSearch={ressetSearch}
            />
          </View>
        ) : null}
        {!loadingOffers && !loading_partners && offersData?.length > 0 && partners && GroupeType === 'Offer' ? (
          <ScrollView>
            {searchResults?.length && searchPhrase && searchResults ? (
              searchResults?.map((offre) => {
                return (
                  <OffreCardGroupe
                    key={offre.offer_id}
                    offre={offre}
                    partner={partners[offre.partner_id]}
                    setSelectedOffer={setSelectedOffer}
                    OfferIsSelected={OfferIsSelected}
                    setGroupImage={setGroupImage}
                  />
                );
              })
            ) : !searchResults?.length && searchPhrase && searchResults && searchingStatus ? (
              <NoSocialData Description="Auccune Offre de ce nom" />
            ) : (
              offersData &&
              offersData.map((offre) => {
                return (
                  <OffreCardGroupe
                    key={offre.offer_id}
                    offre={offre}
                    partner={partners[offre.partner_id]}
                    setSelectedOffer={setSelectedOffer}
                    OfferIsSelected={OfferIsSelected}
                    setGroupImage={setGroupImage}
                  />
                );
              })
            )}
          </ScrollView>
        ) : GroupeType === 'Social' ? (
          <TouchableOpacity onPress={UploadImage}>
            <Text style={styles.imageTxt}>Choisir Une Image Pour Votre Groupe</Text>
            <Image
              source={
                imageUri ? { uri: imageUri.replace('localhost', '10.0.2.2') } : require('../../../assets/profile.png')
              }
              style={styles.image}
            />
          </TouchableOpacity>
        ) : (
          <ActivityIndicator color={BaseColor.primaryLight} style={{ flex: 1 }} size="large" />
        )}
        {ImageError != '' && GroupeType === 'Social' ? (
          <Text style={{ color: 'red', alignSelf: 'center' }}>{ImageError}</Text>
        ) : null}
      </View>
    </View>
  ) : (
    <>
      <ActivityIndicator color={BaseColor.primaryLight} size="large" style={{ flex: 1 }} />
    </>
  );
};
export default CreateGroupe;

const styles = StyleSheet.create({
  Container: {
    flex: 1,
    flexDirection: 'column',
    justifyContent: 'flex-start',
    alignContent: 'center',
    backgroundColor: 'white',
  },
  Title: {
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    lineHeight: 18,
  },
  messageIcon: {
    marginHorizontal: 10,
  },
  messageIcon2: {
    position: 'absolute',
    top: -5,
    marginHorizontal: 5,
  },
  ButtonDefault: {
    color: 'rgba(82, 89, 245, 1)',
    textAlign: 'center',
    fontFamily: 'Poppins-Regular',
    fontSize: 14,
    lineHeight: 19.6,
  },
  TitleIconContainer: {
    marginVertical: 20,
    marginHorizontal: 10,
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignContent: 'flex-start',
  },
  TitleGroupeContainer: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    alignContent: 'flex-start',
    marginHorizontal: 20,
  },
  Title2: { fontSize: 13, fontFamily: 'Poppins-Medium', lineHeight: 19.5, marginBottom: 5 },
  imageTxt: {
    fontSize: 13,
    fontFamily: 'Poppins-Medium',
    alignSelf: 'center',
    lineHeight: 19.5,
    marginBottom: 25,
    marginTop: 25,
  },
  image: {
    width: 50,
    height: 50,
    alignSelf: 'center',
  },
  input: {
    width: 335,
    height: 40,
    borderRadius: 8,
    padding: 12,
    backgroundColor: 'rgba(242, 242, 242, 1)',
  },
});
