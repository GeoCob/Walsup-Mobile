import React, { Component } from 'react';
import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { useDispatch, useSelector } from 'react-redux';
import { SetUserInterests } from '../../store/authentication/authenticationThunk';
import AlimentaireSVG from '../../../assets/Icons/components/AlimentaireSVG';
import EvenementSVG from '../../../assets/Icons/components/EvenementSVG';
import DecorationSVG from '../../../assets/Icons/components/DecorationSVG';
import VetementSVG from '../../../assets/Icons/components/VetementSVG';
import SportSVG from '../../../assets/Icons/components/SportSVG';
import TechSVG from '../../../assets/Icons/components/TechSVG';

//Composant de selection des centres d'interets
const Interests = ({ navigation }) => {
  //Appel à l'utilisateur de store d'authentification
  const { user } = useSelector((store) => store.authentification);
  //console.log("user in interests", user);
  //Declaration d'une variable dans le state pour les centres d'interets selectionnés
  const [interests, setInterests] = useState([]);
  const dispatch = useDispatch();
  //Declaration de tous les centres d'interets et leurs données
  const [Categories, setCategories] = useState([
    { id: '0', title: 'Alimentaire', value: 1, pressed: false, icon: AlimentaireSVG },
    { id: '1', title: 'Tech', value: 2, pressed: false, icon: TechSVG },
    { id: '2', title: 'Vêtements', value: 3, pressed: false, icon: VetementSVG },
    { id: '3', title: 'Sports', value: 4, pressed: false, icon: SportSVG },
    { id: '4', title: 'Décoration', value: 5, pressed: false, icon: DecorationSVG },
    { id: '5', title: 'Evènements', value: 6, pressed: false, icon: EvenementSVG },
  ]);
  //UseEffect
  useEffect(() => {
    if (user?.interests_ids?.length > 0) {
      //Si l'utilisateur à des centres d'interets
      //Mise à jour des centres d'interets selectionnés
      setInterests(user.interests_ids);
    }
  }, [user]);

  //Declaration de variable dans le state pour le message d'erreur
  const [message, setMessage] = useState('');
  //Fonction de selection de centre d'interet
  const CategoriesHandle = (category) => {
    if (interests.includes(category.value)) {
      //Si l'utilsiateur clique sur la button confirmer et un centre déjà selectionné ===> on supprime les duplications
      setInterests(interests.filter((item) => item !== category.value));
      //Mise à jour des centres d'interets
      setCategories((prevCategories) =>
        prevCategories.map((item) => (item.id === category.id ? { ...item, pressed: false } : item))
      );
    } else {
      //Sinon
      if (interests.length < 5) {
        //Si les centres d'interets selectionnés sont moins de 5 centres
        //Mise à jour des centre d'interets selectionnés
        setInterests([...interests, category.value]);
        //Mise à jour des centres d'interets
        setCategories((prevCategories) =>
          prevCategories.map((item) => (item.id === category.id ? { ...item, pressed: true } : item))
        );
        //set de message d'erreur un array vide
        setMessage('');
      } else {
        //si centre d'interets > 5 Mise à jour de message d'erreur
        setMessage('Vous ne pouvez sélectionner que 4 catégories');
      }
    }
  };

  //Fonction de submission des centres d'interets
  const onSubmit = () => {
    //set des centres d'interets et d'uid d'utilisateur
    const data = {
      uid: user.uid,
      interests_ids: interests,
    };
    //console.log("Data in interests",data);
    //Appel au reducer de set des centres d'interets
    dispatch(SetUserInterests(data));
    //navigation à l'accueil (marketplace)
    navigation.navigate('Accueil');
  };
  return (
    <View style={styles.BigContainer}>
      {/* <View style={styles.container}>
        <View style={styles.avatarContainer}>
          <Image
            style={styles.avatar}
            source={user.profile_image ? { uri: user.profile_image } : require('../../../assets/profile.png')}
          />
        </View>
        <View style={styles.body}>
          <View style={styles.nameContainer}>
            <Text style={styles.name}>{user.first_name+' '+user.last_name ? user.first_name+' '+user.last_name : 'Your Name'}</Text>
          </View>
          <View style={styles.nameContainer}>
            <Text style={styles.nickname}>@{user.nickname ? user.nickname : user.first_name+' '+user.last_name ? user.first_name+'.'+user.last_name : 'NickName'}</Text>
          </View>
          <View style={styles.infoContainer}>
            <Text style={styles.infoText}>{user.email ? user.email : 'Your mail'}</Text>
          </View>
        </View>
      </View>  */}
      <View style={styles.CategoriesContainer}>
        {/* <Text style={styles.title}>Centre d'interet</Text> */}
        <View style={styles.categories}>
          {Categories.map((item, index) => {
            return (
              <TouchableOpacity
                onPress={() => CategoriesHandle(item)}
                style={[styles.category, { backgroundColor: item.pressed ? '#2D9AFF' : 'rgba(217, 217, 217, 1)' }]}
                key={index}
              >
                <View style={styles.CategorieContainer}>
                  <item.icon />
                  <Text style={[styles.categoryText, { color: item.pressed ? 'black' : 'black' }]}>{item.title}</Text>
                </View>
              </TouchableOpacity>
            );
          })}
          {message && <Text style={{ color: 'red', left: 30 }}>{message}</Text>}
        </View>
        <TouchableOpacity style={styles.submit} onPress={() => onSubmit()}>
          <Text style={styles.submitText}>Confirmer</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default Interests;

const styles = StyleSheet.create({
  CategoriesContainer: {
    flex: 1,
    marginTop: 20,
    flexDirection: 'column',
    alignSelf: 'center',
    borderRadius: 10,
    backgroundColor: 'white',
  },
  category: {
    width: 110,
    padding: 10,
    borderRadius: 10,
    marginVertical: 10,
  },
  categories: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 5,
    marginHorizontal: 20,
  },
  BigContainer: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: 'white',
    justifyContent: 'space-around',
  },
  title: {
    fontSize: 24,
    fontFamily: 'Poppins-SemiBold',
    alignSelf: 'center',
  },
  categoryText: {
    fontSize: 12,
    fontFamily: 'Poppins-Regular',
    alignSelf: 'center',
    lineHeight: 18,
    marginTop: 2,
  },
  submitText: {
    marginTop: 20,
    backgroundColor: '#6959DE',
    color: '#FFFFFF',
    fontSize: 20,
    fontFamily: 'Poppins-ExtraBold',
    alignSelf: 'center',
    paddingHorizontal: 80,
    paddingVertical: 10,
    borderRadius: 20,
  },
  submit: {
    alignSelf: 'center',
    height: 70,
  },
  CategorieContainer: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});
