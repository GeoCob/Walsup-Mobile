import React, { useEffect } from 'react';
import { Text, View, TouchableOpacity, Image } from 'react-native';
import { useSelector } from 'react-redux';
import logoImage from '../../../assets/logo-walsup.png';
import WalsupIconSVG from '../../../assets/Icons/components/WalsupIconSVG';
import styles from './styles';

//Composant Screen 1 de l'app (authentification)
const Authentification = ({ navigation }) => {
  const { user } = useSelector((store) => store.authentification);

  return (
    <View style={styles.contenu}>
      <View style={{ alignItems: 'center', marginTop: 150 }}>
        <View style={{ marginBottom: 20 }}>
          <WalsupIconSVG />
        </View>
        <TouchableOpacity style={styles.buttonSignUp} onPress={() => navigation.navigate('SignUp')}>
          <Text style={styles.buttonText}>S'inscrire</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.buttonSignIn} onPress={() => navigation.navigate('SignIn')}>
          <Text style={styles.buttonText}>Se Connecter</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => navigation.navigate('WhoWeAreSlider')}>
          <Text style={styles.text}>QUI SOMME-NOUS ?</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default Authentification;
