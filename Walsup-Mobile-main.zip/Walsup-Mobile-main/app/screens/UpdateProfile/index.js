import { Text, StyleSheet, View, Image, TouchableOpacity, ScrollView, FlatList } from 'react-native';
import React, { useEffect } from 'react';
import * as ImagePicker from 'expo-image-picker';
import { TextInput } from 'react-native';
import { useState } from 'react';
import DateTimePickerModal from 'react-native-modal-datetime-picker';
import DropDownPicker from 'react-native-dropdown-picker';
import { useDispatch, useSelector } from 'react-redux';
import { createProfile } from '../../store/authentication/authenticationThunk';
import * as Yup from 'yup';
import { useFormik } from 'formik';
import { format } from 'date-fns';
import { useFocusEffect } from '@react-navigation/native';
import DatePicker from 'react-native-datepicker';

//Composant de la Screen de Gestion de Profile
const UpdateProfile = ({ navigation }) => {
  //Appel à l'utilisateur de store d'authentification
  const { user } = useSelector((store) => store.authentification);
  //Declaration d'une variable dans le state initialisé par l'image d'utilisateur si elle existe ( photo de profile de google)
  const [imageUri, setImageUri] = useState(user?.profile_image ? user.profile_image : '');
  //Declaration d'une variable dans le state intiialisé par le préfix de num tel (+33)
  const [phonePrefix, setPhonePrefix] = useState('+33');
  //Declaration d'une variable dans le state pour l'url d'image base64
  const [imageUri64, setImageUri64] = useState('');
  //Declaration d'une variable dans le state initialiser par les choix de genre (sexe)
  const [genreItems, setGenreItems] = useState([
    { label: 'Homme', value: 'Homme' },
    { label: 'Femme', value: 'Femme' },
    { label: 'Autre', value: 'Autre' },
  ]);
  //Declaration d'une variable initialiser par false pour l'ouverture de la galerie de l'appareil
  const [open, setOpen] = useState(false);
  //Declaration d'une variable pour le test de champ de la date de naissance
  const [birthDateTouched, setbirthDateTouched] = useState(false);
  //Declaration d'une variable initialisé par la date de naissance d'utilisateur si elle existe
  const [birthDate, setBirthDate] = useState(user.birth_date ? format(new Date(user.birth_date), 'dd/MM/yyyy') : '');
  //Declaration d'une variable initialisé par false pour le trigger d'une erreur par à rapport à la date de naissance
  const [birthDateError, setBirthDateError] = useState(false);
  //Declaration d'une variable initialiser par false pour l'ouverture de la calendrier de choix de la date de naissance
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);

  const dispatch = useDispatch();

  //UseFocusEffect
  useFocusEffect(
    React.useCallback(() => {
      //initialisation des valeur des champs s'ils existent
      setFieldValue('nom', user?.last_name ? user.last_name : '');
      setFieldValue('prenom', user?.first_name ? user.first_name : '');
      setFieldValue('adresse', user?.adresse ? user.adresse : '');
      setFieldValue('tel', user?.num_tel ? user.num_tel.substring(3) : '');
      setFieldValue('genre', user?.gender ? user.gender : '');
      setBirthDate(user.birth_date ? format(new Date(user.birth_date), 'dd/MM/yyyy') : '');
    }, [user, setFieldValue])
  );

  //Fonction de verification avant la submission de gestion de profile
  const handleSubmit = () => {
    //console.log('handleSubmit called');
    //Validation de formulaire de gestion de profile
    validateForm().then((errors) => {
      //console.log('Validation errors:', errors);
      //trigger des erreurs
      setFieldTouched('nom', !!errors.nom);
      setFieldTouched('prenom', !!errors.prenom);
      setFieldTouched('adresse', !!errors.adresse);
      setFieldTouched('tel', !!errors.tel);
      setFieldTouched('genre', !!errors.genre);
      setbirthDateTouched(true);
      //verification s'il y a une erreur
      const hasErrors = Object.keys(errors).length > 0 || (!birthDate && birthDateTouched) || birthDateError;
      if (!hasErrors) {
        //s'il n y a pas d'erreur on appel on submit
        onSubmit(user.uid);
      }
    });
  };
  //submission de formulaire
  const onSubmit = (uid) => {
    //console.log('onSubmit called');
    //Set de tous les données dans un objet
    const data = {
      first_name: values.prenom,
      last_name: values.nom,
      image: imageUri64,
      uid: uid,
      birth_date: birthDate,
      genre: values.genre,
      adresse: values.adresse,
      tel: phonePrefix + values.tel,
    };
    //Appel au reducer createprofile en y passant l'objet data
    dispatch(createProfile(data));
    //navigation vers la marketplace
    navigation.navigate('Marketplace');
  };

  //Fonction d'ouverture de la calendrier
  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };

  //Fonction de fermeture de la calendrier
  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };

  //Fonction de verifiaction de range de la date de naissance 16+
  const isSixteenOrOlder = (birthdate) => {
    //console.log('birthDate', birthDate);
    const birthDateParts = birthdate.split('/');
    const birthDay = parseInt(birthDateParts[0]);
    const birthMonth = parseInt(birthDateParts[1]) - 1; // Months are zero-indexed in JavaScript
    const birthYear = parseInt(birthDateParts[2]);

    const today = new Date();

    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth();
    const currentDay = today.getDate();

    const age = currentYear - birthYear;

    const monthDifference = currentMonth - birthMonth;

    const dayDifference = currentDay - birthDay;

    if (age > 16) {
      return true;
    } else if (age === 16) {
      if (monthDifference > 0) {
        return true;
      } else if (monthDifference === 0 && dayDifference >= 0) {
        return true;
      }
    }

    return false;
  };

  //Fonction de set de la date denaissance
  const handleConfirm = (date) => {
    //Declaration de la date d'aujourd'hui
    const formattedDate = format(new Date(date), 'dd/MM/yyyy');
    // console.log('formattedDate', formattedDate);
    //Appel à la foonction de verification d'age
    const BirthdateCheck = isSixteenOrOlder(formattedDate);
    //si birthdatecheck true on set la date sinon on trigger une erreur
    if (BirthdateCheck) {
      setBirthDateError(false);
      setBirthDate(formattedDate);
      hideDatePicker();
    } else {
      setBirthDate('');
      setBirthDateError(true);
      hideDatePicker();
    }
  };

  //Fonction d'upload d'image de profile
  const UploadImage = async () => {
    //Lancement de storage de l'appareil afin de choisir une image
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      base64: true,
      aspect: [1, 1],
      quality: 1,
    });
    //console.log(result);
    //set de lien d'image de type base64
    if (!result.canceled) {
      setImageUri64(`data:image/${result.assets[0].uri.split('.').pop()};base64,` + result.assets[0].base64);
      setImageUri(result.assets[0].uri);
    }
  };

  //Validation des champs de formulaire
  const validationSchema = Yup.object().shape({
    nom: Yup.string().required('Le nom est obligatoire'),
    prenom: Yup.string().required('Le prénom est obligatoire'),
    adresse: Yup.string().required("L'adresse est obligatoire"),
    tel: Yup.string()
      .matches(
        /^\d{9}$/,
        "Le numéro de téléphone est invalide s'il vous plait entrez un numéro téléphone francais qui a 9 chiffres"
      )
      .required('Le numéro de téléphone est obligatoire'),
    genre: Yup.string()
      .oneOf(['Homme', 'Femme', 'Autre'], 'Le genre sélectionné est invalide')
      .required('Le genre est obligatoire'),
  });

  //Instansiation de formik
  const { values, handleChange, handleBlur, errors, touched, setFieldValue, validateForm, setFieldTouched } = useFormik(
    {
      initialValues: {
        nom: user?.last_name ? user.last_name : '',
        prenom: user?.first_name ? user.first_name : '',
        adresse: user?.adresse ? user.adresse : '',
        tel: user?.num_tel ? user.num_tel : '',
        genre: user?.gender ? user.gender : '',
      },
      validationSchema: validationSchema,
      onSubmit,
    }
  );
  //Fonction qui retourn l'ui de formulaire
  const renderItem = () => (
    <View style={styles.container}>
      <View style={styles.imageContainer}>
        <TouchableOpacity onPress={UploadImage} style={{ width: '100%', alignSelf: 'center' }}>
          <Image
            source={
              imageUri ? { uri: imageUri.replace('localhost', '10.0.2.2') } : require('../../../assets/profile.png')
            }
            style={styles.image}
          />
          <Text style={styles.imageTxt}>Modifier la photo</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.nomprenom}>
        <View style={{ width: '50%' }}>
          <Text style={styles.label}>Nom</Text>
          <TextInput
            style={styles.nom}
            placeholder="Nom"
            value={values.nom}
            onChangeText={handleChange('nom')}
            onBlur={handleBlur('nom')}
          />
        </View>
        <View style={{ width: '50%' }}>
          <Text style={styles.label}>Prénom</Text>
          <TextInput
            style={styles.prenom}
            placeholder="Prénom"
            value={values.prenom}
            onChangeText={handleChange('prenom')}
            onBlur={handleBlur('prenom')}
          />
        </View>
      </View>
      <View style={{ flexDirection: 'row', marginTop: -13 }}>
        {errors.nom && touched.nom ? (
          <View style={{ marginRight: 40 }}>
            <Text style={{ color: '#FF0000', fontSize: 10 }}>{errors.nom}</Text>
          </View>
        ) : null}
        {errors.prenom && touched.prenom ? (
          <View style={{ position: 'absolute', right: 60 }}>
            <Text style={{ color: '#FF0000', fontSize: 10 }}>{errors.prenom}</Text>
          </View>
        ) : null}
      </View>
      <View>
        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          placeholder={user.email ? user.email : ''}
          value={user.email ? user.email : ''}
          editable={false}
        />
      </View>
      <View>
        <Text style={styles.label}>Genre</Text>
        <DropDownPicker
          style={styles.Genreinput}
          open={open}
          value={values.genre}
          items={genreItems}
          setOpen={setOpen}
          onSelectItem={(item) => {
            setFieldValue('genre', item.value);
          }}
          setItems={setGenreItems}
          placeholder="Sexe"
        />
        {errors.genre && touched.genre ? (
          <Text style={{ color: '#FF0000', fontSize: 10, marginTop: -13 }}>{errors.genre}</Text>
        ) : null}
      </View>
      <View>
        <Text style={styles.label}>Adresse</Text>
        <TextInput
          style={styles.input}
          placeholder="Adresse"
          value={values.adresse}
          onChangeText={handleChange('adresse')}
          onBlur={handleBlur('adresse')}
        />
      </View>
      {errors.adresse && touched.adresse ? (
        <Text style={{ color: '#FF0000', fontSize: 10, marginTop: -13 }}>{errors.adresse}</Text>
      ) : null}
      <View>
        <Text style={styles.label}>Date de Naissance</Text>
        <TouchableOpacity onPress={showDatePicker}>
          <View pointerEvents="none">
            <TextInput style={[styles.input, { width: '100%' }]} placeholder="Date de Naissance" value={birthDate} />
          </View>
        </TouchableOpacity>
        <DateTimePickerModal
          isVisible={isDatePickerVisible}
          mode="date"
          onConfirm={handleConfirm}
          onCancel={hideDatePicker}
        />

        {!birthDate && birthDateTouched ? (
          <Text style={{ color: '#FF0000', fontSize: 10, marginTop: -13 }}>La date de naissance est obligatoire</Text>
        ) : null}
        {birthDateError ? (
          <Text style={{ color: '#FF0000', fontSize: 10, marginTop: -4 }}>
            Il faut que votre age soit plus que 16 ans
          </Text>
        ) : null}
      </View>
      <View>
        <Text style={styles.label}>Numéro de téléphone Associé</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <TextInput style={[styles.input, { flexBasis: '20%' }]} value={phonePrefix} editable={false} />
          <TextInput
            style={[styles.input, { flexBasis: '80%' }]}
            placeholder="N° Tél"
            value={values.tel}
            onChangeText={handleChange('tel')}
            onBlur={handleBlur('tel')}
            keyboardType="phone-pad"
          />
        </View>
      </View>
      {errors.tel && touched.tel ? (
        <Text style={{ color: '#FF0000', fontSize: 10, marginTop: -13 }}>{errors.tel}</Text>
      ) : null}
      <TouchableOpacity
        style={styles.submit}
        onPress={handleSubmit}
        // disabled={!values.nom || !values.prenom || !values.adresse || !values.tel || !values.genre || !birthDate}
      >
        <Text style={styles.submitText}>Confirmer</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: '#ffffff', width: '100%', height: '100%' }}>
      <FlatList
        data={[1]} // Pass an array with a single item (the form) to render
        renderItem={renderItem}
        keyExtractor={(item) => item.toString()}
        contentContainerStyle={{}} // Add padding to the bottom of the list
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginHorizontal: 20,
  },
  input: {
    backgroundColor: '#F5F5F5',
    borderRadius: 10,
    height: 46,
    marginBottom: 10,
    paddingHorizontal: 20,
    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: '#EDEFFE',
  },
  imageContainer: {
    marginTop: 4,
    alignItems: 'center',
  },
  image: {
    borderRadius: 56,
    width: 90,
    height: 90,
    marginBottom: 10,
    alignSelf: 'center',
  },
  imageTxt: {
    marginBottom: 15,
    width: '100%',
    textAlign: 'center',
    color: '#5487EB',
  },
  nomprenom: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
  },
  nom: {
    backgroundColor: '#F5F5F5',
    marginRight: 10,
    borderRadius: 10,
    height: 46,
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  prenom: {
    backgroundColor: '#F5F5F5',
    borderRadius: 10,
    height: 46,
    marginBottom: 20,
    paddingHorizontal: 10,
  },
  submitText: {
    alignSelf: 'center',
    borderRadius: 20,
    color: 'white',
    fontSize: 18,
    textAlign: 'center',
    fontFamily: 'Poppins-SemiBold',
  },
  submit: {
    alignSelf: 'center',
    backgroundColor: '#6959DE',
    width: 285,
    borderRadius: 10,
    padding: 10,
  },
  Genreinput: {
    backgroundColor: '#F5F5F5',
    width: '100%',
    borderRadius: 10,
    height: 46,
    marginBottom: 20,
    margintop: 20,
    paddingHorizontal: 10,
    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: '#EDEFFE',
  },
  label: {
    fontSize: 15,
    fontFamily: 'Poppins-Bold',
    marginBottom: 6,
  },
});

export default UpdateProfile;
