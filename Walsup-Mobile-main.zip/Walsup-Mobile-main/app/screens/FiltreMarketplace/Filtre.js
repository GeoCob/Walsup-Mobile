import React, { Component } from 'react';
import { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import { useDispatch, useSelector } from 'react-redux';
import { SetUserInterests } from '../../store/authentication/authenticationThunk';
import DealsSvg from '../../../assets/Icons/components/DealsSvg';
import CashbackSvg from '../../../assets/Icons/components/Cashback';
import DecorationFilterSVG from '../../../assets/Icons/components/DecorationFilterSVG';
import offresSvg from '../../../assets/Icons/components/offresSvg';
import InformatiqueSvg from '../../../assets/Icons/components/InformatiqueSvg';
import EvenementsSvg from '../../../assets/Icons/components/EvenementsSvg';
import SportFilterSVG from '../../../assets/Icons/components/SportFilterSVG';
import AlimentationSvg from '../../../assets/Icons/components/AlimentationSvg';
import DecorationSVG from '../../../assets/Icons/components/DecorationSVG';
import VetementsFilterSVG from '../../../assets/Icons/components/VetementsFilterSVG';
import RestaurationSvg from '../../../assets/Icons/components/Restauration';
import {
  setfiltersCommercialSlice,
  resetfiltersCommercialSlice,
} from '../../store/commercialOffers/commercialOffersSlice';
import { setfiltersNewsSlice, resetfiltersNewsSlice } from '../../store/postNews/postNewsSlice';

//Composant de filtres
const Filtre = ({ navigation }) => {
  const { user } = useSelector((store) => store.authentification);
  //console.log("user in interests", user);
  //Declaration d'une variable dans le state pour les filters selectionnés
  const [filters, setFilters] = useState([]);
  const dispatch = useDispatch();
  //Declaration d'une variable dans le state pour les categories (filtres)
  const [Categories, setCategories] = useState([
    // { id: '0', title: 'Hot Deals', value: 1, pressed: false, icon: DealsSvg },
    // { id: '1', title: 'Cashback Max', value: 2, pressed: false, icon: CashbackSvg },
    // { id: '2', title: 'Toutes les offres', value: 3, pressed: false, icon: offresSvg },
    { id: '3', title: 'Vetements', value: 3, pressed: false, icon: VetementsFilterSVG },
    { id: '4', title: 'Technologies', value: 2, pressed: false, icon: InformatiqueSvg },
    { id: '5', title: 'Evènements', value: 6, pressed: false, icon: EvenementsSvg },
    { id: '6', title: 'Sport et Loisirs', value: 4, pressed: false, icon: SportFilterSVG },
    { id: '7', title: 'Alimentations', value: 1, pressed: false, icon: AlimentationSvg },
    { id: '8', title: 'Décoration', value: 5, pressed: false, icon: DecorationFilterSVG },
  ]);
  //Declaration d'une variable dans le state pour le message d'erreur
  const [message, setMessage] = useState('');
  //Fonction de selection des filtres
  const CategoriesHandle = (category) => {
    if (filters.includes(category.value)) {
      //Si il y a des filters déjà selectionnés ===> on supprime les duplciations
      setFilters(filters.filter((item) => item !== category.value));
      //Mise à jour des categories (filtres)
      setCategories((prevCategories) =>
        prevCategories.map((item) => (item.id === category.id ? { ...item, pressed: false } : item))
      );
    } else {
      if (filters.length < 5) {
        //Si les filtres selectionnés sont moins de 5 filtres
        //Mise à jour des filtres selectionnés
        setFilters([...filters, category.value]);
        //Mise à jour des filtres
        setCategories((prevCategories) =>
          prevCategories.map((item) => (item.id === category.id ? { ...item, pressed: true } : item))
        );
        setMessage('');
      } else {
        setMessage('Vous ne pouvez sélectionner que 5 catégories');
      }
    }
  };
  //Fonction de submission des filtres
  const onSubmit = () => {
    if (filters.length > 0) {
      //s'il y a des filtres selectionnés
      //Appel au reducer de set des filtres
      dispatch(setfiltersCommercialSlice(filters));
      dispatch(setfiltersNewsSlice(filters));
      //Navigation vers la marketplace
      navigation.navigate('Accueil');
    } else {
      //Appel au reducer de reset des filtres
      dispatch(resetfiltersCommercialSlice());
      dispatch(resetfiltersNewsSlice());
      //Navigation vers la marketplace
      navigation.navigate('Accueil');
    }
  };
  return (
    <View style={styles.BigContainer}>
      {/* <View style={styles.container}>
        <View style={styles.avatarContainer}>
          <Image
            style={styles.avatar}
            source={user.profile_image ? { uri: user.profile_image } : require('../../../assets/profile.png')}
          />
        </View>
        <View style={styles.body}>
          <View style={styles.nameContainer}>
            <Text style={styles.name}>{user.first_name+' '+user.last_name ? user.first_name+' '+user.last_name : 'Your Name'}</Text>
          </View>
          <View style={styles.nameContainer}>
            <Text style={styles.nickname}>@{user.nickname ? user.nickname : user.first_name+' '+user.last_name ? user.first_name+'.'+user.last_name : 'NickName'}</Text>
          </View>
          <View style={styles.infoContainer}>
            <Text style={styles.infoText}>{user.email ? user.email : 'Your mail'}</Text>
          </View>
        </View>
      </View>  */}
      <View style={styles.CategoriesContainer}>
        <Text style={styles.title}>Categories</Text>
        <View style={styles.categories}>
          {Categories.map((item, index) => {
            return (
              <TouchableOpacity onPress={() => CategoriesHandle(item)} style={[styles.category]} key={index}>
                <View style={styles.CategorieContainer}>
                  <item.icon circleColor={item.pressed ? { value: '#6959DE' } : { value: '#130F26' }} />
                  <Text style={[styles.categoryText, { color: item.pressed ? '#6959DE' : 'black' }]}>{item.title}</Text>
                </View>
              </TouchableOpacity>
            );
          })}
          {message && <Text style={{ color: 'red', left: 30 }}>{message}</Text>}
        </View>
        <TouchableOpacity style={styles.submit} onPress={() => onSubmit()}>
          <Text style={styles.submitText}>Appliquer le filtre </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default Filtre;

const styles = StyleSheet.create({
  CategoriesContainer: {
    flex: 1,
    marginTop: 20,
    flexDirection: 'column',
    alignSelf: 'center',
    borderRadius: 10,
    backgroundColor: 'white',
  },
  category: {
    width: 110,
    padding: 10,
    borderRadius: 10,
    marginVertical: 10,
  },
  categories: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: 5,
    marginHorizontal: 20,
  },
  BigContainer: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: 'white',
    justifyContent: 'space-around',
  },
  title: {
    fontSize: 24,
    fontFamily: 'Poppins-Bold',
    top: 10,
    left: 50,
  },
  categoryText: {
    fontSize: 12,
    fontFamily: 'Poppins-Bold',
    alignSelf: 'center',
    lineHeight: 18,
    marginTop: 2,
  },
  submitText: {
    marginTop: 20,
    backgroundColor: '#6959DE',
    color: '#FFFFFF',
    fontSize: 20,
    fontFamily: 'Poppins-ExtraBold',
    alignSelf: 'center',
    paddingHorizontal: 80,
    paddingVertical: 10,
    borderRadius: 20,
  },
  submit: {
    alignSelf: 'center',
    height: 70,
  },
  CategorieContainer: {
    flexDirection: 'column',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
});
