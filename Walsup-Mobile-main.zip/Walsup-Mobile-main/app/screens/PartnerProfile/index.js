import React, { useState, useCallback } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { View, Text, TouchableOpacity, StyleSheet, Image, ActivityIndicator, Linking } from 'react-native';
//Theme
import { BaseColor, Fonts } from '../../../config/theme';
// redux data
import { subscribeToPartner, unSubscribeToPartner } from '../../store/social/socialThunk';
import { useSelector, useDispatch } from 'react-redux';
//server conf
import { serverSection } from '../../../config/servConf';

//Composant de profile de partenaire
const PartnerProfile = ({ route, navigation }) => {
  //appel des données de route params
  const { connectedUserId, partnerId, partnerName, partnerImageUrl, partnerLink, partnerSubbed } = route.params;
  //appel des loaders de store social
  const { partnersSubsLoader, partnersSuggestionLoader } = useSelector((store) => store.social);
  //Declaration d'une variable dans le state de status d'abonnement
  const [subbedStatus, setSubbedStatus] = useState(partnerSubbed);
  //UseFocusEffect
  useFocusEffect(
    useCallback(() => {
      //console.log('=========> suggestions');
      //mise à jour de l'état d'abonnement
      setSubbedStatus(partnerSubbed);
    }, [partnerSubbed])
  );

  //methods
  const dispatch = useDispatch();
  //Fonction d'abonnement au partenaire
  const handleSubbscriptions = () => {
    if (partnersSubsLoader || partnersSuggestionLoader) return;
    if (subbedStatus) {
      //si l'utilisateur est déjà abonné appel au reducer de désabonnemnt au partenaire
      dispatch(unSubscribeToPartner({ partner_uid: partnerId, user_uid: connectedUserId }));
      setSubbedStatus(false);
      //console.log('===> unsubscribe');
    } else {
      //si l'utilisateur n'est pas déjà abonné appel au reducer de d'abonnemnt au partenaire
      dispatch(subscribeToPartner({ sender_id: connectedUserId, requested_id: partnerId }));
      setSubbedStatus(true);
      //console.log('===> unsubscribe');
    }
  };
  return (
    <View style={styles.profile__mainContainer}>
      <View style={styles.profile__dataCard_cotainer}>
        {/* profile data partner */}
        <View style={styles.profile__dataCard_main}>
          {/* profile logo */}
          <Image
            style={styles.profile__imagemain}
            source={
              partnerImageUrl
                ? {
                    uri: serverSection
                      ? partnerImageUrl.toString()
                      : partnerImageUrl.toString().replace('localhost', '10.0.2.2'),
                  }
                : require('../../../assets/profile.png')
            }
          />
        </View>
        <View>
          {/* partner name / link / button */}
          <Text style={styles.profile__partnerName}>{partnerName}</Text>
          <Text style={styles.profile__link} onPress={() => Linking.openURL(partnerLink)}>
            {partnerLink}
          </Text>
          <TouchableOpacity
            style={{
              ...styles.profile__button_subbs,
              backgroundColor: subbedStatus ? BaseColor.fadedGrey_02 : BaseColor.primaryColor,
            }}
            onPress={handleSubbscriptions}
            disabled={partnersSubsLoader || partnersSuggestionLoader}
          >
            {!partnersSubsLoader || !partnersSuggestionLoader ? (
              <Text
                style={{ ...styles.profile__button_text, color: subbedStatus ? BaseColor.backMain : BaseColor.white }}
              >
                {subbedStatus ? 'Abonner' : "S'abonner"}
              </Text>
            ) : (
              <ActivityIndicator color={subbedStatus ? BaseColor.backMain : BaseColor.white} />
            )}
          </TouchableOpacity>
        </View>
      </View>
      <View>
        {/* title and discription */}
        <Text style={styles.profilr__description}>Description :</Text>
        <Text style={styles.profile__description_text}>
          {partnerName} Europe est une société de distribution de prêt-à-porter créée en 1978 à Roncq par Patrick
          Mulliez.Évoluant sur le secteur des grandes surfaces spécialisées textile, Kiabi est un des chefs de file du
          secteur. Kiabi fait partie de l'Association familiale Mulliez à laquelle appartient notamment Auchan.
        </Text>
      </View>
    </View>
  );
};

export default PartnerProfile;

const styles = StyleSheet.create({
  profile__mainContainer: {
    flex: 1,
    backgroundColor: BaseColor.white,
    paddingTop: 42,
    paddingHorizontal: 18,
  },
  profile__dataCard_cotainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 48,
  },
  profile__dataCard_main: {
    flexDirection: 'row',
  },
  profile__imagemain: {
    width: 76,
    height: 76,
    backgroundColor: BaseColor.white,
    borderRadius: 60,
    borderBottomColor: BaseColor.fadedGrey,
    borderWidth: 0.8,
    marginRight: 36,
  },
  profile__partnerName: {
    fontSize: Fonts.font_big,
    fontFamily: 'Poppins-Medium',
    color: BaseColor.backMain,
  },
  profile__link: {
    fontSize: Fonts.font_normal,
    fontFamily: 'Poppins-Medium',
    color: BaseColor.backMain,
  },
  profilr__description: {
    fontSize: Fonts.font_XL,
    fontFamily: 'Poppins-Medium',
    color: BaseColor.backMain,
    marginBottom: 12,
  },
  profile__description_text: {
    fontSize: Fonts.font_normal,
    color: BaseColor.backMain,
  },
  profile__button_subbs: {
    justifyContent: 'center',
    alignItems: 'center',
    width: 160,
    height: 22,
    borderRadius: 10,
    marginTop: 10,
  },
  profile__button_text: {
    fontSize: Fonts.font_normal,
    fontFamily: 'Poppins-Regular',
    textAlign: 'justify',
  },
});
