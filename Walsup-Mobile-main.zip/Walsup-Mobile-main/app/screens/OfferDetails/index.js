import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useFocusEffect, useScrollToTop, useNavigation } from '@react-navigation/native';
import {
  SafeAreaView,
  Text,
  View,
  Image,
  Pressable,
  TextInput,
  ActivityIndicator,
  TouchableOpacity,
} from 'react-native';
import { Circle, Svg } from 'react-native-svg';
import CountDownTimer from '../../components/Countdown';
//css and styles tools
import Swiper from 'react-native-swiper';
import styles from './style';
import { BaseColor, Fonts } from '../../../config/theme';
import EntypoIcons from 'react-native-vector-icons/Entypo';
import Icon from 'react-native-vector-icons/Ionicons';
import Octicons from 'react-native-vector-icons/Octicons';
import Feather from 'react-native-vector-icons/Feather';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { Icons, Mascotts, Logo } from '../../../config/Images';
import { FlatList, ScrollView } from 'react-native-gesture-handler';
//redux
import { useSelector, useDispatch } from 'react-redux';
import {
  likeCommercialOffer,
  unlikeCommercialOffer,
  getCommercialOfferById,
  createCommercialOfferComment,
  getAllcommercialComments,
} from '../../store/commercialOffers/commercialOffersThunk';
import { emptyOfferByID, emptyComments } from '../../store/commercialOffers/commercialOffersSlice';
//server switcher
import { serverSection } from '../../../config/servConf';
import WorkInProgressScreen from '../WorkInProgress';

//Composant de details de l'offre commercial
const OfferDetails = ({ route, navigation }) => {
  //appel au données d'utilisateur , de partenaire et de l'offre de route params
  const { userID, userImage, userfirstName, userLastName, data, partnerName, partnerImge, scrollToCom } = route.params;
  //Declaration de variable dans le state pour le toggle d'affichage de tous les commntaires des offres
  const [showAllComments, setShowAllComments] = useState(false);
  const dispatch = useDispatch();
  //correct counter to handle calculation on board with expiration date and rest
  //Declaration de variable dans le state pour le calcul de compteur
  const [renderDesc, setRenderDesc] = useState(true);
  //force rerender
  const [childKey, setChildKey] = useState(0);
  //timer calculus
  //Declaration de variable dans le state pour storer la date d'aujourd'hui
  const [actualDate, setActualDate] = useState(new Date());
  //Declaration de vairable dans le state pour storer la date d'expiration de l'offre
  const [endingDate, setEndingDate] = useState();

  // svg system
  const size = 60;
  const progress = 0.2;
  const strokeWidth = 6.4;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const progressOffset = circumference * (1 - progress);

  //Fonction de mise à jour de la variable de compteur
  const handleDescSwitcher = (section) => {
    section ? setRenderDesc(true) : setRenderDesc(false);
  };

  //like logics
  //Declaration de variable dans le state pour la status de j'aime pour l'offre
  const [like, setLike] = useState(data.user_has_liked);
  //Declaration de variable dans le state pour le nombre de j'aime
  const [likeCount, setLikeCount] = useState(data.likes);
  //Declaration de variable dans le state pour les données de l'offre
  const [product, setProduct] = useState({ ...data });
  //Appel de des commentaire, loader des comments , loader de j'aime et de l'offre depuis le store de l'offre commercial
  const { loadingLike, loadingOfferByID, commentsForOffer, loadingofferComment } = useSelector(
    (store) => store.commercialOffers
  );
  //Declaration de variable dans le state pour le commentaire
  const [comment, setComment] = useState('');
  //Declaration de variable dans le state pour les commentaires de l'offre
  const [comments, setComments] = useState([...commentsForOffer]);

  //Fonction de navigation vers la page de WorkInProgress (pour les pages qui ne sont pas encore developpés)
  function handlePress() {
    navigation.navigate('WorkInProgress');
  }
  // useEffect(() => {
  //   console.log('timestamp in details', (endingDate - actualDate) / 1000);
  // }, [endingDate, actualDate]);

  //UseFocusEffect
  useFocusEffect(
    useCallback(() => {
      //Appel au reducer de fetch de l'offre commercial
      dispatch(getCommercialOfferById({ user_id: userID, offer_id: data.offer_id }));
      //Appel au reducer de fetch des commentaires de l'offre commercial
      dispatch(getAllcommercialComments({ offer_id: data.offer_id }));
      //Mise à jour de l'état de j'aime de l'utilisateur par rappport à l'offre
      setLike(data.user_has_liked);
      //Mise à jour de nombre de j'aime
      setLikeCount(data.likes);
      //Mise à jour des commentaires
      setComments((prevState) => commentsForOffer);
    }, [data.offer_id, commentsForOffer?.length, data.user_has_liked, data.likes])
  );
  //UseEffect
  useEffect(() => {
    //mise à jour de l'offre
    setChildKey(Math.floor(Math.random() * 10000000));
    setEndingDate(new Date(data.expiration_date));
    setProduct({ ...data });
    dispatch(getCommercialOfferById({ user_id: userID, offer_id: data.offer_id }));
  }, [data.offer_id, product.offer_id, data.user_has_liked, data.likes]);
  const scrollViewRef = useRef(null);

  useFocusEffect(
    useCallback(() => {
      if (scrollToCom) {
        //console.log('Scroll ===>', scrollToCom);
        scrollViewRef.current?.scrollToEnd();
      }
    }, [scrollToCom])
  );
  useEffect(() => {
    // console.log(showAllComments);
    // console.log(comments);
  }, [showAllComments]);

  return (
    <SafeAreaView
      style={{
        flex: 1,
      }}
    >
      {!loadingOfferByID ? (
        <View>
          <ScrollView ref={scrollViewRef}>
            <View style={styles.mainCarrousel}>
              {/* swiper, return Bnt => like, share external and internal link  use a relative container to palce the position of the retunr btn and share and stuff depending on therest*/}
              <Swiper
                dotColor={BaseColor.fadedGrey}
                activeDotStyle={{ width: 28 }}
                activeDotColor={BaseColor.primaryColor}
              >
                {product.offer_imgs.map((imageData, index) => (
                  <Image
                    style={styles.carrousel}
                    key={index}
                    source={{ uri: serverSection ? imageData : imageData.replace('localhost', '10.0.2.2') }}
                  />
                ))}
              </Swiper>
              <View style={styles.IconsContainer}>
                <View
                  style={{
                    ...styles.iconsFrame,
                    marginTop: 28,
                  }}
                >
                  <Pressable
                    onPress={() => {
                      dispatch(emptyOfferByID());
                      dispatch(emptyComments());
                      setComments((prevState) => []);
                      setLike('');
                      setLikeCount(0);
                      setShowAllComments(false);
                      navigation.navigate('Marketplace');
                    }}
                  >
                    <EntypoIcons name="chevron-left" color={BaseColor.backMain} size={32} />
                  </Pressable>
                </View>
                <View style={styles.socialsContainer}>
                  <View
                    style={{
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}
                  >
                    <View style={styles.iconsFrame}>
                      <Pressable
                        onPress={() => {
                          if (loadingLike) return;
                          if (like) {
                            setLike((prevState) => !prevState);
                            setLikeCount((prevState) => prevState - 1);
                            dispatch(unlikeCommercialOffer({ user_id: userID, offer_id: product.offer_id }));
                            setProduct((prevState) => ({
                              ...prevState,
                              user_has_liked: false,
                              likes: prevState.likes - 1,
                            }));
                          } else {
                            setLike((prevState) => !prevState);
                            setLikeCount((prevState) => prevState + 1);
                            dispatch(likeCommercialOffer({ user_id: userID, offer_id: product.offer_id }));
                            setProduct((prevState) => ({
                              ...prevState,
                              user_has_liked: true,
                              likes: prevState.likes + 1,
                            }));
                          }
                        }}
                      >
                        {!like ? (
                          <AntDesign name="hearto" size={22} color={BaseColor.backMain} />
                        ) : (
                          <AntDesign name="heart" size={22} color={BaseColor.redheart} />
                        )}
                      </Pressable>
                    </View>
                    <Text
                      style={{
                        fontSize: Fonts.font_big,
                        fontFamily: 'Poppins-Medium',
                      }}
                    >
                      {likeCount}
                    </Text>
                  </View>
                  <View
                    style={{
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}
                  >
                    <View style={styles.iconsFrame}>
                      <Feather name="share-2" size={22} color={BaseColor.backMain} />
                    </View>
                    <Text
                      style={{
                        fontSize: Fonts.font_big,
                        fontFamily: 'Poppins-Medium',
                      }}
                    >
                      00
                    </Text>
                  </View>
                  <View
                    style={{
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}
                  >
                    <View style={styles.iconsFrame}>
                      <Octicons name="link" size={22} color={BaseColor.backMain} />
                    </View>
                    <Text
                      style={{
                        fontSize: Fonts.font_big,
                        fontFamily: 'Poppins-Medium',
                      }}
                    >
                      00
                    </Text>
                  </View>
                </View>
              </View>
            </View>
            <View style={styles.partnerTab}>
              {/* main partner tab */}
              <View style={styles.partnerTab}>
                {/* logo and partner name */}
                <Image
                  style={styles.partnerLogo}
                  source={{
                    uri: serverSection
                      ? partnerImge.toString()
                      : partnerImge.toString().replace('localhost', '10.0.2.2'),
                  }}
                />
                <Text
                  style={{
                    marginStart: 12,
                    fontSize: Fonts.font_XL,
                    fontFamily: 'Poppins-SemiBold',
                  }}
                >
                  {partnerName}
                </Text>
              </View>
              <View
                style={{
                  marginRight: 8,
                }}
              >
                {/* counter */}
                <CountDownTimer
                  key={childKey}
                  timestamp={(endingDate - actualDate) / 1000}
                  title={data.title}
                  textStyle={{
                    fontSize: 25,
                    color: `${BaseColor.primaryColor}`,
                    fontFamily: 'Poppins-Medium',
                    letterSpacing: 0.25,
                  }}
                />
              </View>
            </View>
            <View
              style={{
                width: '100%',
                margin: 0,
                padding: 0,
                height: 0.5,
                backgroundColor: BaseColor.primaryLight,
                shadowColor: BaseColor.primarydark,
                shadowOpacity: 0.5,
                shadowOffset: {
                  width: 0,
                  height: 2,
                },
                shadowRadius: 3,
                elevation: 1,
              }}
            ></View>
            <View style={styles.titleSectionContainer}>
              <Text style={styles.titleText}> {data.title} </Text>
            </View>
            <View style={styles.descriptionContaier}>
              {/* description and specs zone */}
              <View style={styles.switcherContainer}>
                {/* swithcer zone */}
                <Pressable
                  style={renderDesc ? styles.activeBtn : styles.nonActiveBtn}
                  onPress={() => handleDescSwitcher(1)}
                >
                  <Text style={renderDesc ? styles.activeText : styles.nonActiveText}>Déscription</Text>
                </Pressable>
                <Pressable
                  style={renderDesc ? styles.nonActiveBtn : styles.activeBtn}
                  onPress={() => handleDescSwitcher(0)}
                >
                  <Text style={renderDesc ? styles.nonActiveText : styles.activeText}>Spécification</Text>
                </Pressable>
              </View>
              <View style={{ marginTop: 18 }}>
                {/* conditional rendering zone */}
                {renderDesc ? (
                  <Text>{data.description}</Text>
                ) : (
                  <Text>This is the spec section{data.specification}</Text>
                )}
              </View>
            </View>
            <View style={styles.cashbackSectionContainer}>
              {/* section avis and price / cahsback now */}
              <View style={styles.avisContainer}>
                {/* avis */}
                <Text style={styles.avistext}>Avis</Text>
                <Image
                  style={{
                    width: '100%',
                    height: 26,
                    resizeMode: 'contain',
                  }}
                  source={Icons.starsAvis}
                />
              </View>
              <View style={styles.cashbackContainer}>
                {/* section prix et cashback */}
                <View style={styles.priceContainer}>
                  <Text
                    style={{
                      color: BaseColor.white,
                      fontSize: Fonts.font_EXXL,
                      fontFamily: 'Poppins-SemiBold',
                    }}
                  >
                    {data.unit_price} €
                  </Text>
                </View>
                <View style={styles.cashbackRationContainer}>
                  <View
                    style={{
                      marginRight: 46,
                      marginLeft: 14,
                    }}
                  >
                    <Text
                      style={{
                        color: BaseColor.white,
                        fontSize: Fonts.font_XL,
                        fontFamily: 'Poppins-Bold',
                      }}
                    >
                      {(data.unit_price * (data.cashback_level1_value / 100)).toFixed(2)} €
                    </Text>
                    <Text
                      style={{
                        color: BaseColor.white,
                        fontSize: Fonts.font_normal,
                      }}
                    >
                      cashback
                    </Text>
                  </View>
                  <Image
                    style={{
                      width: 55,
                      height: 70,
                      resizeMode: 'contain',
                      position: 'absolute',
                      bottom: -15,
                      left: 65,
                    }}
                    source={Mascotts.cashback_mascote}
                  />
                </View>
              </View>
            </View>
            <View style={styles.cashbackCalculationSection}>
              {/* section palier et progression */}
              {/* <Text
                style={{
                  fontSize: Fonts.font_XXL,
                  fontFamily:'Poppins-SemiBold',
                }}
              >
                Palier de progression Cashback
              </Text> */}
              <View style={styles.mainCashbackSection}>
                {/* section palier actuell et suivant */}
                <View
                  style={{
                    flexDirection: 'row',
                    width: '60%',
                    height: 100,
                    justifyContent: 'space-around',
                    marginRight: 12,
                    backgroundColor: BaseColor.darckBlue,
                    borderRadius: 10,
                  }}
                >
                  {/* main actual cashback now */}
                  <View
                    style={{
                      position: 'relative',
                      alignItems: 'center',
                    }}
                  >
                    <Text
                      style={{
                        color: BaseColor.white,
                        fontSize: Fonts.font_big,
                        fontFamily: 'Poppins-Medium',
                        marginTop: 8,
                      }}
                    >
                      Réduction
                    </Text>
                    <Svg
                      style={{
                        marginTop: 4,
                      }}
                      width={size}
                      height={size}
                    >
                      <Circle
                        cx={size / 2}
                        cy={size / 2}
                        r={radius}
                        stroke={BaseColor.fadedGrey}
                        strokeWidth={strokeWidth}
                        fill="none"
                      />
                      <Circle
                        cx={size / 2}
                        cy={size / 2}
                        r={radius}
                        stroke={BaseColor.greenPrimary}
                        strokeWidth={strokeWidth}
                        fill="none"
                        strokeDasharray={`${circumference} ${circumference}`}
                        strokeDashoffset={progressOffset}
                      />
                    </Svg>
                    <Text
                      style={{
                        position: 'absolute',
                        top: '50%',
                        left: '31%',
                        color: BaseColor.white,
                        fontSize: Fonts.font_XL,
                        fontFamily: 'Poppins-Medium',
                      }}
                    >
                      {data.cashback_level1_value}%
                    </Text>
                  </View>
                  <View
                    style={{
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}
                  >
                    <View
                      style={{
                        flexDirection: 'row',
                        justifyContent: 'center',
                        alignItems: 'center',
                      }}
                    >
                      <Text
                        style={{
                          fontSize: Fonts.font_XL,
                          fontFamily: 'Poppins-Medium',
                          color: BaseColor.white,
                          marginRight: 8,
                        }}
                      >
                        0/{data.cashback_level1_sales_limit}
                      </Text>
                      <Icon name="md-pricetags" size={16} color={BaseColor.white} />
                    </View>
                    <Text
                      style={{
                        fontSize: Fonts.font_big,
                        fontFamily: 'Poppins-Medium',
                        color: BaseColor.white,
                        marginTop: 8,
                      }}
                    >
                      Vendu
                    </Text>
                  </View>
                </View>
                <View
                  style={{
                    width: '38%',
                    position: 'relative',
                    justifyContent: 'center',
                    alignItems: 'center',
                    height: 100,
                    backgroundColor: BaseColor.white,
                    borderRadius: 10,
                  }}
                >
                  {/* next step */}
                  <Image
                    style={{
                      position: 'absolute',
                      width: '100%',
                      resizeMode: 'contain',
                      top: -70,
                    }}
                    source={Mascotts.money}
                  />
                  <Text
                    style={{
                      fontSize: Fonts.font_EXXL,
                      fontFamily: 'Poppins-Bold',
                      color: BaseColor.darckBlue,
                    }}
                  >
                    {data.cashback_level2_value.toString()}%
                  </Text>
                  <Text
                    style={{
                      fontSize: Fonts.font_XL,
                      fontFamily: 'Poppins-Medium',
                      color: BaseColor.orangePrimary,
                    }}
                  >
                    Level-Up
                  </Text>
                  <Text
                    style={{
                      fontSize: Fonts.font_normal,
                      fontFamily: 'Poppins-Medium',
                      color: BaseColor.darckBlue,
                    }}
                  >
                    Cashback
                  </Text>
                </View>
              </View>
              <View style={styles.cashbackReviewSectionContainer}>
                {/* section resumer */}
                <Image
                  style={{
                    position: 'absolute',
                    left: -11,
                    width: 100,
                    height: 100,
                    resizeMode: 'contain',
                  }}
                  source={Logo.logo_detail_big}
                />
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginLeft: 48,
                    marginRight: 18,
                  }}
                >
                  <Text
                    style={{
                      fontSize: Fonts.font_XL,
                      fontFamily: 'Poppins-SemiBold',
                      color: BaseColor.primaryColor,
                    }}
                  >
                    Jackpot Cashback
                  </Text>
                  {/* this bring a major problem in our DB structure even an Object.key and value aproche would nor solve this issue efficiently, chaining condition is far less ressource intessive then looping so this code even tho loock primitiive but best solution when it come to calculation wise */}
                  <Text
                    style={{
                      fontSize: Fonts.font_XL,
                      fontFamily: 'Poppins-SemiBold',
                      color: BaseColor.primaryColor,
                      marginRight: 18,
                    }}
                  >
                    {data.cashback_level5_value
                      ? data.cashback_level5_value
                      : data.cashback_level4_value
                      ? data.cashback_level4_value
                      : data.cashback_level3_value
                      ? data.cashback_level3_value
                      : data.cashback_level2_value}
                    %
                  </Text>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginLeft: 48,
                    marginRight: 18,
                  }}
                >
                  <Text
                    style={{
                      fontSize: Fonts.font_XL,
                      fontFamily: 'Poppins-SemiBold',
                      color: BaseColor.orangePrimary,
                    }}
                  >
                    Level-Ups
                  </Text>
                  <Text
                    style={{
                      fontSize: Fonts.font_XL,
                      fontFamily: 'Poppins-SemiBold',
                      color: BaseColor.orangePrimary,
                      marginRight: 18,
                    }}
                  >
                    1/
                    {data.cashback_level5_value
                      ? '5'
                      : data.cashback_level4_value
                      ? '4'
                      : data.cashback_level3_value
                      ? '3'
                      : data.cashback_level2_value
                      ? '2'
                      : '1'}
                  </Text>
                </View>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    marginLeft: 48,
                    marginRight: 18,
                  }}
                >
                  <Text
                    style={{
                      fontSize: Fonts.font_XL,
                      fontFamily: 'Poppins-SemiBold',
                      color: BaseColor.primaryColor,
                    }}
                  >
                    Vente
                  </Text>
                  <Text
                    style={{
                      fontSize: Fonts.font_XL,
                      fontFamily: 'Poppins-SemiBold',
                      color: BaseColor.primaryColor,
                      marginRight: 18,
                    }}
                  >
                    0/
                    {data.cashback_level5_sales_limit
                      ? data.cashback_level4_sales_limit
                      : data.cashback_level4_sales_limit
                      ? data.cashback_level4_sales_limit
                      : data.cashback_level3_sales_limit
                      ? data.cashback_level3_sales_limit
                      : data.cashback_level2_sales_limit
                      ? data.cashback_level2_sales_limit
                      : data.cashback_level1_sales_limit}
                  </Text>
                </View>
              </View>
            </View>
            <View style={styles.commentariesContainer}>
              {/* section commnetaire */}
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
              >
                <Text
                  style={{
                    fontSize: Fonts.font_XL,
                    fontFamily: 'Poppins-Medium',
                    color: BaseColor.backMain,
                    marginLeft: 6,
                  }}
                >
                  Commentaires
                </Text>
                <Text
                  style={{
                    fontSize: Fonts.font_big,
                    fontFamily: 'Poppins-Medium',
                    color: BaseColor.backMain,
                    marginRight: 6,
                  }}
                  onPress={() => setShowAllComments((prevState) => !prevState)}
                >
                  {showAllComments ? 'Afficher moins' : 'Afficher tout'}
                </Text>
              </View>
              <View
                style={{
                  width: '100%',
                  paddingHorizontal: 12,
                  marginTop: 28,
                  marginBottom: 12,
                }}
              >
                {!loadingOfferByID && comments?.length ? (
                  <FlatList
                    data={
                      showAllComments
                        ? comments.slice(0, comments?.length)
                        : comments.slice(
                            comments?.length >= 3 ? comments?.length - 3 : 0,
                            comments?.length >= 3 ? comments?.length : 3
                          )
                    }
                    renderItem={({ item }) => (
                      <View
                        style={{
                          width: '100%',
                          flexDirection: 'row',
                          backgroundColor: BaseColor.white,
                          marginBottom: 12,
                          paddingHorizontal: 8,
                          paddingVertical: 8,
                          borderRadius: 10,
                        }}
                      >
                        <Image
                          style={{
                            width: 48,
                            height: 48,
                            marginRight: 10,
                            borderRadius: 100,
                            borderColor: BaseColor.fadedGrey,
                            borderWidth: 1.6,
                          }}
                          source={
                            item.profile_image
                              ? {
                                  uri: serverSection
                                    ? item.profile_image
                                    : item.profile_image.replace('localhost', '10.0.2.2'),
                                }
                              : require('../../../assets/profile.png')
                          }
                        />
                        <View
                          style={{
                            width: '82%',
                            paddingHorizontal: 8,
                          }}
                        >
                          <Text
                            style={{
                              fontSize: Fonts.font_XL,
                              fontFamily: 'Poppins-Medium',
                              color: BaseColor.backMain,
                            }}
                          >
                            {`${item.first_name ? item.first_name : ''} ${item.last_name}`.trim()}
                          </Text>
                          <Text
                            style={{
                              fontSize: Fonts.font_normal,
                              fontFamily: 'Poppins-Regular',
                              color: BaseColor.backMain,
                              textAlign: 'justify',
                            }}
                          >
                            {item.comment_msg}
                          </Text>
                        </View>
                      </View>
                    )}
                    initialNumToRender={5}
                    keyExtractor={(item) => item.id}
                  />
                ) : null}

                {/* adding input for text */}
              </View>
              <View
                style={{
                  width: '95%',
                  flexDirection: 'row',
                  marginHorizontal: 12,
                  marginBottom: 10,
                  paddingHorizontal: 10,
                  paddingVertical: 0,
                  alignItems: 'center',
                  borderColor: BaseColor.greyMain,
                  borderRadius: 10,
                  borderWidth: 2,
                }}
              >
                <Image
                  style={{
                    width: 42,
                    height: 42,
                    marginRight: 18,
                    borderRadius: 100,
                    borderColor: BaseColor.fadedGrey,
                    borderWidth: 1.6,
                  }}
                  source={
                    userImage
                      ? { uri: serverSection ? userImage : userImage.replace('localhost', '10.0.2.2') }
                      : require('../../../assets/profile.png')
                  }
                />
                <TextInput
                  width={'72%'}
                  label="comment"
                  value={comment}
                  placeholder="Entrer votre commentaire"
                  onChangeText={setComment}
                  multiline={true}
                  numberOfLines={3}
                />
                <Pressable
                  onPress={async () => {
                    if (!comment) return;
                    // setComments(prevState=>[comment, ...prevState]);
                    // console.log(comment);
                    dispatch(
                      createCommercialOfferComment({ user_id: userID, offer_id: data.offer_id, comment_msg: comment })
                    );
                    const newComment = {
                      id: Math.floor(Math.random() * 10000000),
                      created_at: new Date(),
                      user_id: userID,
                      comment_msg: comment,
                      commercial_offer_id: data.offer_id,
                      advertising_offer_id: null,
                      first_name: userfirstName,
                      last_name: userLastName,
                      profile_image: userImage,
                    };
                    setComments((prevState) => {
                      const oldState = prevState;
                      const newState = [...oldState, newComment];
                      return newState;
                    });
                    setComment('');
                  }}
                >
                  <Feather name="send" size={22} color={BaseColor.backMain} />
                </Pressable>
              </View>
            </View>
            <View style={{ height: 50 }}></View>
          </ScrollView>

          <View style={styles.ButtonSection}>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'space-between',
                right: 10,
              }}
            >
              <TouchableOpacity onPress={handlePress}>
                <Image
                  style={{ width: 100, borderRadius: 5, marginHorizontal: 2 }}
                  source={require('../../../assets/ComponentWishlist.png')}
                />
              </TouchableOpacity>
              <TouchableOpacity onPress={handlePress}>
                <Image
                  style={{ width: 100, borderRadius: 5, marginHorizontal: 2 }}
                  source={require('../../../assets/ComponentPanier.png')}
                />
              </TouchableOpacity>

              <TouchableOpacity onPress={handlePress}>
                <Image
                  style={{ borderRadius: 5, marginHorizontal: 2 }}
                  source={require('../../../assets/AchatDirect.png')}
                />
              </TouchableOpacity>
            </View>
          </View>

          <View
            style={{
              width: '100%',
              height: 58,
              flexDirection: 'row',
              justifyContent: 'space-between',
              backgroundColor: BaseColor.white,
              borderColor: BaseColor.fadedGrey,
              borderTopWidth: 1,
              borderBottomWidth: 1,
              paddingHorizontal: 12,
              paddingVertical: 7,
            }}
          >
            <View
              style={{
                width: '46%',
                flexDirection: 'row',
                justifyContent: 'space-around',
              }}
            >
              <View
                style={{
                  justifyContent: 'center',
                  alignItems: 'center',
                  width: '46%',
                  backgroundColor: BaseColor.primarydark,
                  borderRadius: 10,
                }}
              >
                <Image
                  style={{
                    width: 28,
                    height: 28,
                    resizeMode: 'contain',
                  }}
                  source={Icons.wishlist_details}
                />
              </View>
              <View
                style={{
                  justifyContent: 'center',
                  alignItems: 'center',
                  width: '46%',
                  backgroundColor: BaseColor.primarydark,
                  borderRadius: 10,
                }}
              >
                <Image
                  style={{
                    width: 32,
                    height: 36,
                    resizeMode: 'contain',
                  }}
                  source={Icons.cart_details}
                />
              </View>
            </View>
            <View
              style={{
                flexDirection: 'row',
                justifyContent: 'center',
                alignItems: 'center',
                width: '52%',
                backgroundColor: BaseColor.primaryColor,
                borderRadius: 10,
              }}
            >
              <Image
                style={{
                  width: 28,
                  height: 28,
                  resizeMode: 'contain',
                }}
                source={Icons.bag_details}
              />
              <Text
                style={{
                  fontSize: Fonts.font_XL,
                  color: BaseColor.white,
                  fontFamily: 'Poppins-SemiBold',
                  marginHorizontal: 12,
                }}
              >
                Achat direct
              </Text>
            </View>
          </View>
          {/*END sequence*/}
        </View>
      ) : (
        <View
          style={{
            width: '100%',
            height: '100%',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <ActivityIndicator size={56} color={BaseColor.primaryLight} />
        </View>
      )}
    </SafeAreaView>
  );
};

export default OfferDetails;
