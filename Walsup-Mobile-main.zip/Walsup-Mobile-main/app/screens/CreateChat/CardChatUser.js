import React, { useCallback, useEffect, useState } from 'react';
import { Text, TouchableOpacity, StyleSheet, Image, View } from 'react-native';
//server switcher
import { serverSection } from '../../../config/servConf';
import { BaseColor, Fonts } from '../../../config/theme';
import { useFocusEffect } from '@react-navigation/native';
import { getGroupMembers } from '../../store/social/socialThunk';
import { useSelector, useDispatch } from 'react-redux';


const CardChatUser = (props) => {
    const { 
        item,
        handleCallOne,
        type = "default",
        active = true,
        secondaryItem
    } = props;
    const dispatch = useDispatch();
    const { followedUsers, UserGroups, GroupMembers, GroupMembersLoader } = useSelector((store) => store.social);
    const [timeDifference, setTimeDifference] = useState('');
    const [groupMembersData, setGroupMembersData] = useState([])
    // estimated time calculation
    useFocusEffect(
      useCallback(()=>{
        const calculateTime = () => {
          const currentTimestamp = Date.now();
          const lastmessageTime = item.lastMessageCreationDate
          const difference = currentTimestamp - parseInt(lastmessageTime, 10);
          const seconds = Math.floor(difference / 1000);
          const minutes = Math.floor(seconds / 60);
          const hours = Math.floor(minutes / 60);
          const days = Math.floor(hours / 24);
          if(difference > 0){
            if (minutes < 59) {
              setTimeDifference(`${minutes} min`);
            } else if (hours < 24) {
              setTimeDifference(`${hours} heurs`);
            } else if(days === 1) {
              setTimeDifference(`Hier`);
            } else if (days < 6) {
              setTimeDifference(`${days} jours`);
            } else if (days === 7) {
              setTimeDifference('Une semaine');
            } else {
              const date = new Date(parseInt(lastmessageTime, 10));
              let options = {day: '2-digit', month: 'long'};
              const formattedDate = `${date.toLocaleDateString('fr-FR', options)}`;
              setTimeDifference(formattedDate);
            }
          } 
        }
        calculateTime();
      },[item.lastMessageCreationDate, item.uid])
    );
    // useFocusEffect(
    //   useCallback(()=>{
    //     // finish prerendering !!!
    //     const groupeData = UserGroups.filter( elem => elem.id.toString() === item.id)
    //     let members = []
    //     const dispatchData = async ()=>{
    //       if(groupeData[0]){
    //         members = groupeData[0]["member_ids"];
    //         await dispatch(getGroupMembers(members));
    //         setGroupMembersData(prev => GroupMembers)

    //         console.log("groupe members data ===>",groupMembersData);
    //       }
    //     }
    //     dispatchData();
    //   },[item.id, item?.profile_image, item?.group_img]))
    
    return (
        <>
            <View style={styles.Ami}>
                <TouchableOpacity
                    style={styles.AmiInfo}
                    onPress={() => {
                      if(type === "default" && active)handleCallOne(item)
                      if(type === "discussions" && active){
                        item?.profile_image 
                          ? handleCallOne(item.id, item.uid) 
                          : handleCallOne(item.id, null)
                      }}}>
                    <Image
                        style={styles.Amisimage}
                        source={item?.profile_image ? {
                        uri: item?.profile_image && serverSection 
                          ? item?.profile_image 
                          : item.profile_image.replace('localhost', '10.0.2.2') 
                        } : item?.group_img ? {
                          uri : item?.group_img && serverSection 
                              ? item?.group_img
                              : item?.group_img.replace('localhost', '10.0.2.2')
                        }: require('../../../assets/profile.png')}/>
                        {/* notification counter */}
                        {
                          item?.badges > 0 
                          ? (<View
                                style={styles.badgesNotifications}>
                                <Text style={styles.badgesNotifications__text}>{item?.badges> 9 ? "9+" : item?.badges.toString()} </Text>
                              </View>)
                          : null 
                        }
                        <View style={styles.textWrapper}>
                          <Text style={styles.AmiName}>{item?.first_name && item?.last_name 
                            ? `${item?.first_name} ${item?.last_name}` 
                            : item?.groupeName}</Text>
                          <View
                            style={styles.messageIndicators}>
                            {type === "discussions" 
                              ? (<>
                                <Text style={[styles.lastMessage, item.badges>0 ? styles.notificationsOn : {}]}>{item.lastMessage ? `${item.lastMessage.substring(0,19)}...` : "Coucou 👋"}</Text> 
                                {item.lastMessage
                                ?<Text style={parseInt(item.badges) > 0 ? styles.messageIndicators__timerIndicatorON :styles.messageIndicators__timerIndicator}>{timeDifference}</Text>
                                :null}
                              </>)
                              : null}
                          </View>
                        </View>
                </TouchableOpacity>
            </View>
        </>
    )
}

export default CardChatUser;

const styles = StyleSheet.create({
    Ami: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      height: 70,
      width: '100%',
      marginLeft: 15,
    },
    AmiInfo: {
      flexDirection: 'row',
      alignItems: 'center',
      // justifyContent: 'space-between',
      width: '92%',
      position: 'relative'
    },
    Amisimage: {
      width: 50,
      height: 50,
      borderRadius: 40,
    },
    AmiName: {
      fontFamily: 'Poppins-Medium',
      //fontWeight: '500',
      width: '80%',
      fontSize: 13,
      marginLeft: 10,
    },
    lastMessage:{
      fontFamily: 'Poppins',
      width: '80%',
      fontSize: 12,
      marginLeft: 10,
    },
    threeDotsIcon: {
      position: 'absolute',
      top: -10,
      right: 30,
      color: 'rgba(53, 47, 132, 1)',
    },
    checkCircleIcon: {
      position: 'absolute',
      top: 21,
      right: 0,
      color: 'rgba(53, 47, 132, 1)',
    },
    textWrapper:{
      flexDirection: "column",
      width: "80%"
    },
    notificationsOn:{
      fontFamily: "Poppins-Bold"
    }, 
    badgesNotifications: {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      width: 24,
      height: 24,
      borderRadius: 50,
      backgroundColor: BaseColor.redheart,
      position: 'absolute',
      top: -5,
      left: -6
    },
    badgesNotifications__text:{
      color: BaseColor.white,
      marginLeft: 4
    },
    messageIndicators:{
      display: 'flex',
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center'
    },
    messageIndicators__timerIndicator:{
      fontSize: 12,
      fontWeight: "300",
    },
    messageIndicators__timerIndicatorON:{
      fontSize: 11,
      fontFamily: "Poppins-Bold",
    }
  });