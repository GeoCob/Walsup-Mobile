import { StyleSheet, Text, View, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import React, { useEffect, useState, useCallback } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import SearchBarComponent from '../../components/SearchBar';
import AmiCard from '../../components/AmiCard';
import { useDispatch, useSelector } from 'react-redux';
import ModalComponent from '../../components/Modal';
import CreateGroupeIcon from '../../../assets/Icons/components/CreateGroupeIcon';
import { BaseColor } from '../../../config/theme';
import { getfollowedUsers } from '../../store/social/socialThunk';
import NoSocialData from '../../components/noSocialData';
import CardChatUser from './CardChatUser';
import { database } from '../../../config/firebase';
import { ref, set, get, child, getDatabase, push, serverTimestamp, onValue } from 'firebase/database';

//Composant de nouvelle discussion
const CreateChat = ({ navigation }) => {
  const dispatch = useDispatch();
  //Appel aux amis et loader des amis depuis le store social
  const { followedUsers, followedUsersLoader } = useSelector((store) => store.social);
  //Appel à l'utilisateur depuis le store d'authentification
  const { user } = useSelector((store) => store.authentification);
  //Declaration d'une variable dans le state pour l'ouverture et la fermeture de modal
  const [isModalVisible, setisModalVisible] = useState(false);
  // Declaration des variables dans le state relative à la recherche
  const [clicked, setClicked] = useState(false);
  const [searchPhrase, setSearchPhrase] = useState('');
  const [searchingStatus, setSearchStatus] = useState(false);
  const [searchResults, setSearchResults] = useState([]);
  //Declaration des variables pour le load et le set des amis à discuter avec
  const [sanitisedSelection, setSanitisedSelection] = useState([]);
  const [loading, setLoading] = useState(false);
  const [active, setActive] = useState(true);

  //Fonction de toggle de modal
  const ModalVisibiltyToggle = () => {
    setisModalVisible(!isModalVisible);
  };

  //UseEffect qui appel le reducer de fetch des amis
  useEffect(() => {
    if (user.uid) {
      dispatch(getfollowedUsers(user.uid));
    }
  }, []);

  //UseFocusEffect pour le fetch des données des conversations
  useFocusEffect(
    useCallback(() => {
      //Initialisation de données
      setSanitisedSelection([]);
      //lancement de loader
      setLoading(true);
      //Appel à la base de données firebase
      const db = getDatabase();
      //accées à la base de données et reference
      const dbRef = ref(db, `privateChatConversation/${user.uid}`);
      //Fonction de fetch de data
      const unsubscribe = onValue(dbRef, (snapShot) => {
        const value = snapShot.val();
        if (value) {
          const newData = Object.entries(value).map(([id, value]) => ({ id, ...value }));
          const newArray = [];
          //optimise this by switching to SQL backend aproche it's a O(n)² not deadly but bad
          for (let indexone = 0; indexone < followedUsers.length; indexone++) {
            const elementTest = followedUsers[indexone];
            for (let indexTwo = 0; indexTwo < newData.length; indexTwo++) {
              const elementFilter = newData[indexTwo];
              if (elementTest.uid === elementFilter.uid) break;
              if (indexTwo + 1 === newData.length) newArray.push(elementTest);
            }
          }
          //Mise à jour de données
          setSanitisedSelection(newArray);
        }
        if (!value) setSanitisedSelection(followedUsers); // sinon retour de données vide (on a des discussions avec tous nos amis)
        setLoading(false);
      });

      // cleanup function
      return () => unsubscribe();
    }, [])
  );

  // Fonction de recherche
  const SearchHandle = () => {
    if (sanitisedSelection) {
      const newState = sanitisedSelection?.filter((search) =>
        search.first_name
          ? search.first_name.toLowerCase().includes(searchPhrase.toLowerCase()) ||
            search.last_name.toLowerCase().includes(searchPhrase.toLowerCase())
          : search.name.toLowerCase().includes(searchPhrase.toLowerCase())
      );
      setSearchResults(newState);
      setSearchStatus(true);
    } else {
      ressetSearch();
    }
  };
  //reset de la recherche
  const ressetSearch = () => {
    setSearchResults([]);
    setSearchPhrase('');
    setSearchStatus(false);
    setClicked(false);
  };

  //Fonction de creation de nouvelle discussion
  const createPrivateChatRoom = async (friend) => {
    setActive(false);
    try {
      //set d'id de conversation en contatinant les deux uid des utilisateurs avec celui le plus grand en premier
      const conversationID = user.uid > friend.uid ? `${user.uid}${friend.uid}` : `${friend.uid}${user.uid}`;
      //Appel à la base de données firebase
      const db = getDatabase();
      //reference à la base de données
      const dbRef = ref(db);
      //accées à la base de données pour l'utilisateur connecté
      const snapShot = await get(child(dbRef, `privateChatConversation`));
      //set des données dans la base de données
      await set(ref(db, `privateChatConversation/${user.uid}/${conversationID}`), {
        creationDate: serverTimestamp(),
        lastMessage: '',
        lastMessageCreationDate: serverTimestamp(),
        badges: 0,
        uid: friend.uid,
        first_name: friend.first_name,
        last_name: friend.last_name,
        profile_image: friend.profile_image,
      });
      //set des données pour l'ami de l'utilisateur connecté
      await set(ref(db, `privateChatConversation/${friend.uid}/${conversationID}`), {
        creationDate: serverTimestamp(),
        lastMessage: '',
        lastMessageCreationDate: serverTimestamp(),
        badges: 0,
        uid: user.uid,
        first_name: user.first_name,
        last_name: user.last_name,
        profile_image: user.profile_image,
      });
      //verification des deux utilisateurs
      const checkResultme = await get(child(dbRef, `privateChatConversation/${user.uid}/${conversationID}`));
      const checkResultfriend = await get(child(dbRef, `privateChatConversation/${friend.uid}/${conversationID}`));
      //si les deeux données sont crées et verifiés alors on supprime l'ami de la page de creation de discussion
      if (checkResultme.exists() && checkResultfriend.exists()) {
        const removedFromList = sanitisedSelection?.filter((item) => item.uid !== friend.uid);
        setSanitisedSelection(removedFromList);
      }
      await new Promise((resolve) => setTimeout(resolve, 200));
      setActive(true);
      //navigation vers la discussion avec l'ami
      const recieverData = followedUsers.filter((item) => item.uid === friend.uid);
      navigation.navigate('Discussion', {
        conversationId: conversationID,
        recieverId: friend.uid,
        recieverData: recieverData[0],
        type: 'default',
      });
    } catch (error) {
      console.log(error);
    }
  };
  return (
    <View style={{ backgroundColor: 'white', flex: 1 }}>
      <SearchBarComponent
        clicked={clicked}
        setClicked={setClicked}
        searchPhrase={searchPhrase}
        setSearchPhrase={setSearchPhrase}
        search={SearchHandle}
        setSearchStatus={setSearchStatus}
        ressetSearch={ressetSearch}
      />
      {/* create groupe section */}
      <View style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
        <TouchableOpacity
          style={styles.container__create__groupe}
          onPress={() => {
            setisModalVisible(true);
          }}
        >
          <CreateGroupeIcon />
        </TouchableOpacity>
        <Text style={styles.createGroup}>Créer un nouveau groupe</Text>
      </View>
      <ModalComponent isModalVisible={isModalVisible} ModalVisibiltyToggle={ModalVisibiltyToggle} type="groupeCreate" />
      {/* End create groupe section */}
      <Text style={styles.title}>Suggestions</Text>
      {/* loader && !followedUsers?.length */}
      {!followedUsersLoader && !loading && sanitisedSelection?.length > 0 ? (
        <ScrollView style={{ flex: 0.8 }}>
          {/* if search active then return result search view */}
          {searchResults?.length && searchPhrase && searchingStatus ? (
            searchResults.map((item) => <CardChatUser key={item.uid} item={item} />)
          ) : // if no result for search
          !searchResults?.length && searchPhrase && searchingStatus ? (
            <NoSocialData Description="Aucun Resultas de recherhce" />
          ) : // if no search done
          sanitisedSelection?.length > 0 ? (
            sanitisedSelection?.map((item) => (
              <CardChatUser key={item.uid} item={item} active={active} handleCallOne={createPrivateChatRoom} />
            ))
          ) : (
            <ActivityIndicator />
          )}
        </ScrollView>
      ) : (
        <NoSocialData Description={"votre liste d'amis est vide"} />
      )}
    </View>
  );
};

export default CreateChat;

const styles = StyleSheet.create({
  container__create__groupe: {
    width: 40,
    height: 40,
    backgroundColor: BaseColor.fadedGrey,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 20,
  },
  title: {
    color: '#858585',
    fontSize: 16,
    fontFamily: 'Poppins-Bold',
    marginLeft: 20,
    paddingVertical: 10,
  },
  createGroup: {
    color: '#333333',
    fontSize: 16,
    fontFamily: 'Poppins-Regular',
    marginLeft: 20,
    paddingVertical: 10,
  },
});
