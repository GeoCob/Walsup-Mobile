import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  screen: {
    flex: 1,
  },
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor:'#ffffff'
  },
  logo: {
    width: 281,
    height: 50,
    resizeMode: 'contain',
    marginBottom: 30,
  },
  backgroundImage: {
    position: 'absolute',
    width: '100%',
    height: '100%',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
  },
  cardContainer: {
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
    borderColor: '#6858DD',
    backgroundColor: '#ffffff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
    elevation: 2,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#F5F5F5',
    width: 285,
    borderRadius: 10,
    height: 46,
    marginBottom: 25,
    paddingHorizontal: 10,
    justifyContent: 'space-between',
    alignItems: 'center',
    flexDirection: 'row',
    borderWidth: 1,
    borderColor: '#EDEFFE',
  },
  buttonSignIn: {
    backgroundColor: '#352F84',
    width: 285,
    borderRadius: 10,
    padding: 10,
    margin: 10,
  },
});
