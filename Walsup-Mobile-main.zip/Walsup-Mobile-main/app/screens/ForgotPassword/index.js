import React, { useState } from 'react';
import { View, Image, TextInput, TouchableOpacity, Text, KeyboardAvoidingView } from 'react-native';
import styles from './styles';

//Composant de mot de passe oublié (Fonctionnalité n'est pas encore implementé)
const ForgotPassword = ({ navigation }) => {
  const [email, setEmail] = useState('');

  return (
    <KeyboardAvoidingView style={styles.screen} behavior="height">
      <View style={styles.container}>
        <Image source={require('../../../assets/logo-walsup.png')} style={styles.logo} />
        <TextInput style={styles.input} placeholder="E-mail" value={email} onChangeText={(text) => setEmail(text)} />
        <TouchableOpacity
          style={styles.buttonSignIn}
          title="Envoyer"
          onPress={() => {
            // handle forgotPassword button press
          }}
        >
          <Text style={styles.buttonText}>Envoyer</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

export default ForgotPassword;
