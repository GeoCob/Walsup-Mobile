import React, { useRef, useEffect } from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet, Easing } from 'react-native';
import Animated, { useAnimatedStyle } from 'react-native-reanimated';
import styles from './styles';
import { useSelector, useDispatch } from 'react-redux';
import { logoutUser } from '../../store/authentication/authenticationSlice';

//Composant de déconnexion
const Disconnect = ({ navigation }) => {
  //Declaration de variable d'animation selon l'axe des Y
  const translateY = useRef(new Animated.Value(0)).current;
  //Appel à l'utilisateur et son loader de store d'authentification
  const { user, loading } = useSelector((store) => store.authentification);

  const dispatch = useDispatch();

  //UseEffect d'animation d'image
  useEffect(() => {
    Animated.timing(translateY, {
      toValue: -50,
      duration: 1000,
      easing: Easing.linear,
      useNativeDriver: true,
    }).start(({ finished }) => {
      if (finished) {
        Animated.timing(translateY, {
          toValue: 0,
          duration: 1000,
          easing: Easing.linear,
          useNativeDriver: true,
        }).start(({ finished }) => {
          if (finished) {
            Animated.timing(translateY, {
              toValue: -50,
              duration: 1000,
              easing: Easing.linear,
              useNativeDriver: true,
            }).start();
          }
        });
      }
    });
  }, []);

  //UseEffect
  useEffect(() => {
    const timer = setTimeout(() => {
      //Appel au reducer de déconnexion d'utilisateur
      dispatch(logoutUser());
    }, 2000);
    return () => clearTimeout(timer);
  }, [navigation]);

  useEffect(() => {
    //Si l'utilisateur n'existe plus et le load est terminé
    if (!loading && !user.uid) {
      //Navigation vers la page d'authentification (1ere screen de l'app)
      navigation.navigate('Authentification');
    }
  }, [loading, user]);

  const imageStyle = {
    transform: [
      {
        translateY: translateY,
      },
    ],
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}> Â Bientôt!</Text>
      <TouchableOpacity>
        <Animated.Image source={require('../../../assets/félicitation.png')} style={[styles.image, imageStyle]} />
      </TouchableOpacity>
    </View>
  );
};

export default Disconnect;
