import React, { useState, useEffect } from 'react';
import {
  View,
  Image,
  TextInput,
  TouchableOpacity,
  Text,
  KeyboardAvoidingView,
  ScrollView,
  ActivityIndicator,
} from 'react-native';
import styles from './styles';
import { GoogleSignin, statusCodes } from '@react-native-google-signin/google-signin';
import { LoginManager, AccessToken } from 'react-native-fbsdk-next';
import { BaseColor } from '../../../config/theme';
import * as Yup from 'yup';
import { useFormik } from 'formik';
import { useDispatch, useSelector } from 'react-redux';
import {
  loginUserWithFacebook,
  loginUserWithGoogle,
  loginUserRun,
} from '../../store/authentication/authenticationThunk';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../../../config/firebase';

import Ionicons from 'react-native-vector-icons/Ionicons';
import WalsupIconSVG from '../../../assets/Icons/components/WalsupIconSVG';
import { useFocusEffect } from '@react-navigation/native';

//Composant de connexion
const SignIn = ({ navigation }) => {
  //Declaration de variable dans le state pour les champs de formulaires (n'est plus utilisé)
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  //Declaration de variable dans le state pour le message d'erreur
  const [errorMessage, setErrorMessage] = useState(null);
  //Declaration de variable dans le state pour le load
  const [thirdPartyLoading, setThirdPartyLoading] = useState(false);
  //Declaration de variable dans le state pour l'affichage de message d'erreur
  const [showErrorMessage, setShowErrorMessage] = useState(false);
  //Declaration de variable dans le state pour l'affichage de mot de passe
  const [passwordVisibility, setPasswordVisibility] = useState(true);
  //Appel de loader , d'utilisateur et d'erreur de connexion depuis le store d'authentification
  const { loading, user, LoginError } = useSelector((store) => store.authentification);
  const dispatch = useDispatch();

  //Fonction de toggle de visibilité de mot de passe
  const togglePasswordVisibility = () => {
    setPasswordVisibility(!passwordVisibility);
  };

  //UseFocusEffect
  useFocusEffect(
    React.useCallback(() => {
      if (user?.uid && !loading && !thirdPartyLoading) {
        //verification si l'utilisateur est chargé et existant on se navigue vers la page de felicitation
        setErrorMessage(null);
        setShowErrorMessage(false);
        navigation.navigate('SigninSuccess', { comingFrom: 'SignIn' });
      } else if (LoginError?.error && !loading && !thirdPartyLoading) {
        //Set d'erreur
        setErrorMessage(LoginError.error);
        setShowErrorMessage(true);
        //console.log(LoginError);
      } else {
        //console.log(3);
        setErrorMessage(null);
        setShowErrorMessage(false);
      }
    }, [LoginError, loading, thirdPartyLoading])
  );

  //Configuration Oauth2.0 pour l'api de connexion et inscription google
  GoogleSignin.configure({
    webClientId: '281609768173-ea66e1boqhbsaggou1dsbm1lsfs4pccp.apps.googleusercontent.com',
  });

  //Fonction de submit de connexion par facebook
  const onSubmitFacebook = async () => {
    try {
      //Lancement de Loader
      setThirdPartyLoading(true);
      //Deconnexion d'utilisateur s'il y a un utilisateur connecté dans l'api
      await LoginManager.logOut();
      //Connexion d'utilisateur par l'application Facebook
      const result = await LoginManager.logInWithPermissions(['public_profile', 'email']);
      //Extraction de token d'accées Facebook d'utilisateur
      const data = await AccessToken.getCurrentAccessToken();
      const accessToken = data.accessToken;
      //Appel au reducer de connexion par facebook en y passant la token d'accées
      dispatch(loginUserWithFacebook(accessToken));
      //Reinitialisation d'erreur
      setErrorMessage(null);
    } catch (error) {
      console.log(error);
    } finally {
      setThirdPartyLoading(false);
    }
  };
  //Fonction de submit de connexion par Google
  const onSubmitGoogle = async () => {
    try {
      //Lancement de Loader
      setThirdPartyLoading(true);
      //Verificatiion s'il y a un utilisateur connecté
      const isloggedin = await GoogleSignin.getCurrentUser();
      if (isloggedin) {
        //Deconnexion d'utilisateur connecté existant
        await GoogleSignin.signOut();
        await GoogleSignin.revokeAccess();
      } else {
        //Appel à Google Play services
        await GoogleSignin.hasPlayServices();
        //Connexion à compte Google
        const userInfo = await GoogleSignin.signIn();
        //console.log('user', userInfo);
        //Extraction de token d'accées de compte google
        await GoogleSignin.getTokens()
          .then(async (res) => {
            //Appel au reducer de connexion par Google en y passant la token d'accées
            // console.log('token', res.accessToken); //<-------Get accessToken
            await dispatch(loginUserWithGoogle(res.accessToken));

            setErrorMessage(null);
          })
          .catch((err) => {
            //console.log('error', err);
          });
      }
    } catch (error) {
      if (error.code === statusCodes.SIGN_IN_REQUIRED) {
        await GoogleSignin.hasPlayServices();
        const userInfo = await GoogleSignin.signIn();
        //console.log('user', userInfo);
        await GoogleSignin.getTokens()
          .then(async (res) => {
            // console.log('token', res.accessToken); //<-------Get accessToken
            await dispatch(loginUserWithGoogle(res.accessToken));

            setErrorMessage(null);
          })
          .catch((err) => {
            //console.log('error', err);
          });
      }
    } finally {
      setThirdPartyLoading(false);
    }
  };

  //Fonction de submission de formulaire de connexion par email et mot de passe
  const onSubmit = async () => {
    try {
      //Lancement de Loader
      setThirdPartyLoading(true);
      const Email = values.email.toLowerCase().trim();
      //Connexion par email et mot de passe en utilisant firebase
      signInWithEmailAndPassword(auth, Email, values.password)
        .then((userCredential) => {
          // Signed in
          if (userCredential.user) {
            const Data = {
              email: Email,
            };
            //Appel au reducer de connexion par email et mot de passe
            dispatch(loginUserRun(Data));

            setErrorMessage(null);
          }
        })
        .catch((error) => {
          if (error.code === 'auth/user-not-found') {
            const errormsg = "utilisateur introuvable, veuillez vous s'inscrire";
            setErrorMessage(errormsg);
          } else if (error.code === 'auth/invalid-email') {
            const errormsg = ' Votre email est invalid';
            setErrorMessage(errormsg);
          } else if (error.code === 'auth/too-many-requests') {
            const errormsg =
              'Ce Compte est désactivé a cause\nde plusieurs tentatives de connexion échoué.\nVous pouvez réactiver votre compte\n en réintialisant votre mot de passe';
            setErrorMessage(errormsg);
          } else if (error.code === 'auth/wrong-password') {
            const errormsg = 'Mot de passe incorrect!';
            setErrorMessage(errormsg);
          } else {
            console.log(error);
          }
        });
    } catch (err) {
      console.log(err);
    } finally {
      setThirdPartyLoading(false);
    }
  };

  //Verification et Validation de formulaire
  const validationSchema = Yup.object().shape({
    email: Yup.string().email('Veuillez entrer un email valide').required("L'email est obligatoire"),
    password: Yup.string().required('Le mot de passe est obligatoire'),
  });

  //Instantiation de formulaire par formik
  const { values, handleChange, handleBlur, errors, touched } = useFormik({
    initialValues: {
      email: '',
      password: '',
    },
    validationSchema: validationSchema,
    onSubmit,
  });

  //retour de formulaire correspondant de connexion
  return (
    <>
      {loading ? (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator size={56} color={BaseColor.primaryLight} />
        </View>
      ) : (
        <View style={styles.container}>
          <View style={{ marginBottom: 20 }}>
            <WalsupIconSVG />
          </View>
          <View>
            <TextInput
              style={styles.input}
              placeholder="E-mail"
              value={values.email}
              onChangeText={handleChange('email')}
              onBlur={handleBlur('email')}
            />
            {errors.email && touched.email ? (
              <View style={{ alignSelf: 'baseline', marginLeft: 0 }}>
                <Text style={{ color: '#FF0000', fontSize: 10, marginBottom: -10 }}>{errors.email}</Text>
              </View>
            ) : null}
            <View style={styles.passwordContainer}>
              <TextInput
                style={[styles.input, styles.passwordInput]}
                placeholder="Mot de passe"
                value={values.password}
                onChangeText={handleChange('password')}
                onBlur={handleBlur('password')}
                secureTextEntry={passwordVisibility}
              />
              <TouchableOpacity style={styles.eyeIcon} onPress={togglePasswordVisibility}>
                <Ionicons name={passwordVisibility ? 'eye' : 'eye-off'} size={24} color="gray" />
              </TouchableOpacity>
            </View>
            {errors.password && touched.password ? (
              <View style={{ alignSelf: 'baseline', marginLeft: 0 }}>
                <Text style={{ color: '#FF0000', fontSize: 10, marginTop: -10 }}>{errors.password}</Text>
              </View>
            ) : null}
            <TouchableOpacity onPress={() => navigation.navigate('ForgotPassword')}>
              <Text style={styles.forgotPasswordText}>Mot de passe oublié ?</Text>
            </TouchableOpacity>
            {showErrorMessage && errorMessage && !loading ? (
              <View
                style={{
                  paddingHorizontal: 10,
                  paddingVertical: 5,
                  backgroundColor: 'white',
                  borderRadius: 5,
                  marginTop: 10,
                }}
              >
                <Text style={{ color: 'red' }}>{errorMessage}</Text>
              </View>
            ) : null}
          </View>
          <TouchableOpacity
            style={styles.buttonSignIn}
            title="Connexion"
            onPress={() => {
              // handle sign in button press
              onSubmit();
            }}
          >
            <Text style={styles.buttonText}>Se Connecter</Text>
          </TouchableOpacity>
          <View
            style={{
              borderColor: '#F5F8FC',
              width: '63%',
              borderWidth: 1,
              marginTop: 30,
              marginBottom: 10,
            }}
          />
          <Text style={styles.orText}>Ou continuer avec</Text>
          <View style={styles.iconContainer}>
            <TouchableOpacity
              onPress={() => {
                // handle FaceBook login
                onSubmitFacebook();
              }}
            >
              <Image source={require('../../../assets/FacebookIcon.png')} style={styles.icon} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                // handle Google login
                onSubmitGoogle();
              }}
            >
              <Image source={require('../../../assets/GoogleIcon.png')} style={styles.icon} />
            </TouchableOpacity>
            <TouchableOpacity>
              <Image source={require('../../../assets/AppleIcon.png')} style={styles.icon} />
            </TouchableOpacity>
          </View>
          <View style={styles.haveAnAccountContainer}>
            <Text style={styles.haveAnAccount}>Vous n'avez pas de compte ? </Text>
            <TouchableOpacity
              onPress={() => {
                setErrorMessage(null);
                navigation.navigate('SignUp');
              }}
            >
              <Text style={styles.haveAnAccountLink}>S'inscrire</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </>
  );
};

export default SignIn;
