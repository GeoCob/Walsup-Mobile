import { Text, StyleSheet, View, Image, TouchableOpacity, ActivityIndicator } from 'react-native';
import React, { Component, useEffect, useState } from 'react';
import CustomButton from '../../components/Button';
import Tabs from '../Social/tabs';
import { useDispatch, useSelector } from 'react-redux';
import TabContent from '../Social/tabContent';
import ModalComponent from '../../components/Modal';
import { Octicons } from '@expo/vector-icons';
import { database } from '../../../config/firebase';
import { child, get, ref, set, getDatabase, serverTimestamp } from 'firebase/database';
import {
  AcceptReceivedFollow,
  DeclineReceivedFollow,
  DeleteSentRequest,
  FollowUser,
  GetFriendShipState,
  getFriendfollowedUsers,
  getFirendAllGroupsById,
  getFriendAllSubscribedPartners,
  getAllSubscribedPartners,
  getDiscussionData,
} from '../../store/social/socialThunk';

//Composant de profile social (profile d'utilisateur)
const ProfileSocial = ({ route, navigation }) => {
  //Appel d'item de params de route
  const { item } = route.params;
  //Appel d'utilisateur depuis le store d'authentification
  const { user } = useSelector((store) => store.authentification);

  //Appel des amis , loader des amis , groupes et loader de group , status d'amitié et loader de status d'amitié
  const {
    FriendfollowedUsers,
    FriendfollowedUsersLoader,
    FriendUserGroups,
    FriendUserGroupsLoader,
    IsFriend,
    IsFriendLoader,
  } = useSelector((store) => store.social);

  //Declaration d'une variable dans le state pour le type de la tab active (amis,groupes,abonnements)
  const [tabType, setTabType] = useState('amisProfil');
  const dispatch = useDispatch();
  //Declaration d'une varriable dans le state pour la visibilité de modal
  const [isModalVisible, setisModalVisible] = useState(false);
  //Declaration d'une varaible danse le state pour l'ami à retirer de la liste des amis
  const [FriendRemove, setFriendRemove] = useState(null);

  //UseEffect
  useEffect(() => {
    //Appel au reducer de fetch des amis d'un ami
    dispatch(getFriendfollowedUsers(item.uid));
    //Set de données d'utilisateur connecté et l'ami dont le profil est affiché dans un objet
    const data = {
      uid: user.uid,
      friend_uid: item.uid,
    };
    //Appel au reducer de fetch de status d'amitié en y passant l'objet de données de deux utilisateurs
    dispatch(GetFriendShipState(data));
    //Appel au reducer de fetch des groupe d'un ami
    dispatch(getFirendAllGroupsById(item.uid));
    //Appel au reducer de fetch des partenaires abonnées d'un ami
    dispatch(getFriendAllSubscribedPartners({ user_uid: item.uid }));
  }, [item]);

  //Fonction d'envois de demande
  const SendRequest = () => {
    //Set de données d'utilisateur connecté et l'ami dont le profil est affiché dans un objet
    const data = {
      sender_id: user.uid,
      requested_id: item.uid,
    };
    //Appel au reducer de creation de demande d'amitié
    dispatch(FollowUser(data));
  };

  //Fonction d'acceptation de demande d'amitié reçu
  const AcceptRequest = () => {
    //set de données d'utilisateur connecté et l'ami dont le profil est affiché dans un objet
    const data = {
      sender_id: item.uid,
      requested_id: user.uid,
    };
    //Appel au reducer d'acceptation de demande d'amitié reçu
    dispatch(AcceptReceivedFollow(data));
  };

  //Fonction de rejet de demande d'amitié reçu
  const DeclineRequest = () => {
    //set de données d'utilisateur connecté et l'ami dont le profil est affiché dans un objet
    const data = {
      sender_id: item.uid,
      requested_id: user.uid,
    };
    //Appel au reducer de rejet de demande d'amitié reçu
    dispatch(DeclineReceivedFollow(data));
  };

  //Fonction de suppression de demande d'amitié envoyé (annulation)
  const DeleteRequest = () => {
    //set de données d'utilisateur connecté et l'ami dont le profil est affiché dans un objet
    const data = {
      sender_id: user.uid,
      requested_id: item.uid,
    };
    //Appel au reducer de suppression de demande d'amitié envoyé
    dispatch(DeleteSentRequest(data));
  };

  //Fonction d'ouverture de modal d'ami
  const ModalVisibiltyToggle = (friend) => {
    setisModalVisible(!isModalVisible);
    setFriendRemove(friend);
  };

  //Fonction de changement de tab active
  const handleTabChange = (tabType) => {
    setTabType(tabType);
  };
  //Fonction de navigation vers la discussion avec un ami
  const navigateToDiscussion = async (item) => {
    // Navigate to the "Discussion" component
    //creation de conversation on utilisant la logique de concatination des uids des deux amis en mettant l'uid la plus grande en premier
    const conversationID = user.uid > item.uid ? `${user.uid}${item.uid}` : `${item.uid}${user.uid}`;
    // check if discution exits
    try {
      //appel à la base de données firebase
      const db = getDatabase();
      //referance à la base de données firebase
      const dbRef = ref(db);
      //fetch de la conversation de la base de données
      const snapShot = await get(child(dbRef, `privateChatConversation/${user.uid}/${conversationID}`));
      if (snapShot.exists()) {
        //si la conversation existe on navigue vers la discussion en passant les données correspondants
        navigation.navigate('Discussion', {
          conversationId: conversationID,
          recieverId: item.uid,
          recieverData: item,
          type: 'default',
        });
      } else {
        //sinon la creation de la conversation en intitialisant les données
        await set(ref(db, `privateChatConversation/${user.uid}/${conversationID}`), {
          creationDate: serverTimestamp(),
          lastMessage: '',
          lastMessageCreationDate: serverTimestamp(),
          badges: 0,
          uid: item.uid,
          first_name: item.first_name,
          last_name: item.last_name,
          profile_image: item.profile_image,
        });
        await set(ref(db, `privateChatConversation/${item.uid}/${conversationID}`), {
          creationDate: serverTimestamp(),
          lastMessage: '',
          lastMessageCreationDate: serverTimestamp(),
          badges: 0,
          uid: user.uid,
          first_name: user.first_name,
          last_name: user.last_name,
          profile_image: user.profile_image,
        });
        //navigation vers la discussion
        navigation.navigate('Discussion', {
          conversationId: conversationID,
          recieverId: item.uid,
          recieverData: item,
          type: 'default',
        });
      }
    } catch (error) {
      console.log(error);
    }
  };
  //fonction qui retourne le contrnu de tab selon la tab active
  const getTable = (TabType) => {
    switch (TabType) {
      case 'amisProfil':
        return (
          <TabContent
            FriendfollowedUsers={FriendfollowedUsers}
            FriendfollowedUsersLoader={FriendfollowedUsersLoader}
            tab={tabType}
            ListeName={"Liste d'amis"}
            user={user}
            navigation={navigation}
            otherUser={item}
          />
        );
      case 'groupesProfil':
        return (
          <TabContent
            tab={tabType}
            ListeName={'Mes Groupes'}
            SuggstionsName={'Suggestions'}
            FriendUserGroups={FriendUserGroups}
            FriendUserGroupsLoader={FriendUserGroupsLoader}
            user={user}
            otherUser={item}
            navigation={navigation}
          />
        );
      case 'abonnementsProfil':
        return (
          <TabContent
            tab={tabType}
            user={user}
            otherUser={item}
            navigation={navigation}
            ListeName={'Liste des Partnaires'}
            SuggstionsName={'Suggestions'}
          />
        );
      default:
        return <></>;
    }
  };
  const tableToRender = getTable(tabType);
  //retour de l'ui de profile et des tabs et de contenu de tab active
  return (
    <>
      <View style={styles.container}>
        <View style={styles.rect}>
          <View style={styles.imageRow}>
            <Image
              source={{ uri: item.profile_image.toString().replace('localhost', '10.0.2.2') }}
              resizeMode="cover"
              style={styles.image}
            ></Image>
            <View style={styles.TextContainer}>
              <View style={styles.NameContainer}>
                <Text style={styles.Name}>{item.first_name + ' ' + item.last_name}</Text>
                <Text style={styles.text2}>{item.friend_count}</Text>
                <Text style={styles.text}>{item.group_count}</Text>
                {IsFriend === 'Suggestion' ? (
                  !IsFriendLoader ? (
                    <CustomButton
                      title="Ajouter"
                      style={styles.Button}
                      onPress={() => {
                        SendRequest();
                      }}
                    />
                  ) : (
                    <ActivityIndicator style={{ left: 70, top: 60, position: 'absolute' }} />
                  )
                ) : IsFriend === 'Ami' ? (
                  !IsFriendLoader ? (
                    <TouchableOpacity
                      style={[styles.Button]}
                      onPress={() => {
                        navigateToDiscussion(item);
                      }}
                    >
                      <Octicons name="comment-discussion" size={17} style={styles.Icon} />
                      <Text style={[styles.buttonText]}>Envoyer un message</Text>
                    </TouchableOpacity>
                  ) : (
                    <ActivityIndicator style={{ left: 70, top: 60, position: 'absolute' }} />
                  )
                ) : IsFriend === 'Received' ? (
                  !IsFriendLoader ? (
                    <View style={styles.DoubleButtonContainer}>
                      <CustomButton
                        title="Accepter"
                        style={styles.DoubleButton1}
                        onPress={() => {
                          AcceptRequest();
                        }}
                      />
                      <CustomButton
                        title="Supprimer"
                        style={styles.DoubleButton2}
                        onPress={() => {
                          DeclineRequest();
                        }}
                        Textstyle={{ color: 'black' }}
                      />
                    </View>
                  ) : (
                    <ActivityIndicator style={{ left: 70, top: 60, position: 'absolute' }} />
                  )
                ) : IsFriend === 'Sent' ? (
                  !IsFriendLoader ? (
                    <CustomButton
                      title="Annuler la demande"
                      style={[styles.Button, { backgroundColor: 'rgba(242, 242, 242, 1)' }]}
                      Textstyle={{ color: 'black' }}
                      onPress={() => {
                        DeleteRequest();
                      }}
                    />
                  ) : (
                    <ActivityIndicator style={{ left: 70, top: 60, position: 'absolute' }} />
                  )
                ) : null}
              </View>
              <Text style={styles.amis}>Amis</Text>
              <Text style={styles.groups}>Groupes</Text>
            </View>
            <CustomButton
              title="+"
              style={styles.Button1}
              Textstyle={{
                fontFamily: 'Poppins-Regular',
                fontSize: 18,
                position: 'absolute',
                top: -3,
              }}
              onPress={() => {
                ModalVisibiltyToggle(item);
              }}
            />
          </View>
        </View>
        <View style={styles.Container}>
          <View style={styles.tabsContainer}>
            <Tabs
              type={'amisProfil'}
              title={'amis'}
              tabType={tabType}
              selected={tabType === 'amisProfil'}
              changeTabType={(type) => handleTabChange(type)}
              user={user}
              otherUser={item}
            />
            <Tabs
              type={'groupesProfil'}
              title={'groupes'}
              tabType={tabType}
              selected={tabType === 'groupesProfil'}
              changeTabType={(type) => handleTabChange(type)}
              user={user}
              otherUser={item}
            />
            <Tabs
              type={'abonnementsProfil'}
              title={'abonnements'}
              tabType={tabType}
              selected={tabType === 'abonnementsProfil'}
              changeTabType={(type) => handleTabChange(type)}
              user={user}
              otherUser={item}
            />
          </View>
          {tableToRender}
        </View>
      </View>
      <ModalComponent
        item={FriendRemove}
        user={user}
        isModalVisible={isModalVisible}
        ModalVisibiltyToggle={ModalVisibiltyToggle}
        type="+"
      />
    </>
  );
};
export default ProfileSocial;

const styles = StyleSheet.create({
  container: {
    marginTop: -35,
    flex: 1,
    backgroundColor: 'rgba(255,255,255,1)',
  },
  rect: {
    flex: 0.2,
    width: 342,
    height: 79,
    left: 20,
    top: 50,
    backgroundColor: 'rgba(255,255,255,1)',
    flexDirection: 'row',
  },
  image: {
    width: 75,
    height: 75,
    borderRadius: 44,
    borderWidth: 0,
    borderColor: '#000000',
    marginTop: 1,
  },
  Name: {
    top: -1,
    left: 0,
    position: 'absolute',
    color: '#121212',
    height: 24,
    width: 140,
    lineHeight: 24,
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
  },
  text2: {
    top: 9,
    left: 0,
    position: 'absolute',
    color: '#121212',
    height: 60,
    width: 29,
    lineHeight: 59,
    fontSize: 20,
    fontFamily: 'Poppins-SemiBold',
  },
  text: {
    top: 8,
    left: 86,
    position: 'absolute',
    color: '#121212',
    height: 60,
    width: 29,
    fontSize: 20,
    lineHeight: 59,
    fontFamily: 'Poppins-SemiBold',
  },
  Button: {
    marginTop: 5,
    height: 22,
    width: 177,
    position: 'absolute',
    backgroundColor: 'rgba(105, 89, 222, 1)',
    left: 0,
    top: 55,
    borderRadius: 20,
  },
  NameContainer: {
    top: 0,
    left: 0,
    width: 180,
    height: 72,
    position: 'absolute',
  },
  amis: {
    top: 33,
    left: 32,
    position: 'absolute',
    color: '#121212',
    height: 15,
    width: 25,
    fontSize: 10,
    lineHeight: 15,
    fontFamily: 'Poppins-Light',
  },
  groups: {
    top: 33,
    left: 120,
    position: 'absolute',
    color: '#121212',
    height: 17,
    width: 43,
    fontSize: 10,
    lineHeight: 15,
    fontFamily: 'Poppins-Light',
  },
  TextContainer: {
    width: 180,
    height: 72,
    marginLeft: 27,
  },
  Button1: {
    height: 22,
    width: 32,
    marginLeft: 7,
    marginTop: 60,
    backgroundColor: 'rgba(53, 47, 132, 1)',
    borderRadius: 10,
  },
  imageRow: {
    height: 76,
    flexDirection: 'row',
    flex: 1,
    marginRight: 19,
    marginTop: 1,
  },
  Container: {
    backgroundColor: 'white',
    flex: 0.8,
    marginTop: 30,
  },
  tabsContainer: {
    flexDirection: 'row',
    alignContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'white',
    justifyContent: 'center',
  },
  button: {
    backgroundColor: 'rgba(105, 89, 222, 1)',
    borderRadius: 5,
    width: 177,
    height: 22,
    paddingVertical: 3,
    paddingHorizontal: 10,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignContent: 'center',
    position: 'relative',
  },
  buttonText: {
    color: '#fff',
    fontSize: 10,
    fontFamily: 'Poppins-Medium',
    position: 'absolute',
    left: 51,
    top: 3,
    textAlign: 'center',
  },
  Icon: { position: 'absolute', left: 23, top: 3, color: 'white' },
  DoubleButtonContainer: {
    marginTop: 5,
    flexDirection: 'row',
    width: 178,
    height: 22,
    justifyContent: 'flex-start',
    alignContent: 'flex-start',
    position: 'relative',
    left: 0,
    top: 55,
  },
  DoubleButton1: {
    width: 89,
    height: 22,
    position: 'absolute',
    left: 0,
    borderTopLeftRadius: 20,
    borderBottomLeftRadius: 20,
  },
  DoubleButton2: {
    width: 89,
    height: 22,
    backgroundColor: 'rgba(242, 242, 242, 1)',
    position: 'absolute',
    left: 89,
    borderTopRightRadius: 20,
    borderBottomRightRadius: 20,
  },
});
