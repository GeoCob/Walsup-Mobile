import React, { useEffect, useState } from 'react';
import { View, Text, Image, TouchableOpacity, ImageBackground } from 'react-native';
import AppIntroSlider from 'react-native-app-intro-slider';
import styles from './styles';
import { Dimensions } from 'react-native';

//Contenu des slides
const slides = [
  {
    key: 1,
    // title: 'Title 1',
    title: 'Pouvez acheter vos produits uniquement en ligne avec un paiement 100% sécurisé.',
    image: require('../../../assets/mascotte-QSN1.png'),
    backgroundColor: '#ffffff',
  },
  {
    key: 2,
    title: 'Les meilleures offres, les plus belles marques:',
    text: "Découvrez des produits de grandes marque . Profiter d'une promotion en groupe d'utilisateur WALSUP sur produits/services en particulier. Cette promotion est accesible à partir de la création d'un groupe membre.",
    image: require('../../../assets/slider2.png'),
    backgroundColor: '#ffffff',
  },
  {
    key: 3,
    title: 'La qualité :',
    text: "Nous veillons à ce que notre aplication s'inspirent de vos envies que votre navigation soit fluide et que notre interface soint claire. \n Pour gagner : Invitez vos proches à s'inscrire et à rejoindre la famille WALSUP. Faites-leur profiter aussi des meilleures offres.",
    title2: 'Pour Gagner :',
    text2:
      'Invitez vos proches à s’inscrire et à rejoindre\nla famille WALSUP.Faites-leur profiter aussi\ndes meilleures offres.',
    image: require('../../../assets/slider3.png'),
    backgroundColor: '#ffffff',
  },
];

const WhoWeAreSlider = ({ navigation }) => {
  const [showRealApp, setShowRealApp] = useState(false);
  const screenWidth = Dimensions.get('window').width;
  const screenHeight = Dimensions.get('window').height;

  //si showRealApp true on navigue vers Authentification
  useEffect(() => {
    showRealApp && navigation.navigate('Authentification');
  }, [showRealApp]);

  //Button terminé
  const CustomDoneButton = ({ onPress }) => {
    return (
      <TouchableOpacity onPress={onPress} style={{ backgroundColor: '#6959DE', padding: 10, borderRadius: 5 }}>
        <Text style={{ color: 'white', textAlign: 'center', fontFamily: 'Poppins-Bold', fontSize: 15 }}>Terminé</Text>
      </TouchableOpacity>
    );
  };

  //fontion qui return slide selon l'ordre
  const _renderItem = ({ item }) => {
    return (
      <>
        {item.key === 3 ? (
          <View style={styles.slide}>
            <ImageBackground
              source={require('../../../assets/BackgroundWalsup.png')}
              resizeMode="cover"
              style={styles.slide}
            >
              <Image
                source={item.image}
                style={[
                  styles.mascotte,
                  { width: screenWidth * 0.8, height: screenHeight * 0.4, resizeMode: 'contain' },
                ]}
              />
              <Text style={styles.title}>{item.title}</Text>
              <Text style={styles.text}>{item.text}</Text>
              <Text style={styles.title}>{item.title2}</Text>
              <Text style={[styles.text, { marginBottom: 30 }]}>{item.text2}</Text>
            </ImageBackground>
          </View>
        ) : (
          <View style={styles.slide}>
            <ImageBackground
              source={require('../../../assets/BackgroundWalsup.png')}
              resizeMode="cover"
              style={styles.slide}
            >
              <Image source={item.image} style={styles.mascotte} />
              <Text style={styles.title}>{item.title}</Text>
              <Text style={styles.text}>{item.text}</Text>
            </ImageBackground>
          </View>
        )}
      </>
    );
  };

  //Function si terminé showrealapp true
  const _onDone = () => {
    setShowRealApp(true);
  };

  //Slider
  return (
    <AppIntroSlider
      activeDotStyle={{ backgroundColor: '#352F84', width: 35 }}
      showNextButton={false}
      renderItem={_renderItem}
      data={slides}
      bottomButton={true}
      renderDoneButton={() => <CustomDoneButton onPress={_onDone} />}
    />
  );
};

export default WhoWeAreSlider;
