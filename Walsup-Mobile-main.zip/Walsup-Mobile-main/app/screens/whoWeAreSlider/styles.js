import { StyleSheet } from 'react-native';
import { Dimensions } from 'react-native';

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;

export default StyleSheet.create({
  slide: {
    flex: 1,
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ffffff',
  },
  title: {
    fontSize: 24,
    fontFamily: 'Poppins-Bold',
    color: '#130F26',
    textAlign: 'center',
  },
  text: {
    fontSize: 15,
    fontFamily: 'Poppins-Bold',
    color: '#130F26',
    textAlign: 'center',
    margin: 10,
  },
  mascotte: {
    width: screenWidth * 0.5,
    height: screenHeight * 0.4,
    resizeMode: 'contain',
  },
  doneButton: {
    doneButtonTextStyle: {
      backgroundColor: '#0000FF',
      borderRadius: 5,
    },
  },
});
