(
    FilteredSuggestions?.length && searchPhrase && searchingStatus ? (
      FilteredSuggestions.map((item) => {
        if (tab === 'abonnements') {
          <React.Fragment key={item.id}>
            <InvitationCardPartner
              item={item}
              user={user}
              profileNavigation={handlePartnerProfileNavigation}
              subbed={false}
            />
            <Divider
              insertType="left"
              orientation="horizontal"
              width={1}
              style={{ width: '80%', marginHorizontal: 30 }}
              color="#F2F2F2"
            />
          </React.Fragment >;
        } else {
          <>
            <InvitationCard item={item} type="suggestion" />
            <Divider
              insertType="left"
              orientation="horizontal"
              width={1}
              style={{ width: '80%', marginHorizontal: 30 }}
              color="#F2F2F2"
            />
          </>;
        }
      })
    ) : !FilteredSuggestions?.length && searchPhrase && searchingStatus ? (
      <NoSocialData Description="Pas de résulta" />
    ) : (partnersSuggestions.map((item) => {
        if (tab === 'abonnements') {
          <>
            <InvitationCardPartner
              item={item}
              user={user}
              profileNavigation={handlePartnerProfileNavigation}
              subbed={false}
            />
            <Divider
              insertType="left"
              orientation="horizontal"
              width={1}
              style={{ width: '80%', marginHorizontal: 30 }}
              color="#F2F2F2"
            />
          </>;
        }
      })
    )
  )