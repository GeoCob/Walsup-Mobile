import { Text, StyleSheet, View, ScrollView } from 'react-native';
import React, { useState, useCallback } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import InvitationCard from '../../components/InvitationCard';
import InvitationCardPartner from '../../components/InvitationCardPartner';
import SearchBarComponent from '../../components/SearchBar';
import { getSuggestionPartners } from '../../store/social/socialThunk';
import { useSelector, useDispatch } from 'react-redux';
import NoSocialData from '../../components/noSocialData';
import GroupeInvitationCard from '../../components/GroupeInvitationCard';

//Composant de la page de suggestion
const Suggestions = ({ route, navigation }) => {
  //appel au title et tab depuis le route params ( tab = abonnements (partenaires)/groupes_suggs(groupes)/amis(utilisateurs))
  const { title, tab } = route.params;
  //Declaration d'une variable dans le state initialisé par false pour la bar de recherche
  const [clicked, setClicked] = useState(false);
  //Declaration d'une variable dans le state initialisé par string vide pour la phrase de recherche
  const [searchPhrase, setSearchPhrase] = useState('');
  //Declaration d'une variable dans le state initialisé par array vide pour la résultat de recherche
  const [searchResult, setSearchResult] = useState([]);
  //Declaration d'une variable dans le state intitialisé par false pour l'état de recherche
  const [searchingStatus, setSearchStatus] = useState(false);
  const [FilteredSuggestions, setFilteredSuggestions] = useState(null);
  //Appel à l'utilisateur depuis le store d'authentification
  const { user } = useSelector((store) => store.authentification);
  //Appel aux : Loader des suggestions de partenaire, de groupe et d'utilisateurs (non amis) (utilisés selon le tab)
  const { partnersSubsLoader, partnersSuggestionLoader, partnersSuggestions, UnfollowedUsers, UserGroupsSuggestions } =
    useSelector((store) => store.social);
  const dispatch = useDispatch();

  //useFocusEffect
  useFocusEffect(
    useCallback(() => {
      //si la tab est abonnements appel aux reducer de fetch de suggestions des partenaires en y passant les données
      if (tab === 'abonnements') {
        dispatch(getSuggestionPartners({ user_uid: user.uid, suggestionType: true }));
        // console.log("test abonement object ====> ", partnersSuggestions);
      }
    }, [tab, partnersSuggestionLoader, partnersSubsLoader])
  );
  //Fonction de Recherche (filtrage de données selon la tab (amis/abonnements/groupes))
  const SearchHandle = () => {
    if (tab === 'amis') {
      const newState = UnfollowedUsers?.filter((search) => {
        if (search?.first_name && search?.last_name) {
          const fullName = search?.first_name + search?.last_name;
          return fullName.toLowerCase().includes(searchPhrase.toLowerCase());
        }
        // if(search?.first_name)
        //   return search?.first_name.toLowerCase().includes(searchPhrase.toLowerCase())
        // if(search?.last_name)
        //   return search?.last_name.toLowerCase().includes(searchPhrase.toLowerCase())
      });
      setSearchResult(newState);
      setSearchStatus(true);
    }
    if (tab === 'groupes_Suggs') {
      const newState = UserGroupsSuggestions?.filter((search) => {
        if (search?.name) return search?.name.toLowerCase().includes(searchPhrase.toLowerCase());
      });
      setSearchResult(newState);
      setSearchStatus(true);
    }
    if (tab === 'abonnements') {
      const newState = partnersSuggestions.filter((search) => {
        if (search?.name) return search?.name.toLowerCase().includes(searchPhrase.toLowerCase());
      });
      setSearchResult(newState);
      setSearchStatus(true);
    }
  };

  //Fonction de reset de résultat et l'état de la barre de recherche
  const ressetSearch = () => {
    setSearchResult([]);
    setSearchPhrase('');
    setSearchStatus(false);
  };

  //navigation vers la page de profile de partenaire
  const handlePartnerProfileNavigation = (data) => {
    console.log('triger Navigations===>', data);
    navigation.navigate('PartnerProfile', {
      connectedUserId: user.uid,
      partnerId: data.id,
      partnerName: data.name,
      partnerImageUrl: data.imageurl,
      partnerLink: 'https://www.youtube.com/',
      partnerSubbed: data.subbed,
    });
  };

  //Retour de composant selon la tab (amis/groupes/abonnements)
  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      <SearchBarComponent
        clicked={clicked}
        setClicked={setClicked}
        searchPhrase={searchPhrase}
        setSearchPhrase={setSearchPhrase}
        search={SearchHandle}
        modifierSearchType={tab}
        setSearchStatus={setSearchStatus}
        ressetSearch={ressetSearch}
      />
      <Text style={styles.ListeName}>{title}</Text>
      {tab === 'amis' ? (
        <ScrollView>
          {searchResult?.length && searchPhrase && searchingStatus ? (
            searchResult?.map((item, index) => (
              <React.Fragment key={index}>
                <InvitationCard item={item} type="suggestion" keys={index} />
              </React.Fragment>
            ))
          ) : !searchResult?.length && searchPhrase && searchingStatus ? (
            <NoSocialData Description="Auccun résulta pour ce nom" />
          ) : UnfollowedUsers?.length ? (
            UnfollowedUsers?.map((item, index) => {
              return (
                <React.Fragment key={index}>
                  <InvitationCard item={item} type="suggestion" keys={index} />
                </React.Fragment>
              );
            })
          ) : (
            <NoSocialData Description="OOps un petit probléme" />
          )}
        </ScrollView>
      ) : tab === 'groupes_Suggs' ? (
        <ScrollView>
          {searchResult?.length && searchPhrase && searchingStatus ? (
            searchResult?.map((item, index) => (
              <React.Fragment key={index}>
                <GroupeInvitationCard item={item} type="suggestion" keys={index} />
              </React.Fragment>
            ))
          ) : !searchResult?.length && searchPhrase && searchingStatus ? (
            <NoSocialData Description="Auccun résulta trouver" />
          ) : UserGroupsSuggestions?.length ? (
            UserGroupsSuggestions.map((item, index) => {
              return (
                <React.Fragment key={index}>
                  <GroupeInvitationCard item={item} type="suggestion" keys={index} />
                </React.Fragment>
              );
            })
          ) : (
            <NoSocialData Description="Auccun résulta trouver" />
          )}
        </ScrollView>
      ) : tab === 'abonnements' ? (
        <ScrollView>
          {searchResult?.length && searchPhrase && searchingStatus ? (
            searchResult?.map((item, index) => (
              <React.Fragment key={index}>
                <InvitationCardPartner
                  item={item}
                  user={user}
                  profileNavigation={handlePartnerProfileNavigation}
                  subbed={false}
                />
              </React.Fragment>
            ))
          ) : !searchResult?.length && searchPhrase && searchingStatus ? (
            <NoSocialData Description="Auccun résulta trouver" />
          ) : partnersSuggestions?.length ? (
            partnersSuggestions?.map((item, index) => (
              <React.Fragment key={index}>
                <InvitationCardPartner
                  item={item}
                  user={user}
                  profileNavigation={handlePartnerProfileNavigation}
                  subbed={false}
                />
              </React.Fragment>
            ))
          ) : (
            <NoSocialData Description="Auccun résulta trouver" />
          )}
        </ScrollView>
      ) : null}
    </View>
  );
};
export default Suggestions;

const styles = StyleSheet.create({
  ListeName: {
    color: '#333333',
    marginLeft: 20,
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    lineHeight: 20,
  },
});
