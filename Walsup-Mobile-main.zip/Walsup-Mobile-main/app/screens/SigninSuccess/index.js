import React, { useRef, useEffect } from 'react';
import { View, Image, TouchableOpacity, Text, StyleSheet, Easing } from 'react-native';
import Animated, { useAnimatedStyle } from 'react-native-reanimated';
import styles from './styles';
import { useNavigation } from '@react-navigation/native';
import BottomTabNavigator from '../../navigation/BottomTabNavigator';
import { useDispatch, useSelector } from 'react-redux';
import { setSignInCompleted } from '../../store/authentication/authenticationSlice';

const SigninSuccess = ({ navigation, route }) => {
  //Declaration de variable d'animation selon l'axe des Y
  const translateY = useRef(new Animated.Value(0)).current;
  //Appel à la variable comingFrom de route params pour la verification d'utilisateur s'il vient de la page d'inscription ou connexion
  const { comingFrom } = route.params;

  const dispatch = useDispatch();
  //Appel à l'utilisateur et le loader de store d'authentification
  const { user, loading, signInCompleted } = useSelector((store) => store.authentification);

  //UseEffect d'animation d'image
  useEffect(() => {
    Animated.timing(translateY, {
      toValue: -50,
      duration: 1000,
      easing: Easing.linear,
      useNativeDriver: true,
    }).start(({ finished }) => {
      if (finished) {
        Animated.timing(translateY, {
          toValue: 0,
          duration: 1000,
          easing: Easing.linear,
          useNativeDriver: true,
        }).start(({ finished }) => {
          if (finished) {
            Animated.timing(translateY, {
              toValue: -50,
              duration: 1000,
              easing: Easing.linear,
              useNativeDriver: true,
            }).start();
          }
        });
      }
    });
  }, []);

  //UseEffect de verification d'utilisateur et navigation
  useEffect(() => {
    if (!loading && user?.uid) {
      const timer = setTimeout(async () => {
        //console.log('Navigating to the next screen');
        dispatch(setSignInCompleted());
        navigation.navigate('Accueil');
      }, 2000);
      return () => clearTimeout(timer);
    } else if (!loading && !user?.uid) {
      const timer = setTimeout(async () => {
        dispatch(setSignInCompleted());
        //console.log(comingFrom);
        navigation.navigate(comingFrom);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [loading, user, navigation]);

  const imageStyle = {
    transform: [
      {
        translateY: translateY,
      },
    ],
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>{'Félicitations !'}</Text>
      <TouchableOpacity>
        <Animated.Image source={require('../../../assets/félicitation.png')} style={[styles.image, imageStyle]} />
      </TouchableOpacity>
    </View>
  );
};

export default SigninSuccess;
