import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, Image } from 'react-native';
import { getDatabase, ref, onValue, push, set } from 'firebase/database';
import SendButtonChat from '../../../assets/Icons/components/SendButtonChat';
import { useSelector } from 'react-redux';

const ChatScreen = ({ route }) => {
  const { user } = useSelector((store) => store.authentification);

  const { chatId } = route.params;
  // const user1Id = 'RGhtSVUumVa0FnOT0ccDMntHwfg2';
  // const user2Id = 'SyodUJ5FhJQbAe26zu4nKfLTad03';
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    const db = getDatabase();
    const chatRef = ref(db, `chatRooms/${chatId}/messages`);

    // Set up Realtime Database listener to listen for changes to the chat messages
    const unsubscribe = onValue(chatRef, (snapshot) => {
      if (snapshot.exists()) {
        const messageObjects = snapshot.val();
        const messageList = Object.keys(messageObjects).map((key) => ({
          id: key,
          message: messageObjects[key].message,
          senderId: messageObjects[key].senderId,
          timestamp: messageObjects[key].timestamp,
        }));
        setMessages(messageList);
      }
    });

    return () => {
      // Unsubscribe from Realtime Database listener when component unmounts
      unsubscribe();
      setMessages([]);
    };
  }, [chatId]);

  const sendMessage = () => {
    if (!message) return;

    const db = getDatabase();
    const messageRef = ref(db, `chatRooms/${chatId}/messages`);
    const newMessageRef = push(messageRef);
    set(newMessageRef, {
      message: message,
      senderId: user.uid,
      timestamp: Date.now(),
    });

    // Clear the message input field
    setMessage('');
  };

  const renderMessage = ({ item }) => {
    const isCurrentUser = item.senderId === user.uid;
    const messageContainerStyle = isCurrentUser ? styles.rightMessageContainer : styles.leftMessageContainer;
    const messageTextStyle = isCurrentUser ? styles.rightMessageText : styles.leftMessageText;

    return (
      <View style={messageContainerStyle}>
        {!isCurrentUser && <Image source={require('../../../assets/fakePorfile/prof_01.png')} style={styles.avatar} />}
        <Text style={messageTextStyle}>{item.message}</Text>
        {/* <Text style={styles.messageTimestamp}>{new Date(item.timestamp).toLocaleString()}</Text> */}
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.separator} />
      <FlatList
        data={messages}
        renderItem={renderMessage}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.messagesContainer}
      />
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          value={message}
          onChangeText={(text) => setMessage(text)}
          placeholder="Type a message"
        />
        <TouchableOpacity onPress={sendMessage}>
          {/* <Text style={styles.sendButtonText}>Send</Text> */}
          <SendButtonChat />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  separator: {
    height: 1,
    width: '100%',
    backgroundColor: '#e5e5e5',
  },
  messagesContainer: {
    flexGrow: 1,
    justifyContent: 'flex-end',
  },
  leftMessageContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    marginVertical: 4,
    marginHorizontal: 12,
  },
  leftMessageText: {
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 12,
    fontSize: 16,
    color: '#000',
    maxWidth: '80%',
    marginLeft: 8,
  },
  rightMessageContainer: {
    flexDirection: 'row-reverse',
    alignItems: 'flex-end',
    marginVertical: 4,
    marginHorizontal: 12,
  },
  rightMessageText: {
    backgroundColor: '#0084ff',
    borderRadius: 10,
    paddingVertical: 8,
    paddingHorizontal: 12,
    fontSize: 16,
    color: '#fff',
    maxWidth: '80%',
    marginRight: 8,
  },
  avatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    marginRight: 8,
  },
  messageTimestamp: {
    fontSize: 12,
    color: '#9b9b9b',
    marginTop: 4,
    marginLeft: 8,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  input: {
    flex: 1,
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
    paddingHorizontal: 16,
    paddingVertical: 10,
    fontSize: 16,
    color: '#000',
    marginRight: 8,
  },
  sendButton: {
    backgroundColor: '#0084ff',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  sendButtonText: {
    fontSize: 16,
    color: '#fff',
  },
});

export default ChatScreen;
