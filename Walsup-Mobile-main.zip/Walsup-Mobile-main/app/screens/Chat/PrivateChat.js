import React, { useState, useEffect, useCallback, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, Image, ActivityIndicator } from 'react-native';
import {
  child,
  get,
  getDatabase,
  onValue,
  ref,
  push,
  serverTimestamp,
  set,
  off,
  update,
  runTransaction,
  increment,
  remove,
} from 'firebase/database';
import SendButtonChat from '../../../assets/Icons/components/SendButtonChat';
import { useFocusEffect } from '@react-navigation/native';
import { useSelector, useDispatch } from 'react-redux';
import { upadatePrivateChatRecieverData } from '../../store/social/privateChatSlice';
// css theme
import styles from './styles';
import { BaseColor } from '../../../config/theme';

//Screen de discussion individuelle (dans la discussion)
const PrivateChat = (props) => {
  //Appel de l'utilisateur depuis le store d'authentification
  const { user } = useSelector((store) => store.authentification);
  //appel des amis et loader d'amis de store social
  const { followedUsers, followedUsersLoader } = useSelector((store) => store.social);
  const dispatch = useDispatch();
  //fetch d'id de conversation , d'utilisateur (ami) et leurs données
  const { conversationId, recieverId, recieverData, navigation } = props;
  //Declaration de variables dans le state pour le message à envoyé , les messages de la conversation , button d'envois et notifications
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const [active, setAvtive] = useState(true);
  const [notification, setNotification] = useState(0);

  // flatlist scrolling
  const flatlistRef = useRef(null);

  //UseFocusEffect
  useFocusEffect(
    useCallback(() => {
      //Reset de conversation
      setMessages([]);
      setMessage('');
      dispatch(upadatePrivateChatRecieverData(recieverData));
    }, [conversationId, followedUsers?.length])
  );
  //UseEffect de fetch des messages
  useFocusEffect(
    useCallback(() => {
      const db = getDatabase();
      const dbRef = ref(db, `PrivateMessages/${conversationId}`);
      const onValueCallback = (snapshot) => {
        const value = snapshot.val();
        if (value) {
          const newData = Object.entries(value).map(([id, value]) => ({ id, ...value }));
          setMessages(newData);
        } else {
          setMessages('');
        }
      };
      onValue(dbRef, onValueCallback);
      return () => off(dbRef, onValueCallback);
    }, [messages?.length, followedUsers?.length])
  );
  //UseFocusEffect de mise à jours des notifications
  useFocusEffect(
    useCallback(() => {
      const db = getDatabase();
      const dbRef = ref(db, `privateChatConversation/${user.uid}/${conversationId}`);
      const onValueCallback = (snapshot) => {
        const value = snapshot.val();
        if (value) {
          setNotification((prev) => value.badges);
        }
        if (!value) {
          navigation.navigate('Chat');
        }
      };
      onValue(dbRef, onValueCallback);
      return () => off(dbRef, onValueCallback);
    }, [conversationId, followedUsers?.length])
  );
  //UseFocusEffect de reset des notifications
  useFocusEffect(
    useCallback(() => {
      const db = getDatabase();
      const dbRef = ref(db);
      const resetNotifications = async () => {
        try {
          const result = await get(child(dbRef, `privateChatConversation/${recieverId}/${conversationId}`));
          if (!result.exists()) {
            console.log('triger remove chat !!!!!');
            // const resultRemove = await remove(ref(db, `privateChatConversation/${user.uid}/${conversationId}`));
            // if(resultRemove.exists()) console.log(resultRemove.val());
            navigation.navigate('Chat');
          }
          if (notification > 0) {
            // console.log(checkPath.val());
            console.log('RESSET BADGES TO ==> 0');
            await update(ref(db, `privateChatConversation/${user.uid}/${conversationId}`), {
              badges: 0,
            });
          }
        } catch (error) {
          console.log(error);
        }
      };
      resetNotifications();
      return () => resetNotifications();
    }, [notification])
  );

  //Fonction d'envois message
  const handleMessages = async () => {
    const db = getDatabase();
    const dbRef = ref(db, `PrivateMessages/${conversationId}`);
    const dbRefUpdates = ref(db);
    setAvtive(false);
    if (message) {
      setMessage('');
      try {
        // push the new message in the private conversation privateMessages collection
        // and create a new document under specific conversation collection
        await push(dbRef, {
          messageCreationdate: serverTimestamp(),
          messageText: message,
          senderId: user.uid,
        });
        // refactor with atomic updates for better writing speed to the db
        const updates = {};
        updates['privateChatConversation/' + recieverId + '/' + conversationId + '/badges'] = increment(1);
        updates['privateChatConversation/' + recieverId + '/' + conversationId + '/lastMessage'] = message;
        updates['privateChatConversation/' + recieverId + '/' + conversationId + '/lastMessageCreationDate'] =
          serverTimestamp();
        updates['privateChatConversation/' + user.uid + '/' + conversationId + '/lastMessage'] = message;
        updates['privateChatConversation/' + user.uid + '/' + conversationId + '/lastMessageCreationDate'] =
          serverTimestamp();
        update(dbRefUpdates, updates);
      } catch (error) {
        console.log(error);
      }
    }
    setAvtive(true);
  };

  // time calculation for messages specifics

  const calculateTime = (timeSet) => {
    const currentTimestamp = Date.now();
    const lastmessageTime = timeSet;
    const difference = currentTimestamp - parseInt(lastmessageTime, 10);
    const seconds = Math.floor(difference / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    let formattedTime;
    if (minutes < 59) {
      const date = new Date(parseInt(lastmessageTime, 10));
      formattedTime = `${date.getHours()}:${('0' + date.getMinutes()).slice(-2)}`;
    } else if (hours < 24) {
      const date = new Date(parseInt(lastmessageTime, 10));
      formattedTime = `${date.getHours()}:${('0' + date.getMinutes()).slice(-2)}`;
    } else if (hours < 48) {
      const date = new Date(parseInt(lastmessageTime, 10));
      formattedTime = `${date.getHours()}:${('0' + date.getMinutes()).slice(-2)} hier`;
    } else {
      const date = new Date(parseInt(lastmessageTime, 10));
      formattedTime = `${date.getDate()} ${date.toLocaleString('fr-FR', { month: 'short' })} ${date.getHours()}:${(
        '0' + date.getMinutes()
      ).slice(-2)}`;
    }
    return formattedTime;
  };

  const renderMessage = ({ item }) => {
    // console.log(item);
    const isCurrentUser = item.senderId === user.uid;
    const messageContainerStyle = isCurrentUser ? styles.rightMessageContainer : styles.leftMessageContainer;
    const messageTextStyle = isCurrentUser ? styles.rightMessageText : styles.leftMessageText;
    const timerStyle = isCurrentUser ? styles.chat__textOn : styles.chat__text;
    const imageUrl = recieverData?.profile_image;

    return (
      <View style={messageContainerStyle}>
        {!isCurrentUser && (
          <Image
            source={
              imageUrl
                ? { uri: imageUrl ? imageUrl : require('../../../assets/fakePorfile/prof_01.png') }
                : require('../../../assets/fakePorfile/prof_01.png')
            }
            style={styles.avatar}
          />
        )}
        <Text style={messageTextStyle}>
          {item.messageText}
          <Text style={timerStyle}>{`\n${calculateTime(item.messageCreationdate)}`}</Text>
        </Text>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.separator} />
      {!followedUsersLoader && followedUsers?.length ? (
        <>
          <FlatList
            ref={flatlistRef}
            data={messages}
            renderItem={renderMessage}
            keyExtractor={(item) => item.id}
            contentContainerStyle={styles.messagesContainer}
            onContentSizeChange={() => flatlistRef.current.scrollToEnd({ animated: true })}
          />
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              value={message}
              onChangeText={(text) => setMessage(text)}
              onSubmitEditing={() => (active ? handleMessages() : null)}
              returnKeyType="send"
              placeholder="Type a message"
            />
            <TouchableOpacity onPress={() => (active ? handleMessages() : null)}>
              {/* <Text style={styles.sendButtonText}>Send</Text> */}
              <SendButtonChat active={active} />
            </TouchableOpacity>
          </View>
        </>
      ) : (
        <ActivityIndicator color={BaseColor.primaryLight} size={2} />
      )}
    </View>
  );
};

export default PrivateChat;
