import React, { useCallback, useEffect, useState, useRef } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet, Image, ActivityIndicator } from 'react-native';
import {
  child,
  get,
  getDatabase,
  onValue,
  ref,
  push,
  serverTimestamp,
  set,
  off,
  update,
  runTransaction,
  increment,
} from 'firebase/database';
import { upadatePrivateChatRecieverData } from '../../store/social/privateChatSlice';
import { useFocusEffect } from '@react-navigation/native';
import { useDispatch, useSelector } from 'react-redux';
import SendButtonChat from '../../../assets/Icons/components/SendButtonChat';
import { getGroupMembers } from '../../store/social/socialThunk';
// css
import styles from './styles';
import { BaseColor } from '../../../config/theme';

//Composant de chat de groupe ( dans la discussion)
const GroupeChat = (props) => {
  //appel à l'utilisateur de  store d'authentification
  const { user } = useSelector((store) => store.authentification);
  //fetch des amis et loader d'amis de store social
  const { followedUsers, followedUsersLoader } = useSelector((store) => store.social);
  //fetch d'id de la conversation, données de groupe et données des membres
  const { conversationId, recieverData, GroupMembersData } = props;
  const dispatch = useDispatch();
  //Declaration des variable dans le state pour le message à envoyer et les messages dans la discussions
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);

  //Declaration de variable pour les notifications
  const [active, setAvtive] = useState(true);
  const [notification, setNotification] = useState(0);
  // flatlist scrolling
  const flatlistRef = useRef(null);
  //UseFocusEffect pour la reintialisation des données
  useFocusEffect(
    useCallback(() => {
      setMessages([]);
      setMessage('');
      dispatch(upadatePrivateChatRecieverData(recieverData));
      // dispatch(getGroupMembers(GroupMembersData));
      console.log('======================>', GroupMembersData);
    }, [recieverData])
  );
  //UseFocusEffect
  useFocusEffect(
    //Fonction de fetch des messages
    useCallback(() => {
      //accées à la base de données
      const db = getDatabase();
      //reference à la base
      const dbRef = ref(db, `PrivateMessages/${conversationId}`);
      //fetch des messages
      const onValueCallback = (snapshot) => {
        const value = snapshot.val();
        if (value) {
          const newData = Object.entries(value).map(([id, value]) => ({ id, ...value }));
          //mise à jour des messages
          setMessages(newData);
        }
      };
      //pour chaque mise à jour de données dans la base les données local se mettent à jour
      onValue(dbRef, onValueCallback);
      return () => off(dbRef, onValueCallback);
    }, [conversationId])
  );
  //UseFocusEffect pour les notifications
  useFocusEffect(
    useCallback(() => {
      //Accées à la base de données
      const db = getDatabase();
      //reference à la base
      const dbRef = ref(db, `privateChatConversation/${user.uid}/${conversationId}`);
      const onValueCallback = (snapshot) => {
        const value = snapshot.val();
        if (value) {
          //mise à jour des notifcations
          setNotification((prev) => value.badges);
        }
      };
      //à chaque fois il y a un changement à la base de données les données local se mettent à jour
      onValue(dbRef, onValueCallback);
      return () => off(dbRef, onValueCallback);
    }, [conversationId, followedUsers?.length])
  );
  //UseFocusEffect de mise à jours des badges
  useFocusEffect(
    useCallback(() => {
      //Accées à la base de données
      const db = getDatabase();
      //reset des badges lorsque l'utilisateur entre dans une discussion
      const resetNotifications = async () => {
        try {
          await update(ref(db, `privateChatConversation/${user.uid}/${conversationId}`), {
            badges: 0,
          });
        } catch (error) {
          console.log(error);
        }
      };

      resetNotifications();
      return () => resetNotifications();
    }, [messages?.length, notification])
  );

  //Fonction de calcul de temps pour le calcul de temps de dernier message envoyé ou reçu
  const calculateTime = (timeSet) => {
    const currentTimestamp = Date.now();
    const lastmessageTime = timeSet;
    const difference = currentTimestamp - parseInt(lastmessageTime, 10);
    const seconds = Math.floor(difference / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    let formattedTime;
    if (minutes < 59) {
      const date = new Date(parseInt(lastmessageTime, 10));
      formattedTime = `${date.getHours()}:${('0' + date.getMinutes()).slice(-2)}`;
    } else if (hours < 24) {
      const date = new Date(parseInt(lastmessageTime, 10));
      formattedTime = `${date.getHours()}:${('0' + date.getMinutes()).slice(-2)}`;
    } else if (hours < 48) {
      const date = new Date(parseInt(lastmessageTime, 10));
      formattedTime = `${date.getHours()}:${('0' + date.getMinutes()).slice(-2)} hier`;
    } else {
      const date = new Date(parseInt(lastmessageTime, 10));
      formattedTime = `${date.getDate()} ${date.toLocaleString('fr-FR', { month: 'short' })} ${date.getHours()}:${(
        '0' + date.getMinutes()
      ).slice(-2)}`;
    }
    return formattedTime;
  };

  //Fonction d'envois de message
  const handleMessages = async () => {
    //Accées à la base de données
    const db = getDatabase();
    //reference à la base de données
    const bdRefUp = ref(getDatabase());
    const dbRef = ref(db, `PrivateMessages/${conversationId}`);
    setAvtive(false);
    //s'il ya un message
    if (message) {
      const BuildMembersUpdates = Object.keys(GroupMembersData);
      BuildMembersUpdates.push(user.uid);
      let updates = {};
      //pour chaque memebre de groupe mise à jour de la conversation , notification et dernier message
      BuildMembersUpdates.forEach((item) => {
        updates['/privateChatConversation/' + item + '/' + conversationId + '/lastMessageCreationDate'] =
          serverTimestamp();
        updates['/privateChatConversation/' + item + '/' + conversationId + '/lastMessage'] = message;
        if (item !== user.uid)
          updates['/privateChatConversation/' + item + '/' + conversationId + '/badges'] = increment(1);
      });
      //reset de message à envoyer
      setMessage('');
      try {
        //mise à jour des messages
        await push(dbRef, {
          messageCreationdate: serverTimestamp(),
          messageText: message,
          senderId: user.uid,
        });
        await update(bdRefUp, updates);
      } catch (error) {
        console.log(error);
      }
      setAvtive(true);
    }
  };
  //Fonction/Composant de render de chaque message avec l'image d'utilisateur et le temps d'envois de message
  const renderMessage = ({ item }) => {
    const isCurrentUser = item.senderId === user.uid;
    const messageContainerStyle = isCurrentUser ? styles.rightMessageContainer : styles.leftMessageContainer;
    const messageTextStyle = isCurrentUser ? styles.rightMessageText : styles.leftMessageText;
    const timerStyle = isCurrentUser ? styles.chat__textOn : styles.chat__text;
    let imageUrl = null;
    if (GroupMembersData[item.senderId]) imageUrl = GroupMembersData[item.senderId].profile_image;

    return (
      <View style={messageContainerStyle}>
        {!isCurrentUser && (
          <Image source={imageUrl ? { uri: imageUrl } : require('../../../assets/profile.png')} style={styles.avatar} />
        )}
        <Text style={messageTextStyle}>
          {item.messageText}
          <Text style={timerStyle}>{`\n${calculateTime(item.messageCreationdate)}`}</Text>
        </Text>
      </View>
    );
  };
  return (
    <View style={styles.container}>
      <View style={styles.separator} />
      {!followedUsersLoader && followedUsers?.length && GroupMembersData ? (
        <>
          {messages ? (
            <FlatList
              ref={flatlistRef}
              data={messages}
              renderItem={renderMessage}
              keyExtractor={(item) => item.id}
              contentContainerStyle={styles.messagesContainer}
              onContentSizeChange={() => flatlistRef.current.scrollToEnd({ animated: true })}
            />
          ) : null}
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              value={message}
              onChangeText={(text) => setMessage(text)}
              onSubmitEditing={() => (active ? handleMessages() : null)}
              returnKeyType="send"
              placeholder="Type a message"
            />
            <TouchableOpacity onPress={() => (active ? handleMessages() : null)}>
              {/* <Text style={styles.sendButtonText}>Send</Text> */}
              <SendButtonChat active={active} />
            </TouchableOpacity>
          </View>
        </>
      ) : (
        <ActivityIndicator color={BaseColor.primaryLight} size={2} />
      )}
    </View>
  );
};

export default GroupeChat;
