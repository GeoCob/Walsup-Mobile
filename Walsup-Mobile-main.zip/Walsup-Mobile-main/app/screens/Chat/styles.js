import { StyleSheet } from "react-native";
import { BaseColor } from "../../../config/theme";

export default StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#fff',
    },
    separator: {
      height: 1,
      width: '100%',
      backgroundColor: '#e5e5e5',
    },
    messagesContainer: {
      flexGrow: 1,
      justifyContent: 'flex-end',
    },
    leftMessageContainer: {
      flexDirection: 'row',
      alignItems: 'flex-end',
      marginVertical: 4,
      marginHorizontal: 12,
    },
    leftMessageText: {
      backgroundColor: '#f0f0f0',
      borderRadius: 10,
      paddingVertical: 8,
      paddingHorizontal: 12,
      fontSize: 16,
      color: '#000',
      maxWidth: '80%',
      marginLeft: 8,
    },
    rightMessageContainer: {
      flexDirection: 'row-reverse',
      alignItems: 'flex-end',
      marginVertical: 4,
      marginHorizontal: 12,
    },
    rightMessageText: {
      backgroundColor: '#0084ff',
      borderRadius: 10,
      paddingVertical: 8,
      paddingHorizontal: 12,
      fontSize: 16,
      color: '#fff',
      maxWidth: '80%',
      marginRight: 8,
    },
    avatar: {
      width: 36,
      height: 36,
      borderRadius: 18,
      marginRight: 8,
    },
    messageTimestamp: {
      fontSize: 12,
      color: '#9b9b9b',
      marginTop: 4,
      marginLeft: 8,
    },
    inputContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 12,
      paddingVertical: 8,
    },
    input: {
      flex: 1,
      backgroundColor: '#f0f0f0',
      borderRadius: 10,
      paddingHorizontal: 16,
      paddingVertical: 10,
      fontSize: 16,
      color: '#000',
      marginRight: 8,
    },
    sendButton: {
      backgroundColor: '#0084ff',
      borderRadius: 20,
      paddingHorizontal: 12,
      paddingVertical: 8,
    },
    sendButtonText: {
      fontSize: 16,
      color: '#fff',
    },
    chat__text:{
      fontSize: 10,
      color: BaseColor.greyMain,
      marginLeft: 50,
    },
    chat__textOn:{
      fontSize: 10,
      color: BaseColor.fadedGrey_02, 
      marginLeft: 50,
    }
  });