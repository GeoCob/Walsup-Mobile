import React, { useState, useEffect, useCallback, useRef } from 'react';

//
import PrivateChat from './PrivateChat';
import GroupeChat from './GroupeChat';

//Chat Screen
const ChatScreen = ({ route, navigation }) => {
  const { conversationId, recieverId, recieverData, type, GroupMembers } = route.params;

  useEffect(() => {
    console.log(GroupMembers);
    console.log('indexData chat disscution', conversationId, recieverId, recieverData, type);
  }, []);

  return (
    <>
      {type === 'default' ? (
        <PrivateChat
          conversationId={conversationId}
          recieverId={recieverId}
          recieverData={recieverData}
          navigation={navigation}
        />
      ) : (
        <GroupeChat conversationId={conversationId} recieverData={recieverData} GroupMembersData={GroupMembers} />
      )}
    </>
  );
};

export default ChatScreen;
