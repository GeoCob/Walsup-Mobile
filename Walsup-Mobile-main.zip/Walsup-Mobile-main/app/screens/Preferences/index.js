import React, { Component } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';
import MIcon from 'react-native-vector-icons/MaterialIcons';

//Composant de menu de Preferences (filters)
const Preferences = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => navigation.navigate('WorkInProgress')} style={styles.button}>
        <Text style={styles.ButtonName}>Avatar</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <MIcon name="keyboard-arrow-right" size={30} color={'black'} style={styles.Icon} />
        </View>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate('Interests')} style={styles.button}>
        <Text style={styles.ButtonName}>Centre d'intérêt</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <MIcon name="keyboard-arrow-right" size={30} color={'black'} style={styles.Icon} />
        </View>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.navigate('WorkInProgress')} style={styles.button}>
        <Text style={styles.ButtonName}>Préférence</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <MIcon name="keyboard-arrow-right" size={30} color={'black'} style={styles.Icon} />
        </View>
      </TouchableOpacity>
    </View>
  );
};

export default Preferences;

const styles = StyleSheet.create({
  container: {
    marginTop: 58,
    flex: 0.4,
    flexDirection: 'column',
    justifyContent: 'space-around',
  },
  button: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    width: 335,
    alignSelf: 'center',
    borderRadius: 10,
    height: 56,
    marginBottom: 16,
    justifyContent: 'space-between', // added
  },
  ButtonName: {
    fontSize: 17,
    fontFamily: 'Poppins-Medium',
    marginVertical: 14,
    marginLeft: 27,
    letterSpacing: 0.5,
    lineHeight: 25,
  },
  Icon: { marginRight: 29 },
});
