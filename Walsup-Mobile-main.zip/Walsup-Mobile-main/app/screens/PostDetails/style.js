import { StyleSheet } from 'react-native';
import { BaseColor, Fonts } from '../../../config/theme';

export default StyleSheet.create({
  mainCarrousel: {
    position: 'relative',
    width: '100%',
    height: 382,
    justifyContent: 'center',
    alignItems: 'center',
  },
  carrousel: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  //   icons details
  IconsContainer: {
    position: 'absolute',
    width: '95%',
    height: '86%',
    top: '3%',
    left: '3%',
    justifyContent: 'space-between',
    alignItems: 'stretch',
  },
  iconsFrame: {
    width: 42,
    height: 42,
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 4 },
  },
  socialsContainer: {
    width: '100%',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
  },
  iconMain: {
    width: 23,
    resizeMode: 'contain',
  },
  // partner styles section
  partnerTab: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 4,
    marginVertical: 6,
  },
  partnerLogo: {
    width: 48,
    height: 48,
    borderRadius: 100,
    borderColor: BaseColor.fadedGrey,
    borderWidth: 2,
  },
  // title section
  titleSectionContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 12,
    marginVertical: 24,
  },
  titleText: {
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
  },
  // description and specs section
  descriptionContaier: {
    width: '100%',
    paddingHorizontal: 12,
    justifyContent: 'center',
  },

  // commentairy section
  commentariesContainer: {
    widhth: '100%',
    paddingHorizontal: 12,
  },
});
