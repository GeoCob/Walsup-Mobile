import React, { useState, useEffect, useCallback } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { SafeAreaView, Text, View, Image, Pressable, TextInput, Linking, ActivityIndicator } from 'react-native';
//css and styles tools
import Swiper from 'react-native-swiper';
import styles from './style';
import { BaseColor, Fonts } from '../../../config/theme';
import EntypoIcons from 'react-native-vector-icons/Entypo';
import Octicons from 'react-native-vector-icons/Octicons';
import Feather from 'react-native-vector-icons/Feather';
import AntDesign from 'react-native-vector-icons/AntDesign';
import { Mascotts, Logo } from '../../../config/Images';
import { FlatList, ScrollView } from 'react-native-gesture-handler';
import { serverSection } from '../../../config/servConf';
//redux
import { useSelector, useDispatch } from 'react-redux';
import {
  likeAdvertisingOffer,
  unLikeAdvertisingOffer,
  createAdvertisingOfferComment,
  getAdvertisingOfferById,
  getAllAdvertisingComments,
} from '../../store/postNews/postNewsThunk';
import { emptyPostByIB, emptyPostComment } from '../../store/postNews/postNewsSlice';

//Composant de details de l'offre publicitaire
const PostDetails = ({ route, navigation }) => {
  //Appel de données d'utilisateur connecté , data de l'offre et les données de partenaire correspondant de route params
  const { userID, userImage, userfirstName, userLastName, data, partnerName, partnerImge } = route.params;
  //Declaration de variable dans le state pour le toggle d'affichage de tous les commentaire
  const [showAllComments, setShowAllComments] = useState(false);
  //Fonction qui permet d'ouvrir l'url de l'offre
  const handlelink = () => {
    Linking.openURL(`${data.link}`);
  };

  //like logics
  //Declaration de variable dans le state de l'état de l'utilisateur par rapport au j'aime de l'offre
  const [like, setLike] = useState(data.user_has_liked);
  //Declaration de variable dans le state de nombre de j'aime de l'offre
  const [likeCount, setLikeCount] = useState(data.likes);
  //Declaration de variable dans le state de product pour le set de tous les données de l'offre
  const [product, setProduct] = useState({ ...data });
  //Appel de loader de j'aime,commentaire et les loaders de store des offres publicitaires
  const { loadingAdsLike, loadPostByID, commentsForPost, loadingPostComment } = useSelector((store) => store.postNews);
  //Declaration de variable dans le state pour le commentaire
  const [comment, setComment] = useState('');
  //Declaration de variable dans le state pour les commentaires de l'offre
  const [comments, setComments] = useState([]);
  const dispatch = useDispatch();
  //render on fucuss
  //UseFocusEffect
  useFocusEffect(
    useCallback(() => {
      //Appel de Reducer de fetch de l'offre publicitaire
      dispatch(getAdvertisingOfferById({ user_id: userID, offer_id: data.offer_id }));
      //Appel de Reducer de fetch des commentaire de l'offre publicitaire
      dispatch(getAllAdvertisingComments({ ads_id: data.offer_id }));
      //mise à jour des commentaires dans le state local
      setComments((prevState) => commentsForPost);
      //mise à jour de l'état de j'aime d'utilisateur
      setLike(data.user_has_liked);
      //mise à jour de nombre des j'aimes
      setLikeCount(data.likes);
    }, [data.offer_id, commentsForPost?.length, data.user_has_liked, data.likes])
  );
  //UseEffect
  useEffect(() => {
    //mise à jour de détails de l'offre
    setProduct({ ...data });
    dispatch(getAdvertisingOfferById({ user_id: userID, offer_id: data.offer_id }));
  }, [data.offer_id, product.offer_id, data.user_has_liked, data.likes]);

  //UseEffect de test
  useEffect(() => {
    //console.log(showAllComments);
  }, [showAllComments]);

  return (
    <SafeAreaView
      style={{
        flex: 1,
      }}
    >
      {!loadPostByID ? (
        <View>
          <ScrollView>
            <View style={styles.mainCarrousel}>
              {/* swiper, return Bnt => like, share external and internal link  use a relative container to palce the position of the retunr btn and share and stuff depending on therest*/}
              <Swiper
                dotColor={BaseColor.fadedGrey}
                activeDotStyle={{ width: 28 }}
                activeDotColor={BaseColor.primaryColor}
              >
                {data.offer_imgs.map((imageData, index) => (
                  <Image
                    style={styles.carrousel}
                    key={index}
                    source={{ uri: imageData.replace('localhost', '10.0.2.2') }}
                  />
                ))}
              </Swiper>
              <View style={styles.IconsContainer}>
                <View
                  style={{
                    ...styles.iconsFrame,
                    marginTop: 28,
                  }}
                >
                  <Pressable
                    onPress={() => {
                      dispatch(emptyPostByIB());
                      dispatch(emptyPostComment());
                      setComments((prevState) => []);
                      setLike('');
                      setLikeCount(0);
                      setShowAllComments(false);
                      navigation.navigate('Marketplace');
                    }}
                  >
                    <EntypoIcons name="chevron-left" color={BaseColor.backMain} size={32} />
                  </Pressable>
                </View>
                <View style={styles.socialsContainer}>
                  <View
                    style={{
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}
                  >
                    <View style={styles.iconsFrame}>
                      <Pressable
                        onPress={() => {
                          if (loadingAdsLike) return;
                          if (like) {
                            setLike((prevState) => !prevState);
                            setLikeCount((prevState) => prevState - 1);
                            dispatch(unLikeAdvertisingOffer({ user_id: userID, ads_id: product.offer_id }));
                            setProduct((prevState) => ({
                              ...prevState,
                              user_has_liked: false,
                              likes: prevState.likes - 1,
                            }));
                          } else {
                            setLike((prevState) => !prevState);
                            setLikeCount((prevState) => prevState + 1);
                            dispatch(likeAdvertisingOffer({ user_id: userID, ads_id: product.offer_id }));
                            setProduct((prevState) => ({
                              ...prevState,
                              user_has_liked: true,
                              likes: prevState.likes + 1,
                            }));
                          }
                        }}
                      >
                        {!like ? (
                          <AntDesign name="hearto" size={22} color={BaseColor.backMain} />
                        ) : (
                          <AntDesign name="heart" size={22} color={BaseColor.redheart} />
                        )}
                      </Pressable>
                    </View>
                    <Text
                      style={{
                        fontSize: Fonts.font_big,
                        fontFamily: 'Poppins-Medium',
                      }}
                    >
                      {likeCount}
                    </Text>
                  </View>
                  <View
                    style={{
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}
                  >
                    <View style={styles.iconsFrame}>
                      <Feather name="share-2" size={22} color={BaseColor.backMain} />
                    </View>
                    <Text
                      style={{
                        fontSize: Fonts.font_big,
                        fontFamily: 'Poppins-Medium',
                      }}
                    >
                      00
                    </Text>
                  </View>
                  <View
                    style={{
                      justifyContent: 'center',
                      alignItems: 'center',
                    }}
                  >
                    <View style={styles.iconsFrame}>
                      <Octicons name="link" size={22} color={BaseColor.backMain} />
                    </View>
                    <Text
                      style={{
                        fontSize: Fonts.font_big,
                        fontFamily: 'Poppins-Medium',
                      }}
                    >
                      00
                    </Text>
                  </View>
                </View>
              </View>
            </View>
            <View style={styles.partnerTab}>
              {/* main partner tab */}
              <View style={styles.partnerTab}>
                {/* logo and partner name */}
                <Image style={styles.partnerLogo} source={{ uri: partnerImge.replace('localhost', '10.0.2.2') }} />
                <Text
                  style={{
                    marginStart: 12,
                    fontSize: Fonts.font_XL,
                    fontFamily: 'Poppins-SemiBold',
                  }}
                >
                  {partnerName}
                </Text>
              </View>
            </View>
            <View
              style={{
                width: '100%',
                margin: 0,
                padding: 0,
                height: 0.5,
                backgroundColor: BaseColor.primaryLight,
                shadowColor: BaseColor.primarydark,
                shadowOpacity: 0.5,
                shadowOffset: {
                  width: 0,
                  height: 2,
                },
                shadowRadius: 3,
                elevation: 1,
              }}
            ></View>
            <View style={styles.titleSectionContainer}>
              <Text style={styles.titleText}> {data.title} news! </Text>
            </View>
            <View style={styles.descriptionContaier}>
              {/* description and specs zone */}
              <View
                style={{
                  marginBottom: 38,
                  paddingVertical: 4,
                  paddingHorizontal: 5,
                }}
              >
                <Text
                  style={{
                    textAlign: 'justify',
                  }}
                >
                  {data.description}
                </Text>
              </View>
            </View>
            {/* section for link */}
            <View
              style={{
                position: 'relative',
                flexDirection: 'row',
                justifyContent: 'space-between',
                alignItems: 'center',
                paddingLeft: 28,
                width: '94%',
                height: 72,
                backgroundColor: BaseColor.primarydark,
                borderRadius: 10,
                marginHorizontal: 12,
                marginBottom: 28,
              }}
            >
              <Image
                style={{
                  position: 'absolute',
                  width: 72,
                  height: 72,
                  resizeMode: 'contain',
                  left: -10,
                }}
                source={Logo.logo_detail_big}
              />
              <Pressable onPress={handlelink}>
                <Text
                  style={{
                    fontSize: Fonts.font_XL,
                    fontFamily: 'Poppins-Medium',
                    color: BaseColor.white,
                    marginLeft: 12,
                  }}
                >
                  {data.link.substr(0, 24)}
                </Text>
              </Pressable>
              <Image
                style={{
                  position: 'absolute',
                  width: 90,
                  height: 90,
                  resizeMode: 'contain',
                  right: 18,
                }}
                source={Mascotts.link_mascot}
              />
            </View>
            <View style={styles.commentariesContainer}>
              {/* section commnetaire */}
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
              >
                <Text
                  style={{
                    fontSize: Fonts.font_XL,
                    fontFamily: 'Poppins-Medium',
                    color: BaseColor.backMain,
                    marginLeft: 6,
                  }}
                >
                  Commentaires
                </Text>
                <Text
                  style={{
                    fontSize: Fonts.font_big,
                    fontFamily: 'Poppins-Medium',
                    color: BaseColor.backMain,
                    marginRight: 6,
                  }}
                  onPress={() => setShowAllComments((prevState) => !prevState)}
                >
                  {showAllComments ? 'Afficher moins' : 'Afficher tout'}
                </Text>
              </View>
              <View
                style={{
                  width: '100%',
                  paddingHorizontal: 12,
                  marginTop: 28,
                  marginBottom: 12,
                }}
              >
                {!loadPostByID && comments?.length ? (
                  <FlatList
                    data={
                      showAllComments
                        ? comments.slice(0, comments?.length)
                        : comments.slice(
                            comments?.length >= 3 ? comments?.length - 3 : 0,
                            comments?.length >= 3 ? comments?.length : 3
                          )
                    }
                    renderItem={({ item }) => (
                      <View
                        style={{
                          width: '100%',
                          flexDirection: 'row',
                          backgroundColor: BaseColor.white,
                          marginBottom: 12,
                          paddingHorizontal: 12,
                          paddingVertical: 8,
                          borderRadius: 10,
                        }}
                      >
                        <Image
                          style={{
                            width: 48,
                            height: 48,
                            marginRight: 28,
                            borderRadius: 100,
                            borderColor: BaseColor.fadedGrey,
                            borderWidth: 1.6,
                          }}
                          source={
                            item.profile_image
                              ? {
                                  uri: serverSection
                                    ? item.profile_image
                                    : item.profile_image.replace('localhost', '10.0.2.2'),
                                }
                              : require('../../../assets/profile.png')
                          }
                        />
                        <View
                          style={{
                            width: '95%',
                            paddingHorizontal: 8,
                          }}
                        >
                          <Text
                            style={{
                              fontSize: Fonts.font_XL,
                              fontFamily: 'Poppins-Medium',
                              color: BaseColor.backMain,
                            }}
                          >
                            {` ${item.first_name ? item.first_name : ''} ${item.last_name}`}
                          </Text>
                          <Text
                            style={{
                              fontSize: Fonts.font_normal,
                              fontFamily: 'Poppins-Regular',
                              color: BaseColor.backMain,
                              marginRight: 12,
                            }}
                          >
                            {item.comment_msg}
                          </Text>
                        </View>
                      </View>
                    )}
                    initialNumToRender={5}
                    keyExtractor={(item) => item.id}
                  />
                ) : null}

                {/* adding input for text */}
              </View>
              <View
                style={{
                  width: '95%',
                  flexDirection: 'row',
                  marginHorizontal: 12,
                  marginBottom: 10,
                  paddingHorizontal: 10,
                  paddingVertical: 0,
                  alignItems: 'center',
                  borderColor: BaseColor.greyMain,
                  borderRadius: 10,
                  borderWidth: 2,
                }}
              >
                <Image
                  style={{
                    width: 42,
                    height: 42,
                    marginRight: 18,
                    borderRadius: 100,
                    borderColor: BaseColor.fadedGrey,
                    borderWidth: 1.6,
                  }}
                  source={{ uri: userImage }}
                />
                <TextInput
                  width={'72%'}
                  label="comment"
                  value={comment}
                  placeholder="Entrer votre commentaire"
                  onChangeText={setComment}
                  multiline={true}
                  numberOfLines={3}
                />
                <Pressable
                  onPress={() => {
                    if (!comment) return;
                    dispatch(
                      createAdvertisingOfferComment({ user_id: userID, offer_id: data.offer_id, comment_msg: comment })
                    );
                    const newComment = {
                      id: Math.floor(Math.random() * 10000000),
                      created_at: new Date(),
                      user_id: userID,
                      comment_msg: comment,
                      commercial_offer_id: null,
                      advertising_offer_id: data.offer_id,
                      first_name: userfirstName,
                      last_name: userLastName,
                      profile_image: userImage,
                    };
                    setComments((prevState) => {
                      const oldState = prevState;
                      const newState = [...oldState, newComment];
                      return newState;
                    });
                    setComment('');
                  }}
                >
                  <Feather name="send" size={22} color={BaseColor.backMain} />
                </Pressable>
              </View>
            </View>
          </ScrollView>
        </View>
      ) : (
        <View
          style={{
            width: '100%',
            height: '100%',
            justifyContent: 'center',
            alignItems: 'center',
          }}
        >
          <ActivityIndicator size={56} color={BaseColor.primaryLight} />
        </View>
      )}
    </SafeAreaView>
  );
};

export default PostDetails;
