import React, { useEffect, useState, useCallback } from 'react';
import { useFocusEffect } from '@react-navigation/native';
import { Text, View, TouchableOpacity, Image, FlatList, SafeAreaView, ActivityIndicator } from 'react-native';
//css and utils
import styles from './style';
import { BaseColor } from '../../../config/theme';
import { Icons } from '../../../config/Images';
//components
import OfferComCard from '../../components/OffersCards';
import NoProducts from '../../components/noProduct';
//redux data
import { useDispatch, useSelector } from 'react-redux';
import { getAllCommercialOffersByCategory } from '../../store/commercialOffers/commercialOffersThunk';
import { getAllAdevertisingOffersByCategory } from '../../store/postNews/postNewsThunk';
import { getAllPartners } from '../../store/authentication/authenticationThunk';
import FiltreSVG from '../../../assets/Icons/components/FiltreSVG';
import Filtre from '../FiltreMarketplace/Filtre';

//Composant de Marketplace
const MarketPlace = ({ navigation }) => {
  //Declaration de variable de state pour la tab des offres commercials
  const [activeCommercial, setActiveCommercial] = useState(true);
  //Declaration de variable de state pour la tab des offres Pubilictaires
  const [activeNews, setActiveNews] = useState(false);
  //Appel des données des offres commercials, filters des offres et loader des offres commercials depuis le store des offres commercials
  const { offersData, loadingOffers, filters } = useSelector((store) => store.commercialOffers);
  //Appel des données des offres publicitaires,filters des offres et loader des offres publicitaires depuis le store des offres publicitaires
  const { postData, loadingPost, filtersnews } = useSelector((store) => store.postNews);
  //Appel des partenaires et loader des partenaires depuis le store d'authentification
  const { partners, loading_partners } = useSelector((store) => store.authentification);
  //Appel d'utilisateur depuis le store d'authentification
  const { user } = useSelector((store) => store.authentification);

  const dispatch = useDispatch();

  //UseFocusEffect
  useFocusEffect(
    useCallback(() => {
      //Appel de reducer de fetch des partenaires
      dispatch(getAllPartners());
      // console.log(partners);
    }, [])
  );

  //UseFocusEffect
  useFocusEffect(
    useCallback(() => {
      //Si les partneiares sont chargés
      if (!loading_partners) {
        //Si la tab active est d'offres commercials
        if (activeCommercial) {
          //Si l'utilisateur à des centres d'interets
          if (user.interests_ids?.length > 0) {
            //S'il y a des filtres
            if (filters?.length > 0) {
              //Set des données de centres d'interets, filters et utilisateur dans un objet
              const data = {
                interests: user.interests_ids,
                user_id: user.uid,
                filters: filters,
              };
              //console.log('1');
              //Appel au reducer de fetch des données de l'offre commercials
              dispatch(getAllCommercialOffersByCategory(data));
              // setCommercialDataOffers({...offersData});
            } else {
              //S'il n y a pas de filtres (tous les filtres sont selectionnés)
              //Set des données de centres d'interets, filters et utilisateur dans un objet
              const data = {
                interests: user.interests_ids,
                user_id: user.uid,
                filters: ['1', '2', '3', '4', '5', '6'],
              };
              //console.log('2');
              //Appel au reducer de fetch des données de l'offre commercials
              dispatch(getAllCommercialOffersByCategory(data));
              // setCommercialDataOffers({...offersData});
            }
          } else {
            //S'il n y a pas des centres d'interets d'utilisateur
            if (filters?.length > 0) {
              //S'il y a des filtres
              //set des interets 0 ( tous les offres car il n y a pas une category de valeur 0)
              const data = {
                interests: [0],
                user_id: user.uid,
                filters: filters,
              };
              //console.log('3');
              //Appel au reducer de fetch des données de l'offre commercials
              dispatch(getAllCommercialOffersByCategory(data));
              // setCommercialDataOffers({...offersData});
            } else {
              //S'il n y a pas des filtres
              //set des interets 0 et tous les filtres
              const data = {
                interests: [0],
                user_id: user.uid,
                filters: ['1', '2', '3', '4', '5', '6'],
              };
              //console.log('4');
              //Appel au reducer de fetch des données de l'offre commercials
              dispatch(getAllCommercialOffersByCategory(data));
              // setCommercialDataOffers({...offersData});
            }
          }
        }
      }
      //console.log("offers data fetch display ========>",offersData);
    }, [loading_partners, activeCommercial])
  );

  //UseFocusEffect le meme principe que l'offre commercial sauf c'est pour les offres partenaires si la tab active est la tab des offres partenaires
  useFocusEffect(
    useCallback(() => {
      if (!loading_partners) {
        if (activeNews) {
          if (user.interests_ids?.length > 0) {
            if (filtersnews?.length > 0) {
              const data = {
                interests: user.interests_ids,
                user_id: user.uid,
                filters: filtersnews,
              };
              dispatch(getAllAdevertisingOffersByCategory(data));
              // setPostDataNews({...postData})
            } else {
              const data = {
                interests: user.interests_ids,
                user_id: user.uid,
                filters: ['1', '2', '3', '4', '5', '6'],
              };
              dispatch(getAllAdevertisingOffersByCategory(data));
              // setPostDataNews({...postData})
            }
          } else {
            if (filtersnews?.length > 0) {
              const data = {
                interests: [0],
                user_id: user.uid,
                filters: filtersnews,
              };
              dispatch(getAllAdevertisingOffersByCategory(data));
              // setPostDataNews({...postData})
            } else {
              const data = {
                interests: [0],
                user_id: user.uid,
                filters: ['1', '2', '3', '4', '5', '6'],
              };
              dispatch(getAllAdevertisingOffersByCategory(data));
              // setPostDataNews({...postData})
            }
          }
        }
      }
      //console.log("adds data fetch display ========>",postData);
    }, [loading_partners, activeNews])
  );

  return (
    <SafeAreaView style={{ flex: 0.92 }}>
      <View style={styles.marketPlaceNavMain}>
        <View style={styles.marketplaceTabContainer}>
          <TouchableOpacity
            onPress={() => {
              setActiveCommercial((prevState) => true);
              setActiveNews((prevState) => false);
            }}
          >
            {activeCommercial ? (
              <View style={styles.mainCenter}>
                <View style={styles.marketPlaceUnitab}>
                  <Image source={require('../../../assets/Icons/marketOfferCom_active.png')} />
                  <Text style={styles.marketPlaceTextUnitActive}>Marketplace</Text>
                </View>
                <View style={styles.marketPlaceActiveTab}></View>
              </View>
            ) : (
              <View style={styles.mainCenter}>
                <View style={styles.marketPlaceUnitab}>
                  <Image source={require('../../../assets/Icons/marketOfferCom_null.png')} />
                  <Text style={styles.marketPlaceTextUnitNull}>Marketplace</Text>
                </View>
                <View style={styles.marketPlaceNullTab}></View>
              </View>
            )}
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => {
              setActiveCommercial((prevState) => false);
              setActiveNews((prevState) => true);
            }}
          >
            {activeNews ? (
              <View style={styles.mainCenter}>
                <View style={styles.marketPlaceUnitab}>
                  <Image source={require('../../../assets/Icons/marketNews_active.png')} />
                  <Text style={styles.marketPlaceTextUnitActive}>News</Text>
                </View>
                <View style={styles.marketPlaceActiveTab}></View>
              </View>
            ) : (
              <View style={styles.mainCenter}>
                <View style={styles.marketPlaceUnitab}>
                  <Image source={require('../../../assets/Icons/marketNews_null.png')} />
                  <Text style={styles.marketPlaceTextUnitNull}>News</Text>
                </View>
                <View style={styles.marketPlaceNullTab}></View>
              </View>
            )}
          </TouchableOpacity>
        </View>
        <TouchableOpacity style={styles.marketplaceFilterContainer} onPress={() => navigation.navigate('Filtre')}>
          <FiltreSVG scale={{ width: 30, height: 30, stroke: 2.8 }} style={styles.filterIcon} />
        </TouchableOpacity>
      </View>

      {/* flatList section scrolls */}
      <View style={styles.testContainer}>
        {!loadingOffers && !loadingPost && !loading_partners ? (
          offersData?.length > 0 || postData?.length > 0 ? (
            <FlatList
              data={activeCommercial ? offersData : postData}
              renderItem={({ item }) => {
                return (
                  <OfferComCard
                    user={user}
                    item={item}
                    navigation={navigation}
                    partners={partners}
                    timer={activeCommercial}
                    offer_type={activeCommercial}
                    endDate={item.expiration_date}
                  />
                );
              }}
              initialNumToRender={10}
              keyExtractor={(item) => item.offer_id}
            />
          ) : (
            <View
              style={{
                width: '100%',
                height: '100%',
                justifyContent: 'center',
                alignItems: 'center',
              }}
            >
              <NoProducts />
            </View>
          )
        ) : (
          <View
            style={{
              width: '100%',
              height: '100%',
              justifyContent: 'center',
              alignItems: 'center',
            }}
          >
            <ActivityIndicator size={56} color={BaseColor.primaryLight} />
          </View>
        )}
        {/* switch loader and no products position for exact situation */}
      </View>
    </SafeAreaView>
  );
};

export default MarketPlace;
