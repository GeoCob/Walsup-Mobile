import { StyleSheet } from 'react-native';
import { BaseColor, Fonts } from '../../../config/theme';

export default StyleSheet.create({
  mainCenter: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  marketPlaceNavMain: {
    flexDirection: 'row',
    height: 52,
    backgroundColor: BaseColor.white,
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  //Tab sections navigation Units
  marketplaceTabContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
    width: '80%',
  },
  marketPlaceUnitab: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  marketPlaceTextUnitActive: {
    fontSize: Fonts.font_big,
    fontFamily: 'Poppins-Medium',
    color: BaseColor.primarydark,
    marginLeft: 12,
  },
  marketPlaceTextUnitNull: {
    fontSize: Fonts.font_big,
    fontFamily: 'Poppins-Medium',
    color: BaseColor.greyMain,
    marginLeft: 12,
  },
  marketPlaceActiveTab: {
    width: 124,
    marginTop: 3,
    borderColor: BaseColor.primarydark,
    borderBottomWidth: 2,
    borderRadius: 20,
  },
  marketPlaceNullTab: {
    width: 124,
    marginTop: 3,
    borderColor: 'transparent',
    borderBottomWidth: 2,
    borderRadius: 10,
  },
  //filterSection
  marketplaceFilterContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: '20%',
    height: '100%',
    borderLeftWidth: 1,
    borderColor: BaseColor.fadedGrey,
  },
  filterIcon: {
    width: 24,
    height: 27,
  },
  testComp: {
    width: 240,
    height: 42,
    marginBottom: 12,
    backgroundColor: BaseColor.orangePrimary,
    borderRadius: 10,
  },
  testContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  //++++++++++++++++//
  //cardOffers styles
  //++++++++++++++++//
  cardContainer: {
    height: 570,
    borderRadius: 10,
    paddingVertical: 6,
    paddingBottom: 12,
    marginHorizontal: 12,
    marginVertical: 12,
    borderColor: '#6858DD',
    backgroundColor: '#ffffff',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 1,
    elevation: 2,
  },
  partnerTab: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 4,
    marginTop: 1,
    marginBottom: 4,
  },
  partnerLogo: {
    width: 46,
    height: 46,
  },
  optionPartnerContainer: {
    justifyContent: 'center',
    alignContent: 'center',
  },
  OptionBtn: {
    width: 21,
    height: 21,
    resizeMode: 'contain',
  },
  //Carroucel styles sections
  mainCarrousel: {
    width: '100%',
    height: 360,
    justifyContent: 'center',
    alignItems: 'center',
  },
  carrousel: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  //social buttons styles section
  mainSocials: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 48,
    paddingHorizontal: 8,
  },
  socialunit: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    alignItems: 'center',
  },
  socialIcons: {
    width: 24,
    height: 28,
    resizeMode: 'contain',
  },
  socialGapText: {
    marginLeft: 12,
    fontSize: 18,
    fontFamily: 'Poppins-SemiBold',
  },
  //Title and counter section
  titleSectionContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 12,
  },
  titleText: {
    fontSize: 16,
    fontFamily: 'Poppins-Medium',
  },
  titleCounter: {
    width: 108,
    resizeMode: 'contain',
  },
  //description section
  descriptContainer: {
    justifyContent: 'space-between',
    paddingHorizontal: 8,
  },
  descriptText: {
    color: '#8C8C8C',
  },
});
