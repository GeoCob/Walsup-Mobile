import { Text, StyleSheet, View, ScrollView, ActivityIndicator } from 'react-native';
import React, { Component, useEffect } from 'react';
import InvitationCard from '../../components/InvitationCard';
import GroupeInvitationCard from '../../components/GroupeInvitationCard';
import { Divider } from '@rneui/themed';
import NoSocialData from '../../components/noSocialData';
import CustomButton from '../../components/Button';
import { useDispatch, useSelector } from 'react-redux';
import {
  GetFollowsReceived,
  GetFollowsSent,
  GetGroupeReceivedInvitations,
  GetGroupeSentInvitations,
} from '../../store/social/socialThunk';
import { BaseColor } from '../../../config/theme';
import { useIsFocused } from '@react-navigation/native';

//Composant des invitations
const Invitations = ({ route, navigation }) => {
  //Appel des des invitationsTitle , title et tab de route.params
  const { InvitationTitleRequest, InvitationTitleReceived, title, tab } = route.params;
  //Appel de invitation reçus et envoyés d'amitié et de groupes et les loaders depuis le store social
  const {
    FollowsReceived,
    FollowsReceivedLoader,
    FollowsSent,
    FollowsSentLoader,
    GroupeReceivedInvitations,
    GroupeReceivedInvitationsLoader,
    GroupeSentInvitations,
    GroupeSentInvitationsLoader,
  } = useSelector((store) => store.social);
  //Appel à l'utilisateur depuis le store d'authentification
  const { user } = useSelector((store) => store.authentification);
  const dispatch = useDispatch();
  const isFocused = useIsFocused();

  //UseEffect
  useEffect(() => {
    if (isFocused && tab === 'amis') {
      //Si la tab d'ou l'utilisateur a cliqué est amis on fetch les invitation des amis reçues et envoyés
      dispatch(GetFollowsReceived(user.uid));
      dispatch(GetFollowsSent(user.uid));
    } else if (isFocused && tab === 'groupes') {
      //Si la tab d'ou l'utilisateur a cliqué est groupes on fetch les invitation des groupes reçues et envoyés
      dispatch(GetGroupeReceivedInvitations(user.uid));
      dispatch(GetGroupeSentInvitations(user.uid));
    }
  }, [isFocused, tab]);

  //Fonction de Button de navigation vers la page de suggestion en cas ou il n y a aucune invitations en attente
  const ButtonPress = () => {
    if (tab === 'groupes') {
      navigation.navigate('Suggestions', {
        title: title,
        tab: 'groupes_Suggs',
      });
    } else {
      navigation.navigate('Suggestions', {
        title: title,
        tab: 'amis',
      });
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      <View style={{ flex: 0.5 }}>
        <Text style={styles.ListeName}>{InvitationTitleReceived}</Text>
        {tab === 'amis' ? (
          !FollowsReceivedLoader && FollowsReceived.length > 0 ? (
            <ScrollView>
              {FollowsReceived.map((item) => {
                return (
                  <React.Fragment key={item.uid}>
                    <InvitationCard item={item} type="received" />
                    <Divider
                      insertType="left"
                      orientation="horizontal"
                      width={1}
                      style={{ width: '80%', marginHorizontal: 30 }}
                      color="#F2F2F2"
                    />
                  </React.Fragment>
                );
              })}
            </ScrollView>
          ) : !FollowsReceivedLoader && FollowsReceived.length === 0 ? (
            <Text style={styles.NodataText}>Aucune Nouvelle Invitation</Text>
          ) : (
            <ActivityIndicator
              color={BaseColor.primaryLight}
              style={{ position: 'absolute', top: '50%', left: '50%' }}
            />
          )
        ) : tab === 'groupes' ? (
          !GroupeReceivedInvitationsLoader && GroupeReceivedInvitations.length > 0 ? (
            <ScrollView>
              {GroupeReceivedInvitations.map((item, idx) => {
                return (
                  <React.Fragment key={idx}>
                    <GroupeInvitationCard item={item} type="received" />
                    <Divider
                      insertType="left"
                      orientation="horizontal"
                      width={1}
                      style={{ width: '80%', marginHorizontal: 30 }}
                      color="#F2F2F2"
                    />
                  </React.Fragment>
                );
              })}
            </ScrollView>
          ) : !GroupeReceivedInvitationsLoader && GroupeReceivedInvitations.length === 0 ? (
            <Text style={styles.NodataText}>Aucune Nouvelle Invitation</Text>
          ) : (
            <ActivityIndicator
              color={BaseColor.primaryLight}
              style={{ position: 'absolute', top: '50%', left: '50%' }}
            />
          )
        ) : null}
      </View>
      <View style={{ flex: 0.5 }}>
        <Text style={styles.ListeName}>{InvitationTitleRequest}</Text>
        {tab === 'amis' ? (
          !FollowsSentLoader && FollowsSent.length > 0 ? (
            <ScrollView>
              {FollowsSent.map((item) => {
                return (
                  <React.Fragment key={item.uid}>
                    <InvitationCard item={item} type="sent" />
                    <Divider
                      insertType="left"
                      orientation="horizontal"
                      width={1}
                      style={{ width: '80%', marginHorizontal: 30 }}
                      color="#F2F2F2"
                    />
                  </React.Fragment>
                );
              })}
            </ScrollView>
          ) : !FollowsSentLoader && FollowsSent.length === 0 ? (
            <View style={{ flexDirection: 'column', justifyContent: 'space-between', alignContent: 'center' }}>
              <Text style={[styles.NodataText, { top: 60 }]}> Explorer de nouvelle communauté</Text>
              <CustomButton
                style={{
                  position: 'absolute',
                  top: 100,
                  alignSelf: 'center',
                  width: 129,
                  height: 37,
                  backgroundColor: 'rgba(105, 89, 222, 1)',
                  borderRadius: 5,
                }}
                Textstyle={{
                  fontFamily: 'Poppins-Medium',
                  fontSize: 12,
                  textAlign: 'center',
                  marginTop: 7,
                }}
                title="Voir Suggestions"
                onPress={() => ButtonPress()}
              />
            </View>
          ) : (
            <ActivityIndicator
              color={BaseColor.primaryLight}
              style={{ position: 'absolute', top: '50%', left: '50%' }}
            />
          )
        ) : tab === 'groupes' ? (
          !GroupeSentInvitationsLoader && GroupeSentInvitations.length > 0 ? (
            <ScrollView>
              {GroupeSentInvitations.map((item) => {
                return (
                  <React.Fragment key={item.id}>
                    <GroupeInvitationCard item={item} type="sent" />
                    <Divider
                      insertType="left"
                      orientation="horizontal"
                      width={1}
                      style={{ width: '80%', marginHorizontal: 30 }}
                      color="#F2F2F2"
                    />
                  </React.Fragment>
                );
              })}
            </ScrollView>
          ) : !GroupeSentInvitationsLoader && GroupeSentInvitations.length === 0 ? (
            <View style={{ flexDirection: 'column', justifyContent: 'space-between', alignContent: 'center' }}>
              <Text style={[styles.NodataText, { top: 60 }]}> Explorer de nouvelle communauté</Text>
              <CustomButton
                style={{
                  position: 'absolute',
                  top: 100,
                  alignSelf: 'center',
                  width: 129,
                  height: 37,
                  backgroundColor: 'rgba(105, 89, 222, 1)',
                  borderRadius: 5,
                }}
                Textstyle={{
                  fontFamily: 'Poppins-Medium',
                  fontSize: 12,
                  textAlign: 'center',
                  marginTop: 7,
                }}
                title="Voir Suggestions"
                onPress={() => ButtonPress()}
              />
            </View>
          ) : (
            <ActivityIndicator
              color={BaseColor.primaryLight}
              style={{ position: 'absolute', top: '50%', left: '50%' }}
            />
          )
        ) : null}
      </View>
    </View>
  );
};
export default Invitations;

const styles = StyleSheet.create({
  ListeName: {
    color: '#333333',
    marginLeft: 20,
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    lineHeight: 20,
  },
  NodataText: {
    fontFamily: 'Poppins-SemiBold',
    fontSize: 13,
    lineHeight: 19.5,
    alignSelf: 'center',
    textAlign: 'center',
    position: 'absolute',
    top: 200,
  },
});
