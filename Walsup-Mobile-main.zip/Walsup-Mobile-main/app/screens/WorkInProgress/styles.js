import { StyleSheet, Dimensions } from 'react-native';

const screenWidth = Math.round(Dimensions.get('window').width);
const screenHeight = Math.round(Dimensions.get('window').height);

export default StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    width: screenWidth * 0.8,
    height: screenHeight * 0.8,
    resizeMode: 'contain',
  },
  text: {
    fontSize: 16,
  },
});
