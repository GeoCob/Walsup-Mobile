import React from 'react';
import { View, Text, Image, Button } from 'react-native';
import styles from './styles';

//Page affiché dans les sections qui ne sont pas encore developpée
const WorkInProgress = () => {
  return (
    <View style={styles.container}>
      {/* <Header title="workInProgress" /> */}
      <Image source={require('../../../assets/work_in_progress.png')} style={styles.image} />
    </View>
  );
};

export default WorkInProgress;
