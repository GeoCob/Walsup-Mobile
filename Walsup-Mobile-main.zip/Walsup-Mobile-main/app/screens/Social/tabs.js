import { StyleSheet } from 'react-native';
import React, { useEffect, useState } from 'react';
import { Text, TouchableOpacity, View } from 'react-native';
import {
  getAllGroupsById,
  getAllGroupsSuggestionsByUid,
  getfollowedUsers,
  getFriendfollowedUsers,
  getUnfollowedUsers,
  getFirendAllGroupsById,
  getSuggestionPartners,
  getAllSubscribedPartners,
} from '../../store/social/socialThunk';
import { fetchAllCommercialOffers } from '../../store/commercialOffers/commercialOffersThunk';
import { getAllPartners } from '../../store/authentication/authenticationThunk';
import { useDispatch } from 'react-redux';

//Composant des tabs
const Tabs = (props) => {
  const { changeTabType, selected, type, user, otherUser, title } = props;

  const dispatch = useDispatch();
  //fonction de fetch des suggestion des amis appelant le reducer correspondant
  const fetchSuggstions = () => {
    dispatch(getUnfollowedUsers(user.uid));
  };
  //fonction de fetch des amis appelant le reducer correspondant
  const fetchAmis = () => {
    dispatch(getfollowedUsers(user.uid));
  };
  //fonction de fetch des suggestion des groupes appelant le reducer correspondant
  const fetchGroups = () => {
    dispatch(getAllGroupsById(user.uid));
  };
  //fonction de fetch des amis d'un ami appelant le reducer correspondant
  const fetchAmisProfile = () => {
    dispatch(getFriendfollowedUsers(otherUser.uid));
  };
  //fonction de fetch des groupes d'un ami appelant le reducer correspondant
  const fetchGroupsProfile = () => {
    dispatch(getFirendAllGroupsById(otherUser.uid));
  };
  //fonction de fetch des suggestion des groupes appelant le reducer correspondant
  const fetchGroupsSuggestions = () => {
    dispatch(getAllGroupsSuggestionsByUid(user.uid));
  };
  //fonction de fetch des offres commercials appelant le reducer correspondant
  const fetchAllCommercialOffersApi = () => {
    dispatch(fetchAllCommercialOffers());
  };
  //fonction de fetch des partenaires appelant le reducer correspondant
  const fetchAllPartnersApi = () => {
    dispatch(getAllPartners());
  };

  //Fonction qui appel les fonctions de fetch correspondant selon la tab active
  const handleChangeTabType = () => {
    changeTabType(type);
    switch (type) {
      case 'amis':
        fetchAmis();
        fetchSuggstions();
        break;
      case 'amisProfil':
        fetchAmisProfile();
        break;
      case 'groupes':
        fetchGroups();
        fetchGroupsSuggestions();
        fetchAllCommercialOffersApi();
        fetchAllPartnersApi();

        break;
      case 'groupesProfil':
        fetchGroupsProfile();
        break;
      case 'abonnements':
        // console.log('user from partner sub tab ===>',user);
        dispatch(getAllSubscribedPartners({ user_uid: user.uid }));
        dispatch(getSuggestionPartners({ user_uid: user.uid, suggestionType: false }));
        break;
      case 'abonnementsProfil':
        //fetchAllBrandAmbassadors(brandKey);
        dispatch(getAllSubscribedPartners({ user_uid: otherUser.uid }));
        break;
      default:
        break;
    }
  };
  //Retour d'ui de tabs
  return (
    <TouchableOpacity
      onPress={handleChangeTabType}
      style={[styles.tabs, { backgroundColor: selected ? '#F2F2F2' : 'white' }]}
    >
      <Text style={[styles.tabsName, { color: selected ? '#6959DE' : '#8A8A8A' }]}>
        {title.charAt(0).toUpperCase() + title.slice(1)}
      </Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  tabs: {
    marginHorizontal: 5,
    marginVertical: 10,
    paddingHorizontal: 25,
    paddingVertical: 5,
    borderRadius: 50,
  },
  tabsName: {
    fontFamily: 'Poppins-Medium',
    fontSize: 14,
    lineHeight: 21,
  },
});

export default Tabs;
