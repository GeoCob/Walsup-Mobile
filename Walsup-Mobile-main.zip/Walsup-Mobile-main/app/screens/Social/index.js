import { View } from 'react-native';
import React from 'react';
import styles from './styles';
import Tabs from './tabs';
import { useState } from 'react';
import TabContent from './tabContent';
import { useSelector } from 'react-redux';

export const Social = ({ route, navigation }) => {
  //Appel à l'utilisateur depuis le store d'authntification
  const { user } = useSelector((store) => store.authentification);
  //Appel aux loaders et données depuis le store de social
  const {
    UnfollowedUsers,
    followedUsers,
    UnfollowedUsersLoader,
    followedUsersLoader,
    UserGroups,
    UserGroupsLoader,
    UserGroupsSuggestions,
    UserGroupsSuggestionsLoader,
  } = useSelector((store) => store.social);
  //Declaration d'une variable dans le state pour le type de tab active
  const [tabType, setTabType] = useState('amis');

  //Fonction de changement de tab active
  const handleTabChange = (tabType) => {
    setTabType(tabType);
  };
  //Fonction d'appel au composant de contenu de tab selon le type de tab active
  const getTable = (TabType) => {
    switch (TabType) {
      case 'amis':
        return (
          <TabContent
            SuggestionsData={UnfollowedUsers}
            followedUsers={followedUsers}
            tab={tabType}
            ListeName={"Liste d'amis"}
            SuggstionsName={"Suggestions d'amis"}
            user={user}
            navigation={navigation}
            UnfollowedUsersLoader={UnfollowedUsersLoader}
            followedUsersLoader={followedUsersLoader}
            handleTabtype={handleTabChange}
          />
        );
      case 'groupes':
        return (
          <TabContent
            tab={tabType}
            ListeName={'Mes Groupes'}
            handleTabtype={handleTabChange}
            SuggstionsName={'Suggestions'}
            UserGroupsSuggestions={UserGroupsSuggestions}
            UserGroupsSuggestionsLoader={UserGroupsSuggestionsLoader}
            UserGroups={UserGroups}
            navigation={navigation}
            UserGroupsLoader={UserGroupsLoader}
            user={user}
          />
        );
      case 'abonnements':
        return (
          <TabContent
            tab={tabType}
            user={user}
            navigation={navigation}
            handleTabtype={handleTabChange}
            ListeName={'Liste des Partnaires'}
            SuggstionsName={'Suggestions'}
          />
        );
      default:
        return <></>;
    }
  };
  const tableToRender = getTable(tabType);
  //Retour des tabs et de contenu de la tab active
  return (
    <View style={styles.Container}>
      <View style={styles.tabsContainer}>
        <Tabs
          type={'amis'}
          title={'amis'}
          tabType={tabType}
          selected={tabType === 'amis'}
          changeTabType={(type) => handleTabChange(type)}
          user={user}
        />
        <Tabs
          type={'groupes'}
          title={'groupes'}
          tabType={tabType}
          selected={tabType === 'groupes'}
          changeTabType={(type) => handleTabChange(type)}
          user={user}
        />
        <Tabs
          type={'abonnements'}
          title={'abonnements'}
          tabType={tabType}
          selected={tabType === 'abonnements'}
          changeTabType={(type) => handleTabChange(type)}
          user={user}
        />
      </View>
      {tableToRender}
    </View>
  );
};

export default Social;
