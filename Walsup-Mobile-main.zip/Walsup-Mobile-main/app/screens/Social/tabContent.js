import { ActivityIndicator, StyleSheet } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import React, { useState, useEffect, useCallback } from 'react';
import { Text, TouchableOpacity, View, ScrollView, Image } from 'react-native';
import SearchBarComponent from '../../components/SearchBar';
import AmiCard from '../../components/AmiCard';
import SuggestionAmiCard from '../../components/SuggestionAmiCard';
import SuggestionPartnerCard from '../../components/SuggestionPartnerCard';
import PartnerCard from '../../components/PartnerCard';
import { useIsFocused } from '@react-navigation/native';

import {
  getAllGroupsById,
  getAllGroupsSuggestionsByUid,
  getfollowedUsers,
  getUnfollowedUsers,
  getFirendAllGroupsById,
  getFriendfollowedUsers,
  getFriendAllSubscribedPartners,
} from '../../store/social/socialThunk';
import { useSelector, useDispatch } from 'react-redux';
import ModalComponent from '../../components/Modal';
import NoSocialData from '../../components/noSocialData';
import GroupeCard from '../../components/GroupeCard';
import SuggestionGroupeCard from '../../components/SuggestionGroupeCard';
import CreateGroupeIcon from '../../../assets/Icons/components/CreateGroupeIcon';
import { BaseColor } from '../../../config/theme';

//Composant de contenu des tabs (selon le type)
const TabContent = (props) => {
  //Declaration d'une variable dans le state initialisé par array vide pour le résultat de recherche
  const [searchResults, setSearchResults] = useState([]);
  //Declaration d'une variable dans le state initialisé par string vide pour la phrase de recherche
  const [searchPhrase, setSearchPhrase] = useState('');
  //Declaration d'une variable dans le state intitialisé par false pour l'état de recherche
  const [searchingStatus, setSearchStatus] = useState(false);
  //Declaration d'une variable dans le state initialisé par false pour la bar de recherche
  const [clicked, setClicked] = useState(false);
  const dispatch = useDispatch();
  //Declaration d'une variable qui appel une fonction qui verifie si la page est focusé
  const isFocused = useIsFocused();
  //Appel des données depuis le props
  const {
    tab,
    ListeName,
    followedUsers,
    FriendfollowedUsers,
    FriendfollowedUsersLoader,
    SuggstionsName,
    SuggestionsData,
    FriendUserGroups,
    FriendUserGroupsLoader,
    UserGroups,
    UserGroupsLoader,
    UserGroupsSuggestions,
    UserGroupsSuggestionsLoader,
    user,
    otherUser,
    navigation,
    followedUsersLoader,
    UnfollowedUsersLoader,
    //partners section
    //functions
    handleTabtype,
  } = props;

  //Fonction de reset de résultat et l'état de la barre de recherche
  const ressetSearch = () => {
    setSearchResults([]);
    setSearchPhrase('');
    setSearchStatus(false);
    setClicked(false);
  };
  //Appel des loader et des données des partenaires
  const {
    partnersSubsLoader,
    partnersSuggestionLoader,
    partnersSubscribed,
    partnersSuggestions,
    FriendpartnersSubscribed,
    FriendpartnersSubsLoader,
  } = useSelector((store) => store.social);
  //Declaration d'une variable dans le state initialisé par false pour le toggle de Modal
  const [isModalVisible, setisModalVisible] = useState(false);
  //Declaration d'une variable dans le state initialisé par null pour l'ami à supprimé de la liste
  const [FriendRemove, setFriendRemove] = useState(null);
  //Declarartion d'une variable dans le state intialisé par null pour l'ami à ajouter comme ami (envois de demande)
  const [FriendToadd, setFriendToadd] = useState(null);
  //Declaration d'une variable dans le state intialisé par false pour le toggle de modal (amis/groupes)
  const [GroupPopUpModifier, setGroupPopUpModifier] = useState(false);
  //Declaration d'une variable dans le state intialisé par null pour la selection de groupe à gérer dans la popup
  const [group, setGroup] = useState(null);

  //Fonction de toggle de Modal d'ami
  const ModalVisibiltyToggle = (friend) => {
    setisModalVisible(!isModalVisible);
    setFriendRemove(friend);
  };
  //Fonction de toggle de Modal de creation de groupe
  const CreateGroupModalVisibilityToggle = () => {
    setGroupPopUpModifier(true);
    setisModalVisible(!isModalVisible);
  };
  //Fonction de toggle de Modal pour un utilisateur suggéré
  const ModalVisibiltyToggleAdd = (friend) => {
    setisModalVisible(!isModalVisible);
    setFriendToadd(friend);
  };
  //Fonction de toggle de Modal pour un groupe
  const ModalVisibiltyToggleGroup = (grp) => {
    setGroupPopUpModifier(false);
    setisModalVisible(!isModalVisible);
    setGroup(grp);
  };

  //UseEffect d'appel aux reducers de fetch des amis et des suggestions d'amis pour la tab d'amis
  useEffect(() => {
    if (isFocused && tab === 'amis') {
      dispatch(getUnfollowedUsers(user.uid));
      dispatch(getfollowedUsers(user.uid));
      // console.log('amis',followedUsers);
      // console.log('suggs',SuggestionsData);
      ressetSearch();
    }
  }, [isFocused, tab]);

  //UseEffect d'appel aux reducers de fetch des groupes et des suggestions d'groupes pour la tab d'groupes
  useEffect(() => {
    if (isFocused && tab === 'groupes') {
      dispatch(getAllGroupsSuggestionsByUid(user.uid));
      dispatch(getAllGroupsById(user.uid));
      ressetSearch();
    }
  }, [isFocused, tab]);

  //UseEffect d'appel aux reducers de fetch des groupes d'un ami pour la tab d'amis dans un profile d'utilisateur
  useEffect(() => {
    if (isFocused && tab === 'groupesProfil') {
      dispatch(getFirendAllGroupsById(otherUser.uid));
      ressetSearch();
    }
  }, [isFocused, tab]);

  //UseEffect d'appel aux reducers de fetch des amis d'un ami pour la tab d'amis dans un profile d'utilisateur
  useEffect(() => {
    if (isFocused && tab === 'amisProfil') {
      dispatch(getFriendfollowedUsers(otherUser.uid));
      ressetSearch();
    }
  }, [isFocused, tab]);

  //UseEffect d'appel aux reducers de fetch des partneaires abonnées d'un ami pour la tab d'amis dans un profile d'utilisateur
  useEffect(() => {
    if (isFocused && tab === 'abonnementsProfil') {
      dispatch(getFriendAllSubscribedPartners({ user_uid: otherUser.uid }));
      ressetSearch();
    }
  }, [isFocused, tab]);

  //Fonction pour la navigation à la page des invitations
  const InvitationsHandle = () => {
    if (tab === 'amis') {
      navigation.navigate('Invitations', {
        InvitationTitleRequest: 'invitations envoyées',
        InvitationTitleReceived: 'Invitatinons recues',
        title: "Suggestions d'amis",
        tab: 'amis',
      });
    } else if (tab === 'groupes') {
      navigation.navigate('Invitations', {
        InvitationTitleRequest: 'invitations envoyées',
        InvitationTitleReceived: 'Invitatinons recues',
        title: 'Suggestions des Groupes',
        tab: 'groupes',
      });
    }
  };

  //Fonction pour la navigation à la page des suggestions
  const SuggestionsHandle = () => {
    if (tab === 'amis') {
      navigation.navigate('Suggestions', {
        tab: 'amis',
        title: "Suggestions d'amis",
      });
    }
    if (tab === 'groupes') {
      navigation.navigate('Suggestions', {
        tab: 'groupes_Suggs',
        title: 'Suggestions des Groupes',
      });
    }
    if (tab === 'abonnements') {
      navigation.navigate('Suggestions', {
        tab: 'abonnements',
        Suggsetions: partnersSuggestions,
        title: 'Suggestions de partenaire',
      });
    }
  };

  //Fonction de navigation vers la page de profile d'un partenaire
  const handlePartnerProfileNavigation = (data) => {
    //console.log('triger Navigations===>', data);
    ressetSearch();
    navigation.navigate('PartnerProfile', {
      connectedUserId: user.uid,
      partnerId: data.id,
      partnerName: data.name,
      partnerImageUrl: data.imageurl,
      partnerLink: 'https://www.youtube.com/',
      partnerSubbed: data.subbed,
    });
  };
  useEffect(() => {
    ressetSearch();
  }, [tab]);

  //Fonction de recherche selon la tab (en filtrant les données correspondants)
  const SearchHandle = () => {
    if (tab === 'amis') {
      const newState = followedUsers?.filter((search) => {
        if (search?.first_name && search?.last_name) {
          const fullName = search?.first_name + search?.last_name;
          return fullName.toLowerCase().includes(searchPhrase.toLowerCase());
        }
      });
      setSearchResults(newState);
      setSearchStatus(true);
    }
    if (tab === 'groupes') {
      //main var UserGroups
      const newState = UserGroups?.filter((search) => {
        if (search?.name) return search?.name.toLowerCase().includes(searchPhrase.toLowerCase());
      });
      setSearchResults(newState);
      setSearchStatus(true);
    }
    if (tab === 'abonnements') {
      //main var partnersSubscribed
      const newState = partnersSubscribed?.filter((search) => {
        if (search?.name) return search?.name.toLowerCase().includes(searchPhrase.toLowerCase());
      });
      setSearchResults(newState);
      setSearchStatus(true);
    }
  };

  //console.log('SuggestionsData', SuggestionsData, typeof SuggestionsData);

  //Retour de l'ui et les données selon la tab active
  return (
    <View style={{ flex: 1, backgroundColor: 'white' }}>
      <View
        style={
          tab === 'amisProfil' || tab === 'groupesProfil' || tab === 'abonnementsProfil' ? { flex: 1 } : { flex: 0.8 }
        }
      >
        {tab === 'amisProfil' || tab === 'groupesProfil' || tab === 'abonnementsProfil' ? null : tab === 'groupes' ? (
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              alignContent: 'flex-start',
              position: 'relative',
            }}
          >
            <SearchBarComponent
              clicked={clicked}
              setClicked={setClicked}
              searchPhrase={searchPhrase}
              setSearchPhrase={setSearchPhrase}
              search={SearchHandle}
              modifierSearchType={tab}
              setSearchStatus={setSearchStatus}
              ressetSearch={ressetSearch}
            />
            <TouchableOpacity
              style={styles.container__create__groupe}
              onPress={() => {
                CreateGroupModalVisibilityToggle();
              }}
            >
              <CreateGroupeIcon />
            </TouchableOpacity>
          </View>
        ) : (
          <SearchBarComponent
            clicked={clicked}
            setClicked={setClicked}
            searchPhrase={searchPhrase}
            setSearchPhrase={setSearchPhrase}
            search={SearchHandle}
            modifierSearchType={tab}
            setSearchStatus={setSearchStatus}
            ressetSearch={ressetSearch}
          />
        )}
        <View style={styles.ListeNameWithInvits}>
          <Text style={styles.ListeName}>{ListeName}</Text>
          {tab === 'amis' || tab === 'groupes' ? (
            <TouchableOpacity onPress={InvitationsHandle}>
              <Text style={styles.Invitations}>Invitations</Text>
            </TouchableOpacity>
          ) : null}
        </View>
        {tab === 'amis' ? (
          !followedUsersLoader && followedUsers?.length > 0 ? (
            <ScrollView style={{ marginTop: 15 }}>
              {searchResults?.length && searchPhrase && searchResults ? (
                searchResults?.map((item) => {
                  return (
                    <AmiCard
                      item={item}
                      key={item.uid}
                      navigation={navigation}
                      type={tab}
                      ModalVisibiltyToggle={ModalVisibiltyToggle}
                    />
                  );
                })
              ) : !searchResults?.length && searchPhrase && searchResults && searchingStatus ? (
                <NoSocialData Description="Auccun amis de ce nom" />
              ) : (
                followedUsers?.map((item) => {
                  return (
                    <AmiCard
                      item={item}
                      key={item.uid}
                      navigation={navigation}
                      type={tab}
                      ModalVisibiltyToggle={ModalVisibiltyToggle}
                    />
                  );
                })
              )}
            </ScrollView>
          ) : !followedUsersLoader && followedUsers?.length === 0 ? (
            <NoSocialData Description="Liste des Amis est Vide" />
          ) : (
            <ActivityIndicator
              color={BaseColor.primaryLight}
              style={{ position: 'absolute', top: '50%', left: '50%' }}
            />
          )
        ) : tab === 'amisProfil' ? (
          !FriendfollowedUsersLoader && FriendfollowedUsers?.length > 0 ? (
            <ScrollView style={{ marginTop: 15, flex: 1 }}>
              {FriendfollowedUsers.map((item) => {
                return (
                  <AmiCard
                    item={item}
                    key={item.uid}
                    navigation={navigation}
                    type={tab}
                    ModalVisibiltyToggle={ModalVisibiltyToggleAdd}
                  />
                );
              })}
            </ScrollView>
          ) : !FriendfollowedUsersLoader && FriendfollowedUsers?.length === 0 ? (
            <NoSocialData Description="Liste des Amis est Vide" />
          ) : (
            <ActivityIndicator
              color={BaseColor.primaryLight}
              style={{ position: 'absolute', top: '50%', left: '50%' }}
            />
          )
        ) : tab === 'groupes' ? (
          !UserGroupsLoader && UserGroups?.length > 0 ? (
            <ScrollView style={{ marginTop: 15 }}>
              {searchResults?.length && searchPhrase && searchingStatus ? (
                searchResults?.map((item) => (
                  <GroupeCard item={item} ModalVisibiltyToggle={ModalVisibiltyToggleGroup} key={item.id} type={tab} />
                ))
              ) : !searchResults?.length && searchPhrase && searchingStatus ? (
                <NoSocialData Description="Auccun résulta de recherche" />
              ) : (
                UserGroups &&
                UserGroups?.map((item) => {
                  return (
                    <GroupeCard item={item} ModalVisibiltyToggle={ModalVisibiltyToggleGroup} key={item.id} type={tab} />
                  );
                })
              )}
            </ScrollView>
          ) : !UserGroupsLoader && UserGroups?.length === 0 ? (
            <NoSocialData Description="Liste des Groupes est Vide" />
          ) : (
            <ActivityIndicator
              color={BaseColor.primaryLight}
              style={{ position: 'absolute', top: '50%', left: '50%' }}
            />
          )
        ) : tab === 'groupesProfil' ? (
          !FriendUserGroupsLoader && FriendUserGroups?.length > 0 ? (
            <ScrollView style={{ marginTop: 15, flex: 1 }}>
              {FriendUserGroups &&
                FriendUserGroups.map((item) => {
                  return (
                    <GroupeCard item={item} key={item.id} type={tab} ModalVisibiltyToggle={ModalVisibiltyToggleGroup} />
                  );
                })}
            </ScrollView>
          ) : !FriendUserGroupsLoader && FriendUserGroups?.length === 0 ? (
            <NoSocialData Description="Liste des Groupes est Vide" />
          ) : (
            <ActivityIndicator
              color={BaseColor.primaryLight}
              style={{ position: 'absolute', top: '50%', left: '50%' }}
            />
          )
        ) : tab === 'abonnements' ? (
          !partnersSubsLoader && partnersSubscribed?.length > 0 ? (
            <ScrollView style={{ marginTop: 15 }}>
              <View>
                {searchResults?.length && searchPhrase && searchingStatus ? (
                  searchResults?.map((item) => (
                    <PartnerCard
                      item={item}
                      user={user}
                      tab="abonnements"
                      profileNavigation={handlePartnerProfileNavigation}
                      subbed={true}
                      key={item.id}
                    />
                  ))
                ) : !searchResults?.length && searchPhrase && searchingStatus ? (
                  <NoSocialData Description="Aucun partenaire ne correspond a ta recherhce" />
                ) : (
                  partnersSubscribed &&
                  partnersSubscribed?.map((item) => (
                    <PartnerCard
                      item={item}
                      user={user}
                      tab="abonnements"
                      profileNavigation={handlePartnerProfileNavigation}
                      subbed={true}
                      key={item.id}
                    />
                  ))
                )}
              </View>
            </ScrollView>
          ) : !partnersSubsLoader && partnersSubscribed?.length === 0 ? (
            <NoSocialData Description="Liste des partenarie est Vide" />
          ) : (
            <ActivityIndicator
              color={BaseColor.primaryLight}
              style={{ position: 'absolute', top: '50%', left: '50%' }}
            />
          )
        ) : tab === 'abonnementsProfil' ? (
          !FriendpartnersSubsLoader && FriendpartnersSubscribed?.length > 0 ? (
            <ScrollView style={{ marginTop: 15 }}>
              {FriendpartnersSubscribed &&
                FriendpartnersSubscribed.map((item) => (
                  <PartnerCard
                    item={item}
                    tab="abonnementsProfil"
                    user={user}
                    profileNavigation={handlePartnerProfileNavigation}
                    subbed={true}
                    key={item.id}
                  />
                ))}
            </ScrollView>
          ) : !FriendpartnersSubsLoader && FriendpartnersSubscribed?.length === 0 ? (
            <NoSocialData Description="Liste des partenarie est Vide" />
          ) : (
            <ActivityIndicator
              color={BaseColor.primaryLight}
              style={{ position: 'absolute', top: '50%', left: '50%' }}
            />
          )
        ) : null}
      </View>
      <View
        style={[
          tab === 'amisProfil' || tab === 'groupesProfil' || tab === 'abonnementsProfil' ? { display: 'none' } : null,
          { flex: 0.2 },
        ]}
      >
        <View style={[styles.ListeSuggstion]}>
          <Text style={styles.ListeName}>{SuggstionsName}</Text>
          {/* handle the navigation conditions in the function depending on the type string */}
          <TouchableOpacity onPress={SuggestionsHandle}>
            <Text style={styles.Invitations}>Voir Tout</Text>
          </TouchableOpacity>
        </View>
        {tab === 'amis' ? (
          !UnfollowedUsersLoader ? (
            <ScrollView style={{ marginTop: 5 }} horizontal={true}>
              {SuggestionsData &&
                SuggestionsData?.slice(0, 6).map((item) => {
                  return <SuggestionAmiCard item={item} user={user} key={item.uid} />;
                })}
            </ScrollView>
          ) : (
            <ActivityIndicator
              color={BaseColor.primaryLight}
              style={{ position: 'absolute', top: '50%', left: '50%' }}
            />
          )
        ) : tab === 'groupes' ? (
          !UserGroupsSuggestionsLoader ? (
            <ScrollView style={{ marginTop: 5 }} horizontal={true}>
              {UserGroupsSuggestions &&
                UserGroupsSuggestions?.slice(0, 6).map((item) => {
                  return <SuggestionGroupeCard item={item} user={user} key={item.id} />;
                })}
            </ScrollView>
          ) : (
            <ActivityIndicator
              color={BaseColor.primaryLight}
              style={{ position: 'absolute', top: '50%', left: '50%' }}
            />
          )
        ) : tab === 'abonnements' ? (
          !partnersSuggestionLoader && partnersSuggestions?.length > 0 ? (
            <ScrollView style={{ marginTop: 5 }} horizontal={true}>
              {partnersSuggestions?.slice(0, 6).map((item) => {
                return (
                  <SuggestionPartnerCard
                    item={item}
                    user={user}
                    profileNavigation={handlePartnerProfileNavigation}
                    subbed={false}
                    key={item.id}
                  />
                );
              })}
            </ScrollView>
          ) : !partnersSuggestionLoader && partnersSuggestions?.length === 0 ? null : (
            <ActivityIndicator
              color={BaseColor.primaryLight}
              style={{ position: 'absolute', top: '50%', left: '50%' }}
            />
          )
        ) : null}
      </View>
      {tab === 'amis' ? (
        <ModalComponent
          item={FriendRemove}
          user={user}
          isModalVisible={isModalVisible}
          ModalVisibiltyToggle={ModalVisibiltyToggle}
          type={tab}
        />
      ) : tab === 'groupes' ? (
        GroupPopUpModifier === false ? (
          <ModalComponent
            item={group}
            user={user}
            isModalVisible={isModalVisible}
            ModalVisibiltyToggle={ModalVisibiltyToggleGroup}
            type={tab}
          />
        ) : (
          <ModalComponent
            isModalVisible={isModalVisible}
            ModalVisibiltyToggle={CreateGroupModalVisibilityToggle}
            type="groupeCreate"
          />
        )
      ) : tab === 'amisProfil' ? (
        <ModalComponent
          item={FriendToadd}
          user={user}
          isModalVisible={isModalVisible}
          ModalVisibiltyToggle={ModalVisibiltyToggleAdd}
          type={tab}
        />
      ) : tab === 'groupesProfil' ? (
        <ModalComponent
          item={group}
          user={user}
          isModalVisible={isModalVisible}
          ModalVisibiltyToggle={ModalVisibiltyToggleAdd}
          type={tab}
        />
      ) : null}
    </View>
  );
};

const styles = StyleSheet.create({
  ListeName: {
    color: '#333333',
    marginLeft: 20,
    fontFamily: 'Poppins-Medium',
    fontSize: 12,
    lineHeight: 20,
  },
  ListeNameWithInvits: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  Invitations: {
    color: '#6959DE',
    marginRight: 20,
  },
  ListeSuggstion: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
  },
  container__create__groupe: {
    width: 40,
    height: 40,
    position: 'absolute',
    right: 15,
    top: 12,
    backgroundColor: BaseColor.fadedGrey,
    borderRadius: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default TabContent;
