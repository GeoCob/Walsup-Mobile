import { StyleSheet } from "react-native";

export default StyleSheet.create({
    Container:{
        backgroundColor:'white',
        flex:1
    },
    tabsContainer:{
        flexDirection:'row',
        alignContent:'space-between',    
        alignItems:'center',
        backgroundColor:'white',
        justifyContent:'center'    
    },
    
});
