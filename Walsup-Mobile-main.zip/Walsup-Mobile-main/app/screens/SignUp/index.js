import React, { useState, useEffect } from 'react';
import { View, Image, TextInput, TouchableOpacity, Text, ActivityIndicator } from 'react-native';
import styles from './styles';
import * as Google from 'expo-auth-session/providers/google';
import { GoogleSignin, statusCodes } from '@react-native-google-signin/google-signin';
import * as Facebook from 'expo-auth-session/providers/facebook';
import * as AuthSession from 'expo-auth-session';
import { LoginManager, AccessToken } from 'react-native-fbsdk-next';
import Constants from 'expo-constants';
import { useDispatch, useSelector } from 'react-redux';
import {
  registerUserWithFacebook,
  registerUserWithGoogle,
  registerUser,
} from '../../store/authentication/authenticationThunk';
import { BaseColor } from '../../../config/theme';
import * as Yup from 'yup';
import { useFormik } from 'formik';
import * as WebBrowser from 'expo-web-browser';

import Ionicons from 'react-native-vector-icons/Ionicons';
import WalsupIconSVG from '../../../assets/Icons/components/WalsupIconSVG';
import { useFocusEffect } from '@react-navigation/native';

const SignUp = ({ navigation }) => {
  //Declaration des variable pour les valeurs de champs de formulaire (ne sont plus utilisés)
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  //Declaration de variable dans le state pour le set de visibilité de mot de passe
  const [passwordVisibility, setPasswordVisibility] = useState(true);
  //Declaration de variable dans le state pour le set de visibilité de mot de passe de confirmation
  const [confirmPasswordVisibility, setconfirmPasswordVisibility] = useState(true);
  //Declaration de variable dans le state de Load des Apis de Google et Facebook
  const [thirdPartyLoading, setThirdPartyLoading] = useState(false);
  //Declaration de variable dans le state pour l'état des erreurs dans le formulaire
  const [showErrorMessage, setShowErrorMessage] = useState(false);
  //Declaration de variable dans le state pour le message d'erreur
  const [errorMessage, setErrorMessage] = useState(null);
  //Appel de loader , d'utilisateur et d'erreur d'inscription depuis le store d'authentification
  const { loading, user, RegisterError } = useSelector((store) => store.authentification);
  //Fonction de toggle de visibilité de mot de passe
  const togglePasswordVisibility = () => {
    setPasswordVisibility(!passwordVisibility);
  };
  //Fonction de toggle de visibilité de mot de passe de confirmation
  const toggleConfirmPasswordVisibility = () => {
    setconfirmPasswordVisibility(!confirmPasswordVisibility);
  };
  //UseFocusEffect
  useFocusEffect(
    React.useCallback(() => {
      if (user?.uid && !loading && !thirdPartyLoading) {
        //verification si l'utilisateur est chargé et existant on se navigue vers la page de felicitation
        setErrorMessage(null);
        setShowErrorMessage(false);
        navigation.navigate('SigninSuccess', { comingFrom: 'SignUp' });
      } else if (RegisterError?.error && !loading && !thirdPartyLoading) {
        //Set d'erreur
        setErrorMessage(RegisterError.error);
        setShowErrorMessage(true);
        //console.log(RegisterError);
      } else {
        //console.log(3);
        setErrorMessage(null);
        setShowErrorMessage(false);
      }
    }, [RegisterError, loading, thirdPartyLoading])
  );

  // useEffect(() => {
  //   if (user?.uid && !loading) {
  //     console.log(1);
  //     setErrorMessage(null);
  //     navigation.navigate('SigninSuccess');
  //   } else if (RegisterError?.error && !loading) {
  //     console.log(2);
  //     setErrorMessage(RegisterError.error);
  //     console.log(RegisterError);
  //   } else {
  //     console.log(3);
  //     setErrorMessage(null);
  //   }
  // }, [RegisterError, loading]);

  const dispatch = useDispatch();

  //Configuration Oauth2.0 pour l'api de connexion et inscription google
  GoogleSignin.configure({
    webClientId: '281609768173-ea66e1boqhbsaggou1dsbm1lsfs4pccp.apps.googleusercontent.com',
  });

  //Fonction de submit d'inscription par facebook
  const onSubmitFacebook = async () => {
    try {
      //Lancement de Loader
      setThirdPartyLoading(true);
      //Deconnexion d'utilisateur s'il y a un utilisateur connecté dans l'api
      await LoginManager.logOut();
      //Connexion d'utilisateur par l'application facebook
      const result = await LoginManager.logInWithPermissions(['public_profile', 'email']);
      //Extraction de token d'accées Facebook d'utilisateur
      const data = await AccessToken.getCurrentAccessToken();
      const accessToken = data.accessToken;
      //Appel au reducer d'inscription par facebook en y passant la token d'accées
      dispatch(registerUserWithFacebook(accessToken));
      //Reintialisation d'erreur
      setErrorMessage(null);
    } catch (error) {
      console.log(error);
    } finally {
      setThirdPartyLoading(false);
    }
  };

  //Fonction de submit d'inscription par Google
  const onSubmitGoogle = async () => {
    try {
      //Lancement de Loader
      setThirdPartyLoading(true);
      //Verification s'il y a un utilisateur connecté
      const isloggedin = await GoogleSignin.getCurrentUser();
      if (isloggedin) {
        //Deconnexion d'utilisateur connecté existant
        await GoogleSignin.signOut();
        await GoogleSignin.revokeAccess();
      } else {
        //Appel à Google Play services
        await GoogleSignin.hasPlayServices();
        //Connexion à compte Google
        const userInfo = await GoogleSignin.signIn();
        //console.log('user', userInfo);
        //Extraction de token d'accées de compte google
        await GoogleSignin.getTokens()
          .then(async (res) => {
            //Appel au reducer d'inscription par Google en y passant la token d'accées
            // console.log('token', res.accessToken); //<-------Get accessToken
            await dispatch(registerUserWithGoogle(res.accessToken));

            setErrorMessage(null);
          })
          .catch((err) => {
            //console.log('error', err);
          });
      }
    } catch (error) {
      if (error.code === statusCodes.SIGN_IN_REQUIRED) {
        await GoogleSignin.hasPlayServices();
        const userInfo = await GoogleSignin.signIn();
        //console.log('user', userInfo);
        await GoogleSignin.getTokens()
          .then(async (res) => {
            // console.log('token', res.accessToken); //<-------Get accessToken
            await dispatch(registerUserWithGoogle(res.accessToken));

            setErrorMessage(null);
          })
          .catch((err) => {
            //console.log('error', err);
          });
      }
    } finally {
      setThirdPartyLoading(false);
    }
  };

  //Fonction de submission de formulaire d'inscription mot de passe et email
  const onSubmit = () => {
    try {
      //Lancement de Loader
      setThirdPartyLoading(true);
      if (values.password === values.confirmPassword) {
        //set des données de formulaire dans un objet
        const data = {
          email: values.email,
          password: values.password,
        };
        //Appel au reducer d'inscription email et mdp en y passant l'objet
        dispatch(registerUser(data));

        setErrorMessage(null);
      }
    } catch (err) {
      console.log(err);
    } finally {
      setThirdPartyLoading(false);
    }
  };

  //Validation de formulaire
  const validationSchema = Yup.object().shape({
    email: Yup.string().email('Veuillez entrer un email valide').required("L'email est obligatoire"),
    password: Yup.string()
      .min(8, 'Le mot de passe doit contenir au moins 8 caractères')
      .matches(/[a-z]/, 'Le mot de passe doit contenir au moins une lettre minuscule')
      .matches(/[A-Z]/, 'Le mot de passe doit contenir au moins une lettre majuscule')
      .matches(/\d/, 'Le mot de passe doit contenir au moins un chiffre')
      .matches(/[!@#$%^&*(),.?":{}|<>]/, 'Le mot de passe doit contenir au moins un caractère spécial')
      .required('Le mot de passe est requis'),
    confirmPassword: Yup.string()
      .oneOf([Yup.ref('password'), null], 'Les mots de passe ne correspondent pas')
      .required('La confirmation du mot de passe est obligatoire'),
  });

  //Instantiation de formulaire par formik
  const { values, handleChange, handleBlur, errors, touched } = useFormik({
    initialValues: {
      email: '',
      password: '',
      confirmPassword: '',
    },
    validationSchema: validationSchema,
    onSubmit,
  });

  //retour de formulaire correspondant d'inscription
  return (
    <>
      {!loading ? (
        <View style={styles.container}>
          <View style={{ marginBottom: 20 }}>
            <WalsupIconSVG />
          </View>
          <TextInput
            style={styles.input}
            placeholder="E-mail"
            value={values.email}
            onChangeText={handleChange('email')}
            onBlur={handleBlur('email')}
          />
          {errors.email && touched.email ? (
            <View style={{ alignSelf: 'baseline', marginLeft: 60 }}>
              <Text style={{ color: '#FF0000', fontSize: 10, marginTop: -20 }}>{errors.email}</Text>
            </View>
          ) : null}
          <View style={styles.passwordContainer}>
            <TextInput
              style={styles.input}
              placeholder="Mot de passe"
              value={values.password}
              onChangeText={handleChange('password')}
              onBlur={handleBlur('password')}
              secureTextEntry={passwordVisibility}
            />
            <TouchableOpacity style={styles.eyeIcon} onPress={togglePasswordVisibility}>
              <Ionicons name={passwordVisibility ? 'eye' : 'eye-off'} size={24} color="gray" />
            </TouchableOpacity>
          </View>
          {errors.password && touched.password ? (
            <View style={{ alignSelf: 'baseline', marginLeft: 60 }}>
              <Text style={{ color: '#FF0000', fontSize: 10, marginTop: -20 }}>{errors.password}</Text>
            </View>
          ) : null}
          <View style={styles.passwordContainer}>
            <TextInput
              style={styles.input}
              placeholder="Confirmation de mot de passe"
              value={values.confirmPassword}
              onChangeText={handleChange('confirmPassword')}
              onBlur={handleBlur('confirmPassword')}
              secureTextEntry={confirmPasswordVisibility}
            />
            <TouchableOpacity style={styles.eyeIcon} onPress={toggleConfirmPasswordVisibility}>
              <Ionicons name={confirmPasswordVisibility ? 'eye' : 'eye-off'} size={24} color="gray" />
            </TouchableOpacity>
          </View>
          {errors.confirmPassword && touched.confirmPassword ? (
            <View style={{ alignSelf: 'baseline', marginLeft: 60 }}>
              <Text style={{ color: '#FF0000', fontSize: 10, marginTop: -20 }}>{errors.confirmPassword}</Text>
            </View>
          ) : null}
          {showErrorMessage && errorMessage && !loading ? (
            <View
              style={{
                paddingHorizontal: 10,
                paddingVertical: 5,
                backgroundColor: 'white',
                borderRadius: 5,
                marginTop: 10,
              }}
            >
              <Text style={{ color: 'red' }}>{errorMessage}</Text>
            </View>
          ) : null}
          <TouchableOpacity
            style={styles.buttonSignUp}
            title="S'inscrire"
            onPress={() => {
              // handle sign up button press
              onSubmit();
            }}
          >
            <Text style={styles.buttonText}>S'inscrire</Text>
          </TouchableOpacity>
          <View
            style={{
              borderColor: '#F5F8FC',
              width: '63%',
              borderWidth: 1,
              marginTop: 30,
              marginBottom: 10,
            }}
          />
          <Text style={styles.orText}>Ou continuer avec</Text>
          <View style={styles.iconContainer}>
            <TouchableOpacity
              onPress={() => {
                //handle Facebook Login
                onSubmitFacebook();
              }}
            >
              <Image source={require('../../../assets/FacebookIcon.png')} style={styles.icon} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                // handle Google login
                onSubmitGoogle();
              }}
            >
              <Image source={require('../../../assets/GoogleIcon.png')} style={styles.icon} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => {
                // handle Apple login
              }}
            >
              <Image source={require('../../../assets/AppleIcon.png')} style={styles.icon} />
            </TouchableOpacity>
          </View>
          <View style={styles.haveAnAccountContainer}>
            <Text style={styles.haveAnAccount}>Vous avez un compte ? </Text>
            <TouchableOpacity
              onPress={() => {
                setErrorMessage(null);
                navigation.navigate('SignIn');
              }}
            >
              <Text style={styles.haveAnAccountLink}>Connexion</Text>
            </TouchableOpacity>
          </View>
        </View>
      ) : (
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator size={56} color={BaseColor.primaryLight} />
        </View>
      )}
    </>
  );
};

export default SignUp;
