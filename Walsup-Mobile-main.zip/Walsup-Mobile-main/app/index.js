import React, { useEffect, useState } from 'react';
import Navigator from './navigation/index';
//redux store provider
import { store, persistor } from './store/store';
import { Provider, useSelector } from 'react-redux';
import 'react-native-gesture-handler';
import { PersistGate } from 'redux-persist/integration/react';
import * as Font from 'expo-font';
import NetInfo from '@react-native-community/netinfo';
import FlashMessage, { showMessage } from 'react-native-flash-message';

//Composant princpal de l'application
const WalsupApp = () => {
  //Appel des fonts Poppins
  let customFonts = {
    'Poppins-Black': require('../assets/fonts/Poppins-Black.otf'),
    'Poppins-BlackItalic': require('../assets/fonts/Poppins-BlackItalic.otf'),
    'Poppins-Bold': require('../assets/fonts/Poppins-Bold.otf'),
    'Poppins-BoldItalic': require('../assets/fonts/Poppins-BoldItalic.otf'),
    'Poppins-ExtraBold': require('../assets/fonts/Poppins-ExtraBold.otf'),
    'Poppins-ExtraBoldItalic': require('../assets/fonts/Poppins-ExtraBoldItalic.otf'),
    'Poppins-ExtraLight': require('../assets/fonts/Poppins-ExtraLight.otf'),
    'Poppins-ExtraLightItalic': require('../assets/fonts/Poppins-ExtraLightItalic.otf'),
    'Poppins-Italic': require('../assets/fonts/Poppins-Italic.otf'),
    'Poppins-Light': require('../assets/fonts/Poppins-Light.otf'),
    'Poppins-LightItalic': require('../assets/fonts/Poppins-LightItalic.otf'),
    'Poppins-Medium': require('../assets/fonts/Poppins-Medium.otf'),
    'Poppins-MediumItalic': require('../assets/fonts/Poppins-MediumItalic.otf'),
    'Poppins-Regular': require('../assets/fonts/Poppins-Regular.otf'),
    'Poppins-SemiBold': require('../assets/fonts/Poppins-SemiBold.otf'),
    'Poppins-SemiBoldItalic': require('../assets/fonts/Poppins-SemiBoldItalic.otf'),
    'Poppins-Thin': require('../assets/fonts/Poppins-Thin.otf'),
    'Poppins-ThinItalic': require('../assets/fonts/Poppins-ThinItalic.otf'),
  };

  //UseEffect qui détecte si l'appareil ou l'application est connecté à l'internet
  useEffect(() => {
    //Function qui détecte si l'appareil ou l'application est connecté à l'internet
    const checkInitialConnection = async () => {
      const initialNetState = await NetInfo.fetch();
      //Affichage de message si l'app n'est pas connecté
      if (!initialNetState.isConnected) {
        showMessage({
          message: "Vous n'etes pas connecté à internet ! Veuillez-vous vous reconnectez",
          type: 'danger',
          position: 'bottom',
          duration: 5000,
        });
      }
    };

    //Ajout d'un listener sur l'état de connexion à internet de l'application pour l'affichage du message si il n y a pas de connexion
    const delayCheckAndSubscribe = setTimeout(() => {
      checkInitialConnection();

      const unsubscribe = NetInfo.addEventListener((state) => {
        if (!state.isConnected) {
          showMessage({
            message: "Vous n'etes pas connecté à internet ! Veuillez-vous vous reconnectez",
            type: 'danger',
            position: 'bottom',
            duration: 5000,
          });
        }
      });

      return () => {
        unsubscribe();
      };
    }, 1000); // Delay of 1 second

    return () => {
      clearTimeout(delayCheckAndSubscribe);
    };
  }, []);

  //Declaration de fontsLoaded dans le state 
  const [fontsLoaded, setFontsLoaded] = useState(false);
  //Function qui charge les fonts 
  const loadFontsAsync = async () => {
    await Font.loadAsync(customFonts);
    setFontsLoaded(true);
  };
  useEffect(() => {
    loadFontsAsync();
  }, []);

  if (!fontsLoaded) {
    return null;
  } else {
    return (
      <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
          <Navigator />
          <FlashMessage position="bottom" />
        </PersistGate>
      </Provider>
    );
  }
};

export default WalsupApp;
